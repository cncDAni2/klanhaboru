javascript: 
var farmolando_faluk="274|562 275|560 _4672 276|561 _4572 276|554"; /*Mely falukat farmolsz? X �s Y koordin�t�kat |-vel v�lasztjuk el egym�st�l, a kh-t�l megszokott m�don - a koordikat egym�st�l pedig teljesen mindegy, vagy legyen valami :-)*/
var kuldendo_egysegek="10 20, meg 50, t�bbi majd alapszam lesz..."; /*Mennyi egys�get k�ldesz az egyes falukra? sorrendben az 1. az el�z� lista 1. faluj�ra vonatkozik. Hagyd �resen, ha az "alapsz�m"-ot szeretn�d �rni a megmaradt helyekre. Sz�mok, egym�st�l mindegy mivel elv�lasztva*/
var alapszam=30; /*Sz�m. Alap�rtelmez�sk�nt ennyi egys�g megy egy falura.*/
var felderitok=1; /*Mennyi felder�t� menjen egy-egy falura? (Ne menjen = 0)*/
var egysegtipus="light"; /*Mivel t�madsz? light=k�nny�lovas, spear=l�ndzsa, ... lsd. Alapok/tech2*/

farmolando_faluk2=farmolando_faluk.match(/[0-9]+(\|)[0-9]+/g);
try{kuldendo_egysegek=kuldendo_egysegek.match(/[0-9]+/g);
var h=kuldendo_egysegek.length;}catch(e){var h=0;}
var b = new Array();
var KL=new Array();
for (var i=0;i<farmolando_faluk2.length;i++){
	b[i]=farmolando_faluk2[i].split("|");
	if (i>(h-1)) KL[i]=alapszam; else KL[i]=kuldendo_egysegek[i];
}
var ID=new Array(); ID[0]=0;
try{var IDs=farmolando_faluk.match(/(\_)[0-9]+/g); for (var i=0;i<IDs.length;i++) ID[i+1]=IDs[i].replace("_","");}catch(e){}

alert(ID);
try{
if (LEPES == undefined) { document.title="CNC: TURBO Farmol�"; var d=document; if(window.frames.length>0) d=window.main.document; url=d.URL; if(url.indexOf('screen=place')==-1) { alert('Gy�lekez�helyen pr�b�ld...'); exit(0); } var LEPES=1; } 
if (LEPES==1) {
	var szam=KL.length; szam=parseInt(szam); 
	http://hu20.klanhaboru.hu/game.php?t=1222555&village=16903&screen=place&mode=command
	         ||                             ||             || 
	tagok[0]=http://hu20.klanhaboru.hu/game.php?t=1222555&village=
	tagok[1]=16903
	ID[0]=16903
	realoldal = http://hu20.klanhaboru.hu/game.php?t=1222555&village=16903&screen=place&mode=command
	
	oldal = document.location.href; tagok = oldal.split(/[0-9]+/g); temp = oldal.match(/[0-9]+/g); 
	if (temp.length==3){/*Helyettes*/
		tagok[0]=tagok[0] + temp[0] + tagok[1]+temp[1]+tagok[2];
		tagok[1]=temp[2];
		ID[0]=temp[2];
	} else { /*Nem helyettes*/
		tagok[0]=tagok[0] + temp[0] + tagok[1];
		tagok[1]=temp[1];
		ID[0]=temp[1];
	}
		 
	var j=0;
	var RefArray=new Array(); for (var i=0;i<szam;i++){ neve="web" + i;if (i==1) j++; if (i==2) j++; alert(j+": "+ID[j]); if (temp.length<3)  var RealOldal=tagok[0] + ID[j] + tagok[2]; else var RealOldal=tagok[0] + ID[j] + tagok[3]; aktualis=window.open(RealOldal,neve); RefArray[i]=aktualis; } LEPES=2; } 
	else if (LEPES==2) { 
	for (i=0;i<szam;i++){ RefArray[i].document.forms[0].x.value=b[i][0]; RefArray[i].document.forms[0].y.value=b[i][1]; RefArray[i].document.forms[0].spy.value=1; RefArray[i].document.getElementById("unit_input_"+egysegtipus).value=KL[i]; RefArray[i].document.forms[0].attack.click(); }
	LEPES=3; 
	} else if (LEPES==3) { 
	function elkuld(){ 
		if (i>szam) clearInterval(ZZ); try{RefArray[i].document.forms[0].submit.click();}catch(e){} i++; } 
	var i=0; LEPES=4; ZZ=setInterval(elkuld,250); 
	} else if (LEPES==4) { 
	for (var i=0;i<szam;i++){ RefArray[i].close(); } } 
}catch(e){alert(e);}

	void(0); 