javascript:
PONTOS=180; /*Ennyivel hamarább indítja a támadást.*/
TIPUS="B"; /*B: Back, azaz mikor érkezzen be? N: Normal, azaz mikor indítsa?*/
function elkuld(){
	//d.forms[0].submit.click();
	return;
}

function createWorker(main){
    var blob = new Blob(
        ["(" + main.toString() + ")(self)"],
        {type: "text/javascript"}
    );
    return new Worker(window.URL.createObjectURL(blob));
}
	
function checktimeshift(){
	var f_ora=document.getElementById("serverDate").innerHTML+" "+document.getElementById("serverTime").innerHTML;
	var f_datum=f_ora.match(/[0-9]+/g);
	var serverido = new Date(f_datum[2],f_datum[1]-1,f_datum[0],f_datum[3],f_datum[4],f_datum[5],0);
	var otthoniido= new Date();
	if (Math.abs(otthoniido-serverido)>5000) {
			return "Vigyázat!\nA szerver ideje, és az Ön operációs rendszerének ideje erősen nem egyforma. A támadás küldése viszont az Ön rendszerének idejéhez lesz mérve.\nAz időeltolódás: "+((otthoniido-serverido)/1000) +
			"mp, azaz "+(((otthoniido-serverido)/1000)/60).toFixed(2)+" perc!\n\n";
	}
	return "";
}

function writeoutDate(d, isOnlyTime) {
	var date = "";
	if (!isOnlyTime) date = d.getFullYear() + "." + leadNull((d.getMonth()+1)) + "." + leadNull(d.getDate()) + " ";
	return date +
		leadNull(d.getHours()) + ":" + leadNull(d.getMinutes()) + ":" + leadNull(d.getSeconds()) + ":" + leadNull(d.getMilliseconds(), true);
	
	function leadNull(num, triple) {
		num = parseInt(num, 10);
		if (triple && num<10) return "00" + num;
		if (triple && num<100) return "0" + num;
		if (num<10) return "0" + num;
		return num;
	}
}
function getIdotartam() {
	var patt=/(<td>)[0-9]+(:)[0-9]+(:)[0-9]+/g;
	var utIdo=d.getElementById("content_value").innerHTML.match(patt)[0].match(/[0-9]+/g);
	for (var i=0;i<utIdo.length;i++) utIdo[i]=parseInt(utIdo[i],10);
	return utIdo;
}

function convert_beIdo(beIdo, utIdo) {
	console.info(beIdo, utIdo);
	var datumSplit=BeIdo.match(/[0-9]+/g);
	var datum = [];
	for (i=0;i < datumSplit.length;i++){
		datumSplit[i] = parseInt(datumSplit[i], 10); 
	}
	
	if ((datumSplit.length == 3 || datumSplit.length == 4)) {
		if (datumSplit.length == 3) datumSplit[3] = 0;
		if (datumSplit[0] > 23 || datumSplit[1] > 59 || datumSplit[2] > 59 || datumSplit[3] > 999) {
			alert ("Érvénytelen időpontmegadás");
			exit(0);
		}
		
		var now = new Date();
		var beadott_ido = new Date();
		
		if (TIPUS == "B") {
			beadott_ido.setHours(datumSplit[0]);
			beadott_ido.setMinutes(datumSplit[1]);
			beadott_ido.setSeconds(datumSplit[2]);
			console.info('NOW_NOW', now, ' + ', utIdo[0]);
			now.setHours(now.getHours() + utIdo[0]);
			console.info('IS: ', now);
			now.setMinutes(now.getMinutes() + utIdo[1]);
			now.setSeconds(now.getSeconds() + utIdo[2]);
			now.setFullYear(beadott_ido.getFullYear());
			now.setMonth(beadott_ido.getMonth());
			now.setDate(beadott_ido.getDate());
		} else {
			beadott_ido.setHours(datumSplit[0]);
			beadott_ido.setMinutes(datumSplit[1]);
			beadott_ido.setSeconds(datumSplit[2]);
		}
		
		console.info('New/Beadott', now, beadott_ido);
		if (now > beadott_ido) beadott_ido.setDate(beadott_ido.getDate() + 1);
		datum = [beadott_ido.getFullYear(), beadott_ido.getMonth() + 1, beadott_ido.getDate(), datumSplit[0], datumSplit[1], datumSplit[2], datumSplit[3]];
		console.info(datum);
	} else datum = datumSplit;
	

	if (datum.length<7) datum[6]=0;
	if (datum[0] < 2017 || datum[0] > 2030 || datum[1]>12 || datum[2]>31 || datum[3]>23 || datum[4]>59 || datum[5]>59 || datum[6]>999) {alert ("Érvénytelen időpontmegadás"); exit(0);}

	return datum;
}

var d=document;
if (window.frames.length>0 && typeof window.main !== 'undefined') d=window.main.document;
if (d.URL.indexOf('try=confirm')==-1) {
	alert('Gyülekezőhelyen, támadás/erősítés leokézása előtt próbáld...');
	exit(0);
}

var alertStr = "";
try{
	alertStr = checktimeshift();
}catch(e){alert('Hiba történt, a script kilép...\n\n' + e); exit(0);}

var tipus = d.getElementById("troop_confirm_go").value;
var toltoSzoveg="Adja meg az indítás idejét:";
if (TIPUS=="B") {
	toltoSzoveg = "Adja meg, mikorra érkezzen a sereg:";
}

var opSysTime=new Date();
TIPUS = TIPUS.toUpperCase();

var odaerkezes = new Date();
if (TIPUS=="B") { /*Csak BACK számításakor kell majd*/
	var ut_idotartam = getIdotartam();
	odaerkezes.setHours(odaerkezes.getHours() + ut_idotartam[0]);
	odaerkezes.setMinutes(odaerkezes.getMinutes() + ut_idotartam[1]);
	odaerkezes.setSeconds(odaerkezes.getSeconds() + ut_idotartam[2]);
}
odaerkezes.setMilliseconds(0);

var BeIdo=prompt(alertStr + tipus + "\n " + toltoSzoveg + "\n(Formátum: [Év Hónap Nap] Óra Perc mp [ms] - az elválasztás nem számít, a ms és az Én/Hónap/Nap megadása opcionális)", writeoutDate(odaerkezes, false));
if (BeIdo==null) exit(0);

var datum = convert_beIdo(BeIdo, ut_idotartam);
var dateforOutput = new Date(datum[0],datum[1]-1,datum[2],datum[3],datum[4],datum[5],datum[6]);
var ERKEZES = 		new Date(datum[0],datum[1]-1,datum[2],datum[3],datum[4],datum[5],datum[6]);

var indIdoText = "";
if (TIPUS=="B") {
	ERKEZES.setHours(ERKEZES.getHours() - ut_idotartam[0]);
	ERKEZES.setMinutes(ERKEZES.getMinutes() - ut_idotartam[1]);
	ERKEZES.setSeconds(ERKEZES.getSeconds() - ut_idotartam[2]);
	ERKEZES.setMilliseconds(ERKEZES.getMilliseconds() - PONTOS);
	indIdoText = "Indítás ideje: <font style='color: #FF00FF; font-weight: bold; font-size: 115%;'>" + writeoutDate(ERKEZES, true) + '</font><br>';
}

kieg=document.createElement("p");
kieg.innerHTML="Felülbírálva:<br>c&amp;c időzítő beállítva erre:<br><b>" + writeoutDate(dateforOutput, false) + "</b><br>" + indIdoText + "Pontosítás: <font style='color: red;'>"+PONTOS+"ms</font>"; 
document.getElementById("date_arrival").setAttribute('style', 'background: #f4e4bc url(http://cncdani2.000webhostapp.com/!Files/images/ido_dead2.png) no-repeat; background-position: right top; background-size: 40px;');
document.getElementById("date_arrival").innerHTML="";
document.getElementById("date_arrival").appendChild(kieg);

/*SZIDO meghatározása, azaz mennyi ms múlva kell OK-ézni*/
ERKEZES.setMilliseconds(ERKEZES.getMilliseconds() + PONTOS);
var CURRTIME=new Date();
CURRTIME.setMilliseconds(CURRTIME.getMilliseconds()+PONTOS);
SZIDO=ERKEZES - CURRTIME;
if (typeof(window.URL) != "undefined") {
	var worker = createWorker(function(self){
		self.addEventListener("message", function(e) {
			setTimeout(function(){
				postMessage('');
			}, e.data);
		}, false);
	});

	worker.onmessage = function(e) {
		elkuld();
	};
	worker.postMessage(SZIDO);
} else {
	setTimeout(function(){
		elkuld();
	}, SZIDO);
}
void(0);