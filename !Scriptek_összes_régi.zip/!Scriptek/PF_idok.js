javascript:
if (document.getElementById("buildings_table")) {
	var T = document.getElementById("buildings_table").rows;
} else {
	var T = document.getElementById("production_table").rows;
}

doWrite(getIndex('Toborzás', T));
doWrite(getIndex('Építés', T));

function doWrite(CELL) {
	for (var i=1;i<T.length;i++) {
		var maxIdo = 0;
		var ALLIMG = T[i].cells[CELL].getElementsByTagName("img");
		if (!ALLIMG || ALLIMG.length == 0) continue;
		for (var j=0;j<ALLIMG.length;j++) {
			var currIdo = 0;
			var time = ALLIMG[j].title;
			if (time == 'Visszavonás') continue;
			time = time.split(" - ");
			time = time[time.length-1];
			var d = new Date();
			if (time.indexOf("ma") > -1) {
				time = time.split(":");
				d.setHours(parseInt(time[1]));
				d.setMinutes(parseInt(time[2]));
			} else if (time.indexOf("holnap") > -1) {
				time = time.split(":");
				d.setDate(d.getDate() + 1);
				d.setHours(parseInt(time[1]));
				d.setMinutes(parseInt(time[2]));
			} else {
				var days = time.split(".");
				time = time.split(" ")[2].split(":");
				d.setDate(parseInt(days[0]));
				d.setMonth(parseInt(days[1]) - 1);
				d.setHours(parseInt(time[0]));
				d.setMinutes(parseInt(time[1]));
			}
			currIdo = kiir(d);
			maxIdo = maxIdo < currIdo ? currIdo : maxIdo;
		}
		T[i].cells[CELL].innerHTML = maxIdo;
	}
}

function kiir(d) {
	var most = new Date();
	return Math.round((d - most) / (1000 * 60));
}

function getIndex(str, rows) {
	for (var i=0;i<rows[0].cells.length;i++) {
		if (rows[0].cells[i].innerText == str) return i;
	}
	return -1;
}
void(0);