self.addEventListener("message", function(e) {
	 setTimeout(function(){
		postMessage('');
	}, e.data);
}, false);