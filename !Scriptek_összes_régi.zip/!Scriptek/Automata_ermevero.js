javascript:
var ido = 300; /*Hány mp-enként nézze meg, lehet e verni érmét?*/
function ver(REF){
	REF.document.getElementById("select_anchor_top").click();
	REF.document.forms[0].submit();
}
function openPage() {
	winREF = window.open(page, 'ermeauto');
}
var page = window.location.href;
page = page.replace(/&amp;from=[-0-9]+/g, '');
page += '&amp;from=-1';
var winREF = window.open(page, 'ermeauto');
document.getElementById("ds_body").innerHTML = "&lt;h1 align='middle'&gt;Ez a lap az auto érmeverés script miatt van itt...&lt;/h1&gt;";
var INDEX = 0;
var next = ido;
setInterval(function(){
	switch (INDEX) {
		case 0: openPage(); next = 10; INDEX = 1; break;
		case 1: ver(winREF); next = ido * (Math.random()+0.5); INDEX = 0; break;
		default: INDEX = 0;
	}
}, next * 1000);
void(0);