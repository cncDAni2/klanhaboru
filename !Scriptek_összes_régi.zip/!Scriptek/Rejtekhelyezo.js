var SPEED=500;
var CNC_LOC = window.location.href;
var REF;
var LNK = CNC_LOC;
var STATE = 0;
var ERR = 0;
setTimeout(build, 100);

function open_window() {
	REF = window.open(CNC_LOC, 'cnc_Hide');
	STATE = 1; ERR = 0;
}
function build_hide() {
	if (!REF.document.getElementById("main_buildrow_hide")) {
		ERR++; return;
	}
	if (REF.document.getElementById("main_buildlink_hide_1")) {
		REF.document.getElementById("main_buildlink_hide_1").click(); console.info("start hide");
		return;
	}
	if (REF.document.getElementById("main_buildlink_hide_2")) {
		REF.document.getElementById("main_buildlink_hide_2").click(); console.info("start hide");
		return;
	}
	if (REF.document.getElementById("main_buildlink_hide_3")) {
		REF.document.getElementById("main_buildlink_hide_3").click(); console.info("start hide");
	}
	console.info ("Switch demolish");
	STATE = 2;
	ERR = 0;
}
function finish_build() {
	if (REF && REF.document.getElementById("buildqueue")) {
		REF.document.getElementById("buildqueue").getElementsByClassName("btn-instant-free")[0].click();
		return true;
	}
	return false;
}
function switch_to_demilish() {
	if (LNK.indexOf("mode=build") > -1) {
		REF = window.open(LNK.replace('mode=build', 'mode=destroy'), 'cnc_Hide');
	} else {
		REF = window.open(LNK + '&mode=destroy', 'cnc_Hide');
	}
	STATE++;
}
function switch_to_build() {
	REF = window.open(LNK.replace('mode=destroy', 'mode=build'), 'cnc_Hide');
	STATE = 1;
}
function demilish_hide() {
	if (!REF.document.getElementById("building_wrapper")) {
		ERR++; return;
	}
	var allButtons = REF.document.getElementById("building_wrapper").getElementsByClassName("btn");
	for (var i=0;i<allButtons.length;i++) {
		if (allButtons[i].href.indexOf('id=hide') > -1 && allButtons[i].href.indexOf("action=downgrade_building") > -1) {
			allButtons[i].click(); return;
		}
	}
	STATE++;
}
function build() {
	console.info("STATE::", STATE, ERR);
	if (ERR > 10) STATE = 0;
	if (!finish_build()) {
		switch(STATE) {
			case 0: open_window(); break;
			case 1: build_hide(); break;
			case 2: switch_to_demilish(); break;
			case 3: demilish_hide(); break;
			case 4: switch_to_build(); break;
		}
	}
	var realSpeed = SPEED * ((Math.random() * 1.5) + 0.5);
	setTimeout(build, realSpeed);
}