javascript:
function setCookie(name, value, expire) {
	document.cookie = name + "=" + escape(value)
	+ ((expire == null) ? "" : ("; expires=" + expire.toGMTString()));
}

function getCookie(Name){
	var search = Name + "=";
	if (document.cookie.length > 0) {
		offset = document.cookie.indexOf(search);
		if (offset != -1) {
			offset += search.length;
			end = document.cookie.indexOf(";", offset);
			if (end == -1) end = document.cookie.length;
			return unescape(document.cookie.substring(offset, end));
		}
	}
}
var d=document;	
	if(window.frames.length>0) d=window.main.document;
	url=d.URL;
	if(url.indexOf('screen=report')==-1) {
		alert('Jelent�sekn�l pr�b�ld...');
		exit(0);
	}
	
	var nyers=document.getElementById("attack_spy");
	var tomb = nyers.innerHTML;
	var patt=/([(])/g;
	tomb=tomb.replace(patt,"E");
	patt=/([)])/g;
	tomb=tomb.replace(patt,"E");
	patt=/>/g;
	tomb=tomb.replace(patt,"");
	patt=/</g;
	tomb=tomb.replace(patt,"");
		patt=/(Fatelep bESzint )[0-9]+/g;
		FA=patt.exec(tomb);
		patt=/[0-9]+/g;
		FA=patt.exec(FA);
		if (FA==null) FA=0;
	
		patt=/(Agyagb�nya bESzint )[0-9]+/g;
		AGYAG=patt.exec(tomb);
		patt=/[0-9]+/g;
		AGYAG=patt.exec(AGYAG);
		if (AGYAG==null) AGYAG=0;
	
		patt=/(Vasb�nya bESzint )[0-9]+/g;
		VAS=patt.exec(tomb);
		patt=/[0-9]+/g;
		VAS=patt.exec(VAS);
		if (VAS==null) VAS=0;
	
		patt=/(Fal bESzint )[0-9]+/g;
		FAL=patt.exec(tomb);
		patt=/[0-9]+/g;
		FAL=patt.exec(FAL);
	
	var falukordi=document.getElementById("labelText");
	var kordik = falukordi.innerHTML;
	KT=kordik.match(/[0-9][0-9][0-9]/g);
	hossz=KT.length;	
	csomag = KT[hossz-2] + "|" + KT[hossz-1] + "\t\t\t\t" + FA + "\t" + AGYAG + "\t" + VAS;
	if (FAL !=null) csomag = csomag + "\t\tFal: " + FAL;
	
	expDate = new Date();
	expDate.setTime(expDate.getTime() + (2*60*1000));
		VISITED = getCookie('visited');
		if (VISITED==null || VISITED=="") {
			VISITED=0;
		} else {
			VISITED++;
		}
		setCookie('visited', VISITED, expDate);
	valt = "falu" + VISITED;
		expDate.setTime(expDate.getTime() + (10*60*1000));
		setCookie(valt, csomag, expDate);
			elementali=VISITED + ". falu sikeresen felv�ve";
			d.getElementById('labelText').innerHTML=elementali;
	
	VISITED=parseInt(VISITED);
	if (VISITED>24) {
		kiir = "Ez az utols� amit elt�rolhattam! Itt van az eddigi: \n";
		expDate = new Date();
		expDate.setTime(expDate.getTime() - (1000));
		for (i=0;i<26;i++){
			LEPES = i;
			VALT = "falu" + LEPES;
			resz = getCookie(VALT);
			kiir = kiir + resz + "\n";
			alert(VALT);
			setCookie(VALT, 0, expDate);
			alert(VALT);
		}
		alert (kiir);
		setCookie('visited', 0, expDate);
	}
	void(0);