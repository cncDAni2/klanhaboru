javascript:
if (typeof(str)!='undefined') exit(0);

function doboz_modell(){
	$("body").append('<div id="konvertalt" style="background-color: #ecd8ad; width: 550px; color: black; position: fixed; right:5%; top:20%; border:3px solid black; font-size: 11pt; padding: 5px; z-index:20;"><div id="k_fej" style="background-color: #e77e8c;"><b>C&C M�hely - Jelent�s konvert�l�</b><br></div><br>\
	<form id="opts"><input type="checkbox" name="spoiler" checked> [Spoiler] <input type="checkbox" name="zero"> No zeroes/Ne legyenek 0-�k<br>\
	<fieldset>\
		<legend>Hide attacker\'s data/T�mad� adatainak elrejt�se</legend>\
		<label style="display: inline">\
		<input type="checkbox" name="att_name"/>\
			Username/n�v\
		</label>\
		<label style="display: inline">\
		<input type="checkbox" name="att_vill"/>\
			Village/falu\
		</label>\
		<label style="display: inline">\
		<input type="checkbox" name="att_units"/>\
			Units/egys�gek\
		</label>\
		<br/>\
	</fieldset><fieldset>\
		<legend>Hide defender\'s data/V�d� adatainak elrejt�se</legend>\
		<label style="display: inline">\
		<input type="checkbox" name="def_name"/>\
			Username/n�v\
		</label>\
		<label style="display: inline">\
		<input type="checkbox" name="def_vill"/>\
			Village/falu\
		</label>\
		<label style="display: inline">\
		<input type="checkbox" name="def_units"/>\
			Units/egys�gek</label>\
		<label style="display: inline">\
		<br>\
		<input type="checkbox" name="scout"/>\
			Scout/k�mked�s\
		</label>\
	</fieldset>\
	<input type="button" onclick="konvertalas()" value="Re-convert"></form>\
	<textarea id="jeli" cols="70" rows="30" onclick="this.select()"></textarea><p id="tags"></p></div>');
}
doboz_modell();
var OPTS=document.getElementById("opts");
var str="";
var fej_str="";


function konvertalas(){try{
	var jel=document.getElementById("content_value").getElementsByTagName("table")[4];
	if (OPTS.att_name.checked || OPTS.def_name.checked || OPTS.att_vill.checked || OPTS.def_vill.checked) var hidden=true; else var hidden=false;
	/*T�ma, �s id�*/
	str="";
	str+="[table][**]"+$.trim(jel.rows[0].cells[0].innerText)+"[||]"; if (hidden) str+="[/**]\n"; else str+=$.trim(jel.rows[0].cells[1].innerText)+"[/**]\n";
	str+="[*]"+jel.rows[1].cells[0].innerText+"[|]"+jel.rows[1].cells[1].innerText+"[/*][/table]\n";
	if (!hidden) fej_str="[img]"+jel.rows[0].cells[1].getElementsByTagName("img")[0].getAttribute("src")+"[/img] "+$.trim(jel.rows[0].cells[1].innerText)+" ("+jel.rows[1].cells[1].innerText+")"; else fej_str="[img]"+jel.rows[0].cells[1].getElementsByTagName("img")[0].getAttribute("src")+"[/img] "+$.trim(jel.rows[0].cells[0].innerText)+" ("+jel.rows[1].cells[1].innerText+")";;


	/*Ki nyert?*/
	str+="[b][size=14]"+jel.getElementsByTagName("h3")[0].innerText+"[/size][/b]\n\n";
	
	/*Szerencse �s mor�l*/
	str+="[b][i]"+jel.getElementsByTagName("h4")[0].innerText+"[/i]\n"+document.getElementById("attack_luck").getElementsByTagName("b")[0].innerText+"\n"+jel.getElementsByTagName("h4")[1].innerText+"[/b]\n\n";

	/*T�mad� adatai*/
	jel=document.getElementById("attack_info_att");
	str+="[table][**]"+jel.rows[0].cells[0].innerText+"[||]"; if (OPTS.att_name.checked) str+=""; else str+="[player]"+jel.rows[0].cells[1].innerText+"[/player]"; str+="[/**]\n";
	var temp=jel.rows[1].cells[1].innerText.match(/[0-9]+(\|)+[0-9]+/g);
	str+="[*]"+jel.rows[1].cells[0].innerText+"[|]"; if (OPTS.att_vill.checked) str+=""; else str+="[coord]"+temp[temp.length-1]+"[/coord]"; str+="[/*][/table]";
		if (OPTS.att_name.checked) fej_str+="\n"+"???: "; else fej_str+="\n[player]"+jel.rows[0].cells[1].innerText+"[/player]: ";
		if (OPTS.att_vill.checked) fej_str+="???|???\n"; 	  else fej_str+="[coord]"+temp[temp.length-1]+"[/coord]\n";

	/*T�mad� egys�gek*/
	jel=document.getElementById("attack_info_att_units");
	str+="[table][*]";
	for (var i=1;i<jel.rows[0].cells.length;i++){
		temp=jel.rows[0].cells[i].getElementsByTagName("img")[0].getAttribute("src").split("unit_")[1].split(".")[0];
		str+="[|][unit]"+temp+"[/unit]";
	}
	str+="[/*]\n[*]";
	var MAX=0;
	for (var i=0;i<jel.rows[1].cells.length;i++){
		temp=jel.rows[1].cells[i].innerText;
		if (temp=="0") {if (OPTS.zero.checked) temp=""; else temp="[color=#B19661]0[/color]";} else if (parseInt(temp)>MAX) MAX=parseInt(temp);
		if (OPTS.att_units.checked) temp="";
		if ((i+1)==jel.rows[1].cells.length) str+=temp; else str+=temp+"[|]";
	}
	str+="[/*]\n[*]";
	for (var i=0;i<jel.rows[2].cells.length;i++){
		temp=jel.rows[2].cells[i].innerText;
		if (temp=="0") {if (OPTS.zero.checked) temp=""; else temp="[color=#B19661]0[/color]";} else if (parseInt(temp)>MAX) MAX=parseInt(temp);
		if (OPTS.att_units.checked) temp="";
		if ((i+1)==jel.rows[2].cells.length) str+=temp; else str+=temp+"[|]";
	}

	str+="[/*][/table]";
	/*T�mad�/extra adatok*/
	jel=document.getElementById("attack_info_att");
	if (jel.rows.length>=3 && !OPTS.att_units.checked) {
		str+="";
		for (var i=3;i<jel.rows.length;i++){
			str+="";
			for (var j=0;j<jel.rows[i].cells.length;j++){
				temp=$.trim(jel.rows[i].cells[j].innerText);
				temp=temp.replace(/\t/g," ");
				temp=temp.replace(/\n/g,"");
				temp=temp.replace(/\r/g," ");
				temp=temp.replace(/( )+/g," ");
				str+=temp+" ";
			}
			str+="\n";
		}
		str+="\n";
	} else str+="\n";
	/*-----------------------------------------------------------*/
	/*V�dekez� adatai*/
	jel=document.getElementById("attack_info_def");
	temp=jel.rows[0].cells[1].innerText; if (OPTS.def_name.checked) temp=""; else {if (temp!="---") temp="[player]"+temp+"[/player]";}
	str+="[table][**]"+jel.rows[0].cells[0].innerText+"[||]"+temp+"[/**]\n";
		if (temp=="") fej_str+="???"; else fej_str+=temp;
	var temp=jel.rows[1].cells[1].innerText.match(/[0-9]+(\|)+[0-9]+/g);
	if (OPTS.def_vill.checked) temp="";
	str+="[*]"+jel.rows[1].cells[0].innerText+"[|]"; if (temp!="") str+="[coord]"+temp[temp.length-1]+"[/coord]"; str+="[/*][/table]";
		if (temp=="") fej_str+=": ???|???"; else fej_str+=": [coord]"+temp[temp.length-1]+"[/coord]";

	/*Folyt.: V�dekez�*/
	str+="[table]";
	if (jel=document.getElementById("attack_info_def_units")) lat=true; else lat=false;
	str+="\n[*]";
	if (!lat) {str+=$.trim(document.getElementById("attack_info_def").rows[2].innerText);} else {
		for (var i=1;i<jel.rows[0].cells.length;i++){
			temp=jel.rows[0].cells[i].getElementsByTagName("img")[0].getAttribute("src").split("unit_")[1].split(".")[0];
			str+="[|][unit]"+temp+"[/unit]";
		}
		str+="[/*]\n[*]";
		var MAX=0;
		for (var i=0;i<jel.rows[1].cells.length;i++){
			temp=jel.rows[1].cells[i].innerText;
			if (temp=="0") {if (OPTS.zero.checked) temp=""; else temp="[color=#B19661]0[/color]";} else if (parseInt(temp)>MAX) MAX=parseInt(temp);
			if (OPTS.def_units.checked) temp="";
			if ((i+1)==jel.rows[1].cells.length) str+=temp; else str+=temp+"[|]";
		}
		str+="[/*]\n[*]";
		for (var i=0;i<jel.rows[2].cells.length;i++){
			temp=jel.rows[2].cells[i].innerText;
			if (temp=="0") {if (OPTS.zero.checked) temp=""; else temp="[color=#B19661]0[/color]";} else if (parseInt(temp)>MAX) MAX=parseInt(temp);
			if (OPTS.def_units.checked) temp="";
			if ((i+1)==jel.rows[2].cells.length) str+=temp; else str+=temp+"[|]";
		}
	}
	str+="[/*][/table]";

	/*V�d�/extra adatok*/
	jel=document.getElementById("attack_info_def");
	if (jel.rows.length>=3 && !OPTS.def_units.checked) {
		str+="";
		for (var i=3;i<jel.rows.length;i++){
			str+="";
			for (var j=0;j<jel.rows[i].cells.length;j++){
				temp=$.trim(jel.rows[i].cells[j].innerText);
				temp=temp.replace(/\t/g," ");
				temp=temp.replace(/\n/g,"");
				temp=temp.replace(/\r/g," ");
				temp=temp.replace(/( )+/g," ");
				str+=temp+" ";
			}
			str+="\n";
		}
		str+="\n";
	} else str+="\n";
	/*------------------------------------------------------------*/
	/*attack_spy -> k�mked�s*/
	/*ha van, akkor egy H4-est lek�r�nk, [b][i], azt�n table
	v�gig az oszlopon - ha van span->nyersanyagcucc; am�gy meg �p�let <br>-t \n-re, <b>-t [b]-re, cs�*/
	if (!(OPTS.scout.checked) && (jel=document.getElementById("attack_spy"))){
		str+="[b][i]"+document.getElementById("content_value").getElementsByTagName("table")[4].getElementsByTagName("h4")[2].innerText+"[/i][/b]";
		
		str+="[table]";
		for (var i=0;i<jel.rows.length;i++){
			str+="[**]"+jel.rows[i].cells[0].innerText+"[|]";
			if (jel.rows[i].cells[1].getElementsByTagName("span").length>0){ /*Nyersanyag*/
				temp=$.trim(jel.rows[i].cells[1].innerText).split("  ");
				var k=0;
				for (var j=0;j<jel.rows[i].cells[1].getElementsByTagName("span").length;j++){
					if (jel.rows[i].cells[1].getElementsByTagName("span")[j].getAttribute("class").indexOf("header")>-1){
						var temp2=jel.rows[i].cells[1].getElementsByTagName("span")[j].getAttribute("class").split("header ")[1];
						if (temp2=="wood") str+="[img]http://hu17.tribalwars.net/graphic/holz.png?a3702[/img]"+temp[k];
						if (temp2=="stone") str+="[img]http://hu17.tribalwars.net/graphic/lehm.png?6c9bd[/img]"+temp[k];
						if (temp2=="iron") str+="[img]http://hu17.tribalwars.net/graphic/eisen.png?0e9e5[/img]"+temp[k];
						k++;
					}
				}
			} else {	/*�p�let v bel�t�s??? (!!!)*/
				temp=$.trim(jel.rows[i].cells[1].innerHTML);
				temp=temp.replace(/\t/g," ");
				temp=temp.replace(/\n/g,"");
				temp=temp.replace(/\r/g,"");
				temp=temp.replace(/( )+/g," ");
				temp=temp.replace(/(<br \/>)/g,"\n");
				temp=temp.replace(/(<br>)/g,"\n");
				temp=temp.replace(/<b>/g,"[b]");
				temp=temp.replace(/<\/b>/g,"[/b]");
				str+=temp;
			}
			str+="[/**]";
		}
		str+="[/table]\n";
	}

	/*attack_result -> zs�km�ny �s rombol�s*/
	/*v�gig a sorokon, [**]-al kezdj�nk, cell[0], [|], cell[1], de cser�lj�k a <b>-ket [b]-re, �s k�sz*/
	if (!(OPTS.scout.checked) && (jel=document.getElementById("attack_results"))){
		str+="[table]";
		for (var i=0;i<jel.rows.length;i++){
			str+="[**]"+jel.rows[i].cells[0].innerText+"[|]";
			if (jel.rows[i].cells[1].getElementsByTagName("span").length>0){ /*Nyersanyag*/
				temp=$.trim(jel.rows[i].cells[1].innerText).split("  ");
				var k=0;
				for (var j=0;j<jel.rows[i].cells[1].getElementsByTagName("span").length;j++){
					if (jel.rows[i].cells[1].getElementsByTagName("span")[j].getAttribute("class").indexOf("header")>-1){
						var temp2=jel.rows[i].cells[1].getElementsByTagName("span")[j].getAttribute("class").split("header ")[1];
						if (temp2=="wood") str+="[img]http://hu17.tribalwars.net/graphic/holz.png?a3702[/img]"+temp[k];
						if (temp2=="stone") str+="[img]http://hu17.tribalwars.net/graphic/lehm.png?6c9bd[/img]"+temp[k];
						if (temp2=="iron") str+="[img]http://hu17.tribalwars.net/graphic/eisen.png?0e9e5[/img]"+temp[k];
						k++;
					}
				}
				str+="[|]"+$.trim(jel.rows[i].cells[2].innerText);
			} else {	/*bont�sok*/
				temp=$.trim(jel.rows[i].cells[1].innerHTML);
				temp=temp.replace(/\t/g," ");
				temp=temp.replace(/\n/g,"");
				temp=temp.replace(/\r/g,"");
				temp=temp.replace(/( )+/g," ");
				temp=temp.replace(/(<br \/>)/g,"\n");
				temp=temp.replace(/(<br>)/g,"\n");
				temp=temp.replace(/<b>/g,"[b]");
				temp=temp.replace(/<\/b>/g,"[/b]");
				str+=temp;
			}
			str+="[/**]";
		}
		str+="[/table]";
	}
	if (OPTS.spoiler.checked) document.getElementById("jeli").value=fej_str+"[spoiler]"+str+"[/spoiler]"; else document.getElementById("jeli").value=str;
	document.getElementById("jeli").select();
	document.getElementById("tags").innerHTML="BB codes: <"+document.getElementById("jeli").value.match(/\[[^\/]/g).length;
}catch(e){alert(e)}}

konvertalas();

$(document).ready(function(){
	$(function() {
        $("#konvertalt").draggable({handle: $('#k_fej')});
	}); 
}); 
void(0);