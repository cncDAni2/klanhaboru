javascript:
ujkieg('Building',"Építő",'<tr><td><b>Alap beállított építés:</b><br><textarea rows="10" cols="100" onmouseover="sugo(\'Faluk kiépítésének sorrendje, mely új falu esetén használatos. Később átírható.\')"></textarea></td></tr><tr><td></td></tr>');
ujkieg_hang('Építő','epulet_elkeszult;epulet_falu_kesz;epulet_falu_nincs_tobb_hely');