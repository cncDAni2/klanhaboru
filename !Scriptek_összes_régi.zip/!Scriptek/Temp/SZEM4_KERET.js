javascript:
function stop(){
var x = setTimeout('',100); for (var i = 0 ; i < x ; i++) clearTimeout(i);}
stop(); /*Id�stop*/

function loadXMLDoc(dname) {
	if (window.XMLHttpRequest) xhttp=new XMLHttpRequest();
		else xhttp=new ActiveXObject("Microsoft.XMLHTTP");
	xhttp.open("GET",dname,false);
	xhttp.send();
	return xhttp.responseXML;
}

try{
var SZEM4_LOCAL_STORAGE="";
var AZON="S0"; /*Levessz�k az S-t, sz�mot elt�roljuk, vizsg�ljuk, ha van s�tibe akkor n�velj�k. S�ti->5p, kernel friss�tgeti 5p-enk�nt. init()-be n�zni van e!*/
var BASE_URL=document.location.href.split("game.php")[0];
var CONFIG=loadXMLDoc(BASE_URL+"interface.php?func=get_config");
var SPEED=CONFIG.getElementsByTagName("speed")[0].textContent;
var UNITS=CONFIG.getElementsByTagName("unit_speed")[0].textContent;
}catch(e){alert(e);}

function init(){try{
	document.getElementsByTagName("body")[0].innerHTML='<div id="alert2" style="width: 300px; background-color: #60302b; color: yellow; position: absolute; left:40%; top:40%; border:3px solid black; font-size: 11pt; padding: 5px; z-index:200; display:none"><p id="alert2szov"></p><p align="center"><a href=\'javascript: alert2("close");\'>Bez�r X</a></p></div> <table width="1024px" align="center" class="fej" style="background-image:url(\'http://cncdani2.freeiz.com/pic/szem4/header_felhok.jpg\');"> <tr><td width="70%" id="fejresz" style="vertical-align:middle; margin:auto;"><h1><i>SZEM 4</i></h1></td><td id="sugo" height="80px"></td></tr> <tr><td colspan="2" id="menuk" style="border-top: 2px solid black;">  	<div class="divrow" style="width: 1024px"> 		<span class="divcell" id="kiegs" style="text-align:left; width:774px;"> 		</span> 		<span class="divcell" style="text-align:right; width:250px"> 			<a href=\'javascript: nyit("naplo");\' onmouseover="sugo(\'Esem�nyek napl�ja\')">Napl�</a> 			<a href=\'javascript: nyit("debug");\' onmouseover="sugo(\'Hibanapl�\')">Debug</a> 			<a href=\'javascript: nyit("hang");\'><img src="http://muhely2.cncdani2.freeiz.com/images/SZEM4/hang.png" onmouseover="sugo(\'Hangbe�ll�t�sok\')" alt="hangok"></a> 		</span> 	</div> 	 </td></tr> </table> <p id="content" style="display: inline"></p>';
	document.getElementById("content").innerHTML='<table class="menuitem" width="1024px" align="center" id="naplo" style="display: none"> <tr><td> <h1 align="center">Napl�</h1><br> <br> <table align="center" class="vis" id="naploka"><tr><th>D�tum</th><th>Script</th><th>Esem�ny</th></tr></table> </td></tr> </table>  <table class="menuitem" width="1024px" align="center" id="debug" style="display: none"> <tr><td> <h1 align="center">DeBugger</h1><br> <br> <table align="center" class="vis" id="debugger"><tr><th>D�tum</th><th>Script</th><th>Esem�ny</th></tr></table> </td></tr> </table>  <table class="menuitem" width="1024px" align="center" id="hang" style="display: none"> <tr><td> <p align="center"><audio id="audio1" controls="controls" autoplay="autoplay"><source id="wavhang" src="" type="audio/wav"></audio></p> <h1 align="center">Hangbe�ll�t�s</h1><br> <div id="hangok" style="display:table;"> 	<div style="display:table-row;"> 	</div> </div> </td></tr> </table>';
	document.getElementsByTagName("style")[0].innerHTML='body{ background: #111; } table.fej{ padding:1px;  margin:auto; color: white; border: 1px solid yellow; } table.menuitem{ vertical-align:top; text-align: top; padding: 20px; margin:auto; color: white; border: 1px solid yellow; } table.menuitem td{ padding: 0px; vertical-align:top; }  table{ padding: 0px; margin: auto; color: white; border: 1px solid green; } table.vis{ color:black; }  textarea{ background-color: #020; color:white; } .divrow{ display: table-row; } .divcell { display: table-cell; text-align: center; vertical-align:top; }  a{ color: white; } img{ border-color: grey; padding:1px; }';
	document.title="SZEM IV";
	AZON="S0";
	debug("SZEM 4","Prog.azon: "+AZON);
	debug("SZEM 4","W-Speed: "+SPEED);
	debug("SZEM 4","U-Speed: "+UNITS);
	/*
	 * AZON be�ll�t�sa multira!
	 */
}catch(e){alert("Hiba ind�t�skor:\n"+e);}}

function pic(file){
	return "http://muhely2.cncdani2.freeiz.com/images/SZEM4/"+file;
}
function playSound(hang){try{
	var ison=document.getElementsByName(hang)[0];
	if (ison==undefined) {debug("hanghiba","Nem defini�lt hang: "+hang); return}
	if (ison.checked==false) return;
	var play="http://cncdani2.freeiz.com/SZEM3/Sounds/"+hang+".wav";
	document.getElementById("wavhang").src=play;
	document.getElementById("audio1").load();
}catch(e){alert2(e);}}

function sugo(str){
	document.getElementById("sugo").innerHTML=str;
	return;
}

function nyit(ezt){try{ /*Csin�lj kiemel�st is (+anti-kiemel�st is akkor :D)*/
	var temp=document.getElementById("content").childNodes;
	var cid="";
	for (var i=0;i<temp.length;i++){
		if (temp[i].nodeName.toUpperCase()=="TABLE") {cid=temp[i].getAttribute("id");
		$("#"+cid).fadeOut(500);}
	}
	setTimeout(function(){$("#"+ezt).fadeIn(500)},500);
}catch(e){alert(e);}}

function alert2(szov){
	if (szov=="close") {$("#alert2").hide(); return;}
	document.getElementById("alert2szov").innerHTML=szov;
	$("#alert2").show();
}
function naplo(tipus,szoveg){
	var d=new Date();
	var perc=d.getMinutes(); var mp=d.getSeconds(); if (perc<10) perc="0"+perc; if (mp<10) mp="0"+mp;
	var honap=new Array("Jan","Febr","March","Apr","May","Jun","Jul","Aug","Sept","Oct","Nov","Dec");
	var table=document.getElementById("naploka");
	var row=table.insertRow(1);
	var cell1=row.insertCell(0);
	var cell2=row.insertCell(1);
	var cell3=row.insertCell(2);
	cell1.innerHTML=honap[d.getMonth()]+" "+d.getDate()+", "+d.getHours()+":"+perc+":"+mp;
	cell2.innerHTML=tipus;
	cell3.innerHTML=szoveg;
}
function debug(tipus,szoveg){
	var d=new Date();
	var perc=d.getMinutes(); var mp=d.getSeconds(); if (perc<10) perc="0"+perc; if (mp<10) mp="0"+mp;
	var honap=new Array("Jan","Febr","March","Apr","May","Jun","Jul","Aug","Sept","Oct","Nov","Dec");
	var table=document.getElementById("debugger");
	var row=table.insertRow(1);
	var cell1=row.insertCell(0);
	var cell2=row.insertCell(1);
	var cell3=row.insertCell(2);
	cell1.innerHTML=honap[d.getMonth()]+" "+d.getDate()+", "+d.getHours()+":"+perc+":"+mp;
	cell2.innerHTML=tipus;
	cell3.innerHTML=szoveg;
}
function ujkieg(id,nev,tartalom){
/*
	Meg kell n�zni, van e m�r ilyen ID-j� kieg. megnyitva
*/
	document.getElementById("kiegs").innerHTML+=' <a href=\'javascript: nyit("'+nev+'");\'>'+nev.toUpperCase()+'</a> ';
	document.getElementById("content").innerHTML+='<table class="menuitem" width="1024px" align="center" id="'+nev+'" style="display: none">'+tartalom+'</table>';
	return;
}
function ujkieg_hang(nev,hangok){ /*Lement�sb�l be�ll�tani a checked-et*/
	var files=hangok.split(";");
	var hely=document.getElementById("hangok").getElementsByTagName("div")[0];
	var kieg=document.createElement("div"); kieg.setAttribute("style","display:table-cell; padding:10px;");
	var str="<h3>"+nev+"</h3>";
	for (var i=0;i<files.length;i++){
		str+='<input type="checkbox" name="'+files[i]+'" checked> '+files[i]+'<br>';
	}
	kieg.innerHTML=str;
	hely.appendChild(kieg);
	return;
}

init();

$(document).ready(function(){
	nyit("naplo");
	$(function() {
		$( "#alert2" ).draggable();
		$('#sugo').mouseover(function() {sugo("Ez itt a s�g�");});
		$('#fejresz').mouseover(function() {sugo("");});
	});	
}); 
void(0);