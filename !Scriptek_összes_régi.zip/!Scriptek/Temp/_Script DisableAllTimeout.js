javascript: var x = setTimeout('alert("alma");',10000); for (var i = 0 ; i < x ; i++) clearTimeout(i); void(0); //M�K�DIK

--------------------
javascript: timeouts[timeouts.length] = setTimeout('foo()', 30);

Then:-

function clear_all_timeouts()
{
        if (timeouts) for (var i in timeouts) if (timeouts[i]) clearTimeout(timeouts[i]);
        timeouts = [];
} 

[11:19:07] Bonnie Parker (Luca/Anik�): javascript: if (timers.length > 0) { tmptimers = timers; timers = []; } else { timers = tmptimers; } void(0);