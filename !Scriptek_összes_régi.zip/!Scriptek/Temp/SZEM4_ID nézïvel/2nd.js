javascript:
if (typeof(AZON)=="undefined") {alert("Ez a script SZEM4 keretrendszer�be �p�l bele. El�sz�r futtasd SZEM4-et!"); exit();}
if (typeof(IDTAMAD_LEPES)!="undefined") exit();
function szem4_IDTAMAD_figy_n_kuld(kord){try{
	TamadUpdt(IDTAMAD_REF);
	if (kord<1) return false;
	
	var celpont=document.getElementById("idtamad_testvill").getElementsByTagName("input")[1].value;
	if (celpont=="" || celpont.length<3) return false;
	
	var table=document.getElementById("idtamad_IDk");
	var d=new Date();
	if (table.rows.length>1) {var d2=new Date(table.rows[1].cells[0].innerHTML);
	d2.setMinutes(d2.getMinutes()+10);
	if (d2>d) return false;}
	
	var ok=false;
	for (var i=0;i<UNITS.length;i++){try{
		if (parseInt(IDTAMAD_REF.document.getElementById("unit_input_"+UNITS[i]).parentNode.children[2].textContent.match(/[0-9]+/g)[0])>0){
			IDTAMAD_REF.document.getElementById("unit_input_"+UNITS[i]).value=1;
			ok=true;
			break;}
		}catch(e){debug("IDTAMAD_t","ERROR: "+e);}
	}
	if (!ok) {
		naplo("IDTAMAD","Nincs egy egys�g se a megadott faluban! V�lassz m�sikat."); 
		document.getElementById("idtamad_testvill").getElementsByTagName("input")[0].value=""; 
		return false;
	}
	
	try{
		celpont=celpont.split("|");
		IDTAMAD_REF.document.forms[0].x.value=celpont[0];
		IDTAMAD_REF.document.forms[0].y.value=celpont[1];
	}catch(e){ naplo ("IDTAMAD","�rv�nytelen c�l�llom�s"+e); document.getElementById("idtamad_testvill").getElementsByTagName("input")[0].value=""; return false; }
	
	IDTAMAD_REF.document.forms[0].support.click();
	return true;
}catch(e){debug("IDTAMAD fnk","Hiba: "+e); return false;}}

function szem4_IDTAMAD_ok(){try{
	IDTAMAD_REF.document.forms[0].submit.click();
	return true;
}catch(e){
	debug("IDTAMAD ok","Hiba: "+e); 
	naplo("IDTAMAD","Nem j� c�lpont? T�r�lve.");
	document.getElementById("idtamad_testvill").getElementsByTagName("input")[1].value="";
	return false;
}}

function szem4_IDTAMAD_idkiszed(){try{
	var table=document.getElementById("idtamad_IDk");
	var lapc=IDTAMAD_REF.document.getElementById("content_value").getElementsByTagName("a");
	var patt=/action=cancel/;
	var patt2=/(id=)[0-9]+/g;
	var id=0;
	for (var k=0;k<lapc.length;k++){
		if (patt.test(lapc[k].href)) {
			if (lapc[k].parentNode.parentNode.getElementsByTagName("td")[0].innerHTML.indexOf("support")>-1){
			/*debug("ID Beir",lapc[k].href);*/
			var id=lapc[k].href.match(patt2);
			id=id[0].replace("id=","");
			lapc[k].click();
			break;}
		}
	}
	if (id==0) throw "Nem tal�ltam ID-t :(";
	
	var d=new Date();
	var row=table.insertRow(1);
	var cell1=row.insertCell(0);
	var cell2=row.insertCell(1);
	cell1.innerHTML=d;
	cell2.innerHTML=id;
	return true;
}catch(e){debug("IDTAMAD_idki","Hiba: "+e); return false;}}

function szem4_IDTAMAD_motor(){try{
	var nexttime=60000;
	if (BOT||IDTAMAD_PAUSE) {nexttime=5000;} else {
		if (IDTAMAD_HIBA>10) {IDTAMAD_HIBA=0; IDTAMAD_GHIBA++; if(IDTAMAD_GHIBA>3) {if (IDTAMAD_GHIBA>5) {naplo("Glob�l","Nincs internet? Folyamatos hiba farmol�n�l"); nexttime=60000; playSound("bot2"); } IDTAMAD_REF.close();} IDTAMAD_LEPES=0;}
		switch (IDTAMAD_LEPES){
			case 0: /*Mindek�pp lapmegnyit�s. Ha van (�rv�nyes) indul� koord megadva, akkor azt a falut nyitjuk*/
				KOORD=-1;
				if (document.getElementById("idtamad_testvill").getElementsByTagName("input")[0].value!="") KOORD=koordTOid(document.getElementById("idtamad_testvill").getElementsByTagName("input")[0].value); 
				if (KOORD<1) {document.getElementById("idtamad_testvill").getElementsByTagName("input")[0].value="";
					if (KOORD==0) naplo("ID_Tamad","�rv�nytelen koordin�ta van megadva indul� falunak");
					IDTAMAD_REF=window.open(VILL1ST,AZON+"_idazon");
				} else {
					IDTAMAD_REF=window.open(VILL1ST.replace(/village=[0-9]+/,"village="+KOORD).replace("screen=overview","screen=place"),AZON+"_idazon");
				}
				 IDTAMAD_LEPES=1;
				 break;
			/*PM3: 1= csak bej�v�t n�z; 2=ID-t is....*/
			case 1: if (isPageLoaded(IDTAMAD_REF,-1,"screen")) {IDTAMAD_HIBA=0; IDTAMAD_GHIBA=0;
					PM3=szem4_IDTAMAD_figy_n_kuld(KOORD); if (PM3) IDTAMAD_LEPES=2; else IDTAMAD_LEPES=0;
					nexttime=1000;
				} else {IDTAMAD_HIBA++;}
				break;
			case 2: if (isPageLoaded(IDTAMAD_REF,KOORD,"try=confirm")) {IDTAMAD_HIBA=0; IDTAMAD_GHIBA=0;
					PM3=szem4_IDTAMAD_ok(); if (PM3) IDTAMAD_LEPES=3; else IDTAMAD_LEPES=0; 
					nexttime=1000;
				} else {IDTAMAD_HIBA++;}
				break;
			case 3: if (isPageLoaded(IDTAMAD_REF,KOORD,"not try=confirm")) {IDTAMAD_HIBA=0; IDTAMAD_GHIBA=0;
					szem4_IDTAMAD_idkiszed(); IDTAMAD_LEPES=0; 
					nexttime=1000;
				} else {IDTAMAD_HIBA++;}
				break;
			default: IDTAMAD_LEPES=0;
		}
	}
}catch(e){debug("IDTamad_m",e);}
	var inga=100/((Math.random()*40)+80);
	nexttime=Math.round(nexttime*inga);
	setTimeout("szem4_IDTAMAD_motor()",nexttime);
	return;
}


var IDTAMAD_PAUSE=false;
var IDTAMAD_LEPES=0;
var IDTAMAD_REF;
var IDTAMAD_HIBA=0; var IDTAMAD_GHIBA=0;
var PM3; var KOORD=0;
szem4_IDTAMAD_motor();

/*-----------------�P�T�--------------------*/
function szem4_EPITO_getlista(){
	var ret='<select>';
	var Z=document.getElementById("epit").getElementsByTagName("table")[0].rows;
	for (var i=1;i<Z.length;i++){
		ret+='<option value="'+Z[i].cells[0].textContent+'">'+Z[i].cells[0].textContent+'</option> ';
	}
	ret+='</select>'; 
	return ret;
}

function szem4_EPITO_ujFalu(){try{
	var f_nev=prompt("Mik az �p�tend� falu(k) koordin�t�i?");
	if (f_nev=="" || f_nev==null) return;
	f_nev=f_nev.match(/[0-9]{1,3}(\|)[0-9]{1,3}/g);
	var Z=document.getElementById("epit_lista"); var str="";
	var lista=szem4_EPITO_getlista();
	for (var i=0;i<f_nev.length;i++){
		var vane=false;
		for (var j=1;j<Z.rows.length;j++){
			if (Z.rows[j].cells[0].textContent==f_nev[i]) vane=true;
		} if (vane) {str+="DUP:"+f_nev[i]+", "; continue;}
		if (koordTOid(f_nev[i])==0) {str+="NL:"+f_nev[i]+", "; continue;}
		
		var ZR=Z.insertRow(-1);
		var ZC=ZR.insertCell(0); ZC.innerHTML=f_nev[i];
			ZC=ZR.insertCell(1); ZC.innerHTML=lista;
			ZC=ZR.insertCell(2); var d=new Date(); d.setSeconds(d.getSeconds()+30); ZC.innerHTML=d;
			ZC=ZR.insertCell(3); ZC.innerHTML="<i>M�g nem tudom</i>";
	}
	if (str!="") alert2("Dupla megad�sok/nem l�tez� faluk kisz�rve: "+str);
	return;
}catch(e){alert2("�j falu(k) felv�telekori hiba:\n"+e);}}

function szem4_EPITO_uj(){try{
	var cs_nev=prompt("Mi legyen az �j csoport neve?\n(A n�v nem tartalmazhat ; jelet!)");
	if (cs_nev=="" || cs_nev==null) return;
	if (cs_nev.indexOf(";")>-1) throw "Mondtam hogy nem lehet benne ;!!!";
	var Z=document.getElementById("epit").getElementsByTagName("table")[0];
	var ZR=Z.insertRow(-1);
	var ZC=ZR.insertCell(0); ZC.innerHTML=cs_nev;
		ZC=ZR.insertCell(1); ZC.innerHTML=Z.rows[1].cells[1].innerHTML;
	
	var Z=document.getElementById("epit_lista").rows;
	for (var i=1;i<Z.length;i++){
		var Z2=Z[i].cells[1].getElementsByTagName("select")[0];
		var option=document.createElement("option");
		option.text=cs_nev;
		Z2.add(option);
	}
	return;
}catch(e){alert2("�j csoport felv�telekori hiba:\n"+e);}}

function szem4_EPITO_cscheck(alma){try{
	var Z=alma.parentNode.getElementsByTagName("input")[0].value;
	Z=Z.split(";");
	
	var epuletek=new Array("main","barracks","stable","garage","church_f","church","smith","snob","place","statue","market","wood","stone","iron","farm","storage","hide","wall","MINES");
	for (var i=0;i<Z.length;i++){
		if (epuletek.indexOf(Z[i].match(/[a-zA-Z]+/g)[0])>-1) {} else throw "Nincs ilyen �p�let: "+Z[i].match(/[a-zA-Z]+/g)[0];
		if (parseInt(Z[i].match(/[0-9]+/g)[0])>30) throw "T�l magas �p�letszint: "+Z[i];
	}
	alert2("Minden OK");
}catch(e){alert2("Hib�s lista:\n"+e);}}


function szem4_EPITO_csopToList(csoport){try{
	var Z=document.getElementById("epit").getElementsByTagName("table")[0].rows;
	for (var i=1;i<Z.length;i++){
		if (Z[i].cells[0].textContent==csoport) return Z[i].cells[1].getElementsByTagName("input")[0].value;
	}
	return ";";
}catch(e){debug("epito_csopToList",e);}}

function szem4_EPITO_Wopen(){try{
	/*Eredm�ny: faluID, teljes �p�tend� lista, pointer a sorra*/
	var TT=document.getElementById("epit_lista").rows;
	var now=new Date();
	for (var i=1;i<TT.length;i++){
		var datum=new Date(TT[i].cells[2].textContent);
		if (datum<now) {
			var lista=szem4_EPITO_csopToList(TT[i].cells[1].getElementsByTagName("select")[0].value);
			return [koordTOid(TT[i].cells[0].textContent),lista,TT[i]];
		}
	}
	return [0,";"];
}catch(e){debug("Epito_Wopen",e);}}

function szem4_EPITO_addIdo(sor,ido){try{
	if (ido=="del") { /*HIB�S! T�R�LNI KELL*/
		var d=new Date();
		d.setMinutes(d.getMinutes()+500);
		sor.cells[2].innerHTML=d;
	} else {
		var d=new Date();
		d.setMinutes(d.getMinutes()+ido);
		sor.cells[2].innerHTML=d;
	}
	return true;
}catch(e){debug("epito_addIdo",e); return false;}}

function szem4_EPITO_IntettiBuild(pcel){try{
	/*Jelenleg: �p�t�s alatt �ll�k --> blista*/
	try{var sor=EPIT_REF.document.getElementById("buildqueue").rows;
/*(!)PONTOS�S*/ if (sor.length>5) { szem4_EPITO_addIdo(PMEP[2],100);  return "overflow";} 
	
	
	var blista="";
	for (var i=1;i<sor.length;i++){
		try{blista+=sor[i].cells[0].getElementsByTagName("img")[0].src.match(/[A-Za-z0-9]+\.(png)/g)[0].replace(/[0-9]+/g,"").replace(".png","");}catch(e){}
		blista+=";";
	}
	}catch(e){var blista=";";}
	
	/*K�vetkez� �p�let meghat�roz�sa: �p�tend� �p�let ---> str*/
	var GD=EPIT_REF.game_data.village.buildings;
	var cel=pcel.split(";");
	var jel=new Array(); /*�p�letek szintjei*/
	var ijel=new Array(); /*�p�let t�pusa*/
	
	var i=-2;
	var ss=blista.split(";");
	for (var elem in GD){
		i++; if (i==-1) continue;
		jel[i]=GD[elem];
		ijel[i]=elem;
		for (var g=0;g<ss.length;g++){if (ijel[i]==ss[g]) {jel[i]++;ss[g]=""}}
	}
	var str=""; var vizsga=""; var mine=new Array(0,0,0);
	for (i=0;i<cel.length;i++){
		vizsga=cel[i].split(" ")[0];
		for (var j=0;j<ijel.length;j++){ /*Keress�k a megfelel� �p�let jelenlegi szintj�t*/
			if (ijel[j]==vizsga) {	/*Megvan, jelenlegi szintje jel[j]*/
				/*alert("C�l: "+cel[i]+"\n Jelenleg: "+ijel[j]+" - "+jel[j]);*/
				for (var k=0;k<parseInt(cel[i].split(" ")[1])-jel[j];k++){
					str+=vizsga+";";
				}
				if (parseInt(cel[i].split(" ")[1])-jel[j]>0) jel[j]=parseInt(cel[i].split(" ")[1]);
			}
		}
		if (vizsga=="MINES"){
			/*3 indexet keresni: wood;stone;iron-�t*/
			for (var j=0;j<ijel.length;j++){
				if (ijel[j]=="wood") mine[0]=j;
				if (ijel[j]=="stone") mine[1]=j;
				if (ijel[j]=="iron") mine[2]=j;
			}
			for (var j=0;j<=parseInt(cel[i].split(" ")[1]);j++){
				for (var k=0;k<3;k++){
					if (jel[mine[k]] < j) {
						str+=k+";";
						jel[mine[k]]++;
					}
				}
			}
			str=str.replace(/0/g,"wood");
			str=str.replace(/1/g,"stone");
			str=str.replace(/2/g,"iron");
		}
		if (str!="") {
			if (str.indexOf(";")>-1) str=str.split(";")[0];
			break;
		}
	}
	if (str.length<4) {/*K�SZ, T�RL�S*/ szem4_EPITO_addIdo(PMEP[2],"del"); return;}
	/* �p�t�s "iself" */
	var build=str;
	var a;
	if (a=EPIT_REF.document.getElementById("main_buildlink_"+build)) {
		if (EPIT_REF.$("#main_buildlink_"+build).is(":visible")) {
			a.click(); 
			szem4_EPITO_addIdo(PMEP[2],1); /*Sikeres Esem�ny lejelent�se SZEM4-nek: +30mp*/
		} else {
			/*Jelenleg nem �p�thet�. Mi�rt?*/
			var elements=new Array(parseInt(EPIT_REF.document.getElementById("storage").textContent),parseInt(EPIT_REF.document.getElementById("pop_max_label").textContent)-parseInt(EPIT_REF.document.getElementById("pop_current_label").textContent)); /*rakt�r, szabad hely*/
			a=a.parentNode.parentNode.cells;
			var needs=new Array(parseInt(a[1].textContent),parseInt(a[2].textContent),parseInt(a[3].textContent),parseInt(a[5].textContent)); /*nyersek, tanya*/
			var ok="";
			if (needs[0]>elements[0] || needs[1]>elements[0] || needs[2]>elements[0]) {ok="storage";}
			else if (needs[3]>elements[1]) {ok="farm";}
/*(!)PONTOS�S*/if (ok=="") {szem4_EPITO_addIdo(PMEP[2],60); return;}
			if (ok==build) {szem4_EPITO_addIdo(PMEP[2],60);return;} else {
				if (ok=="farm" && parseInt(EPIT_REF.game_data.village.buildings.farm)>=30) {
					/*Nem lehet t�bb �p�letet �p�teni, mert megtelt a tanya*/ 
					szem4_EPITO_addIdo(PMEP[2],200);
					naplo("�p�t�","Nem lehet tov�bb �p�teni (az egyik faluba), mert a tanya max-on �n megtelt");
				} else if (EPIT_REF.$("#main_buildlink_"+ok).is(":visible")) EPIT_REF.document.getElementById("main_buildlink_"+ok).click(); else szem4_EPITO_addIdo(PMEP[2],60);
				}
			/*alert(a.parentNode.parentNode.innerHTML);*/
		}
	} else {
		throw "Nem l�tez� �p�let: "+build;
	}
}catch(e){debug("epit_IntelliB",e);}}

function szem4_EPITO_motor(){try{
	var nexttime=2000;
	if (BOT||EPIT_PAUSE) {nexttime=5000;} else {
	if (EPIT_HIBA>10) {EPIT_HIBA=0; EPIT_GHIBA++; if(EPIT_GHIBA>3) {if (EPIT_GHIBA>5) {naplo("Glob�l","Nincs internet? Folyamatos hiba az �p�t�n�l"); nexttime=60000; playSound("bot2");} EPIT_REF.close();} EPIT_LEPES=0;}
	switch (EPIT_LEPES){
		case 0: PMEP=szem4_EPITO_Wopen();
				if (PMEP[0]>0){
				EPIT_REF=window.open(VILL1ST.replace("screen=overview","screen=main").replace(/village=[0-9]+/,"village="+PMEP[0]),AZON+"_SZEM4EPIT"); 
				EPIT_LEPES=1;} break;
		case 1: if (isPageLoaded(EPIT_REF,PMEP[0],"screen=main")) {EPIT_HIBA=0; EPIT_GHIBA=0;
					/*PMEP=*/szem4_EPITO_IntettiBuild(PMEP[1]);
				} else {EPIT_HIBA++;}
				EPIT_LEPES=0;
				break;
		default: EPIT_LEPES=0;
	}
	
	/*
	 1.) Megn�zz�k melyik falut kell megnyitni -->f�hadi.
	 2.) <5 sor? Mit kell venni? Lehets�ges e? Ha nem, lehet e valamikor az �letbe? (tanya/rakt�r-vizsg�lat)
	 3.) Nincs! xD
	*/}
}catch(e){debug("Epito motor",e); EPIT_LEPES=0;}
var inga=100/((Math.random()*40)+80);
nexttime=Math.round(nexttime*inga);
setTimeout("szem4_EPITO_motor()",nexttime);}

ujkieg_hang("�p�t�","epites;falu_kesz");
ujkieg("epit","�p�t�",'<tr><td><h2 align="center">�p�t�si list�k</h2><table align="center" class="vis" style="border:1px solid black;color: black;"><tr><th>Csoport neve</th><th style="width:800px">�p�t�si lista</th></tr><tr><td>Alap�rtelmezett</td><td><input type="text" value="main 10;storage 10;wall 10;main 15;wall 15;storage 15;farm 10;main 20;wall 20;MINES 10;smith 5;barracks 5;stable 5;main 15;storage 20;farm 20;market 10;main 22;smith 12;farm 25;storage 28;farm 26;MINES 24;market 19;barracks 15;stable 10;garage 5;MINES 26;farm 28;storage 30;barracks 20;stable 15;farm 30;barracks 25;stable 20;MINES 30;smith 20;snob 1" size="125"><a onclick="szem4_EPITO_cscheck(this)" style="color:blue; cursor:pointer;"> OK?</a></td></tr></table><p align="center"><a href="javascript: szem4_EPITO_uj()" style="color:white;text-decoration:none;"><img src="'+pic("plus.png")+' height="23px"> �j csoport</a></p></td></tr><tr><td><h2 align="center">�p�tend� faluk</h2><table align="center" class="vis" style="border:1px solid black;color: black;width:800px" id="epit_lista"><tr><th>Falu koord.</th><th>Haszn�lt lista</th><th>Return</th><th>Terv...</th></tr></table><p align="center"><a href="javascript: szem4_EPITO_ujFalu()" style="color:white;text-decoration:none;"><img src="'+pic("plus.png")+'"height="23px"> �j falu(k)</a></p></td></tr>');

/*Table IDs:  farm_opts; farm_honnan; farm_hova*/
var EPIT_LEPES=0;
var EPIT_REF; var EPIT_HIBA=0; var EPIT_GHIBA=0;
var PMEP; var EPIT_PAUSE=false;
szem4_EPITO_motor();
void(0);