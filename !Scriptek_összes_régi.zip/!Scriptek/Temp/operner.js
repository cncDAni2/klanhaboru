javascript: 
function FRM_determiner(){
	var x=document.getElementById("TAMAD");
	var talal=0;
	for (var i=1;i<x.rows.length;i++){
		if (x.rows[i].cells[0].innerHTML=="") {
			talal = x.rows[i].cells[1].innerHTML; 
			x.rows[i].cells[0].innerHTML="X"; 
			break;}
	}
	return talal;
}

function miakordija(ennek){
	var X=document.getElementById("TAMAD");
	var ret="";
	for (var i=1;i<X.rows.length;i++){
		if (X.rows[i].cells[1].innerHTML==ennek) {
		ret=X.rows[i].cells[2].innerHTML;
		break;}
	}
	return ret;
} function TO_determiner(innen){ try{
	var MINIMAL="";
	var x=document.getElementById("FARM");
	var koord=miakordija(innen);
	var FX=koord.match(/[0-9]+/g)[0]; var FY=koord.match(/[0-9]+/g)[1];
	var tavok=new Array();
	for (var i=1;i<x.rows.length;i++) {
		TX=x.rows[i].cells[1].innerHTML.match(/[0-9]+/g)[0];
		TY=x.rows[i].cells[1].innerHTML.match(/[0-9]+/g)[1];
		tavok[i-1]=Math.abs( Math.sqrt( Math.pow(FX-TX,2) + Math.pow(FY-TY,2) ) );
		naplo(TX+"|"+TX+" - "+FX+"|"+FY+" t�vols�g: "+tavok[i-1]);
		/*abszol�t�rt�k( (  (FX-TX)^2 + (FY-TY)^2   )^0.5 )*/
	}
	var index=tavok; /*Innen n�zz�k ut�lag az indexeket*/
	var j=0; var min=tavok[tavok.length]; var temp=0;
	for (i=0;i<tavok.length;i++){
		min=tavok[tavok.length];
		for (j=i;j<tavok.length-1;j++){
			if (tavok[j]<tavok[min]) min=j;
		}
		/*csere i-min*/
		temp=tavok[i]; tavok[i]=tavok[j]; tavok[j]=temp;
	}
	}catch(e){alert(e);}
}

function nullaz_tamad(){
	var x=document.getElementById("TAMAD");
	for (var i=1;i<x.rows.length;i++)
			x.rows[i].cells[0].innerHTML=""; 
}

INNEN=FRM_determiner();
if (INNEN==0) setTimeout("nullaz_tamad()",10000);
IDE=TO_determiner(INNEN);
naplo(INNEN+"-b�l ind�tok");