javascript:
function sugo(str){
		document.getElementById("sugo").innerHTML=str;
		return;
}
function nyit(ezt){try{
	var lista=new Array("farm","piac","naplo","debug");
	for (var i=0;i<lista.length;i++){
		$("#"+lista[i]).fadeOut(500);
	}
	setTimeout(function(){$("#"+ezt).fadeIn(500)},500);
}catch(e){alert(e);}}

function chgborder(ezt){
	try{
		if (ezt.getAttribute("border")=="1") ezt.setAttribute("border","0");
			else ezt.setAttribute("border","1");
	} catch(e) {alert(e);}
}
	function szamchg(ezt){
		try{var ujertek=prompt("�j �rt�k? ");
		if (ujertek==null || parseInt(ujertek)==NaN || isNaN(ujertek)) return;
		if (ujertek>50) return;
		ezt.innerHTML=ujertek;
		}catch(e){alert("hiba: "+e);}
		return;
	}
document.getElementsByTagName("body")[0].innerHTML='<table width="1024px" align="center" class="fej" style="background-image:url(\'http://cncdani2.freeiz.com/pic/szem4/header_felhok.jpg\');"> 	<tr><td width="70%" id="fejresz">C�M</td><td id="sugo">S�G�<br><br><br><br></td></tr> 	<tr><td colspan="2" id="menuk" style="border-top: 2px solid black;"> 	 		<div class="divrow" style="width: 800px"> 		<span class="divcell" style="text-align:left; width:724px;"> 			<a href=\'javascript: nyit("farm");\'>MEN�1</a> 			<a href=\'javascript: nyit("piac");\'>MEN�2</a> 			, ...  		</span> 		<span class="divcell" style="text-align:right; width:300px"> 			<a href=\'javascript: nyit("naplo");\'>Napl�</a> 			<a href=\'javascript: nyit("debug");\'>Debug</a> 			nyelv,  			minijelz�k, 			hangbe�ll�t�s men� (egy k�p) 		</span></div> 		 	</td></tr> </table> <table class="menuitem" width="1024px" align="center" id="farm" style="display: none"> 	<tr><td rowspan="2">  	<table id="TO"  class="vis"><tbody> <!-- Dupl�n van a "FARM"--> 	<th> 	<th onmouseover=\'sugo("Farmoland� falu koordija");\'>Koord</th> 	<th onmouseover=\'sugo("Becs�lt nyersanyag jelenleg");\'>Nyers</th> 	<th onmouseover=\'sugo("Fa, agyag, vas");\'>B�ny�k</th> 	<th onmouseover=\'sugo("Fal szintje");\'>Fal</th> 	<th onmouseover=\'sugo("");\'>Frissess�g</th> 	<th onmouseover=\'sugo("J�t�kos e?");\'>(!)</th> 	</th> 	</tbody></table> 	<!-- 	<div id="TO"> 		<div class="divrow" style="border: 1px solid green"> 			<span class="divcell">Koord</span> 			<span class="divcell">Nyers</span> 			<span class="divcell">B�ny�k</span> 			<span class="divcell">Fal</span> 			<span class="divcell">Adatfrissess�g</span> 		</div> 	</div> 	-->  	</td><td  rowspan="2">  	<table id="FROM" class="vis"><tbody> 	<tr><th onmouseover=\'sugo("�res e?");\'>OUT (id�)</th> 		<th onmouseover=\'sugo("Innen indul a t�mad�s, ID");\'>ID</th> 		<th onmouseover=\'sugo("Innen indul a t�mad�s, koord");\'>Koord</th> 		<th onmouseover=\'sugo("Egys�gek");\'>WithWhat</th></tr> 	</tbody></table>  	</td><td>  	<div class="divrow"> 		<span class="divcell"> 			<textarea id="farmlist" cols="15" rows="8" onmouseover=\'sugo("")\'></textarea> 		</span> 		<span class="divcell"> 			<textarea id="farmlist" cols="15" rows="8" onmouseover=\'sugo("")\'></textarea> 		</span> 	</div> 	<div class="divrow"> 		<span class="divcell"> 			<button type="button" onclick="feltolt()">To Farm</button> 		</span> 		<span class="divcell"> 			<button type="button" onclick="feltolt2()">From farm</button> 		</span> 	</div>   	</td></tr> 	<tr><td>  	<b>Settings</b> (+ablakkezel� inf�)<br> 	<b>K�ldend� egys�gek alap�rtelmezett:</b><br> 	<img src="http://cdn2.tribalwars.net/graphic/unit/unit_spear.png" border="1" onclick="javascript: chgborder(this)"> &nbsp; 	<img src="http://cdn2.tribalwars.net/graphic/unit/unit_sword.png" border="1" onclick="javascript: chgborder(this)">&nbsp; 	<img src="http://cdn2.tribalwars.net/graphic/unit/unit_axe.png" border="1" onclick="javascript: chgborder(this)">&nbsp; 	<img src="http://cdn2.tribalwars.net/graphic/unit/unit_archer.png" border="1" onclick="javascript: chgborder(this)">&nbsp; 	<img src="http://cdn2.tribalwars.net/graphic/unit/unit_light.png" border="1" onclick="javascript: chgborder(this)">&nbsp; 	<img src="http://cdn2.tribalwars.net/graphic/unit/unit_marcher.png" border="1" onclick="javascript: chgborder(this)">&nbsp; 	<img src="http://cdn2.tribalwars.net/graphic/unit/unit_heavy.png" border="1" onclick="javascript: chgborder(this)">&nbsp; 	<br> 	<b>Max t�v/gyalog:</b> <p style="display:inline" ondblclick="szamchg(this);">6</p><br> 	<b>Content-handler</b><br> 	<table id="chandler" class="vis"><tr><th>1</th><th>2</th><th>3</th><th>4</th><th>5</th></tr> 	<tr><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td></tr></table> 	</tr></td> </table> <table class="menuitem" width="1024px" align="center" id="piac" style="display: none"> <tr><td>Piac kiegyensulyoz�j�</td></tr> </table>  <table class="menuitem" width="1024px" align="center" id="naplo" style="display: none"> <tr><td> 	<h1 align="center">Napl�</h1><br> 	<br> 	<table align="center" class="vis" id="naplo"><tr><th>D�tum</th><th>Script</th><th>Esem�ny</th></tr></table> </td></tr> </table>  <table class="menuitem" width="1024px" align="center" id="debug" style="display: none"> <tr><td> 	<h1 align="center">DeBugger</h1><br> 	<br> 	<table align="center" class="vis" id="debug"><tr><th>D�tum</th><th>Script</th><th>Esem�ny</th></tr></table> </td></tr> </table>';
document.getElementsByTagName("style")[0].innerHTML='body{  	background: #111;  }  table.fej{  	padding:1px;   	margin:auto;  	color: white;  	border: 1px solid yellow;  }  table.menuitem{  	vertical-align:top;  	text-align: top;  	padding: 20px;  	margin:auto;  	color: white;  	border: 1px solid yellow;  }  table.menuitem td{  	padding: 0px;  	vertical-align:top;  }    table{  	padding: 0px;  	margin: auto;  	color: white;  	border: 1px solid green;  }    textarea{  	background-color: #020;  	color:white;  }  .divrow{  	display: table-row;  }  .divcell {  	display: table-cell;  	text-align: center;  	vertical-align:top;  }    a{  	color: white;  }  img{  	border-color: grey;  	padding:1px;  } table.vis{ 	color:black;}';
document.title="SZEM IV";
nyit("farm");
void(0);