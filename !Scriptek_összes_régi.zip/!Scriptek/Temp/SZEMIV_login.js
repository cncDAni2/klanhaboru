javascript:
/*Check window.name==""?*/
if (document.getElementById("loginwin")) exit(0);
var x = setTimeout('',100); for (var i = 0 ; i < x ; i++) clearTimeout(i);
document.getElementsByTagName("body")[0].innerHTML+='<div id="loginwin" style="width: 300px; height: 140px; background-color: #60302b; color: yellow; font-weight:bold; position: absolute; left:30%; top:30%; border:3px solid black; font-size: 120%; font-family:Lucida Sans Unicode; padding: 40px; z-index:200;">\
<p id="con">Connecting ... </p>\
<p id="auth">Authentication ... </p>\
<p id="wdata">Loading world data ... </p>\
<p id="icache">Preloading images ... </p>\
<p id="load">Loading SZEM IV ... </p></div>';
$(function() {
        $( "#loginwin" ).draggable();
});

var url = 'http://cncdani2.freeiz.com/SZEM_IV/00login.php';
scr = $('<script type="text/javascript" />').attr('src', url);
$(document).append(scr);
void(0);