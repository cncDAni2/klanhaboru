javascript: var x = setTimeout('',100); for (var i = 0 ; i < x ; i++) clearTimeout(i);

function RAISE(){
	try{x=document.getElementById("FARM");
	var uj=0;
	for (var i=1;i<x.rows.length;i++){
		uj=parseInt(x.rows[i].cells[2].innerHTML)+parseInt(document.getElementById("ALAP").innerHTML/60);
		x.rows[i].cells[2].innerHTML=uj;
	}
	var TT=setTimeout("RAISE()",60000);
	}catch(e){alert(e);}
	return;
} RAISE();
void(0);