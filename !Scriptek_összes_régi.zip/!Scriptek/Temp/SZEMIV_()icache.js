javascript:
function fnGetConfig(){
	try{var oRequest=new XMLHttpRequest();
	var sURL="http://"+window.location.hostname+"/interface.php?func=get_config";
	oRequest.open("GET",sURL,0);
	oRequest.send(null);
	if(oRequest.status==200)return oRequest.responseXML;
	}catch(e){alert(e);}
	alert("Error executing XMLHttpRequest call to get Config!");
}
try{
var xmlDoc=fnGetConfig();
var WSpeed=xmlDoc.getElementsByTagName("speed")[0].childNodes[0].nodeValue;
var USpeed=xmlDoc.getElementsByTagName("unit_speed")[0].childNodes[0].nodeValue;
}catch(e){alert("ZZ: " + e);}