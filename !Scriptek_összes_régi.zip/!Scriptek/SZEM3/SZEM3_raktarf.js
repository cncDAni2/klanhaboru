javascript: 
function res_check(){
	try{
	for (rf=1;rf<11;rf++){
		if (document.getElementById(rf).innerHTML!=""){
			var lapref=window["lap"+rf];
			var fa=lapref.document.getElementById("wood").innerHTML; fa=parseInt(fa);
			var agyag=lapref.document.getElementById("stone").innerHTML; agyag=parseInt(agyag);
			var vas=lapref.document.getElementById("iron").innerHTML; vas=parseInt(vas);
			var kapac=lapref.document.getElementById("storage").innerHTML; kapac=parseInt(kapac);
			var max=Math.max(fa,agyag,vas);
			if (Math.round(kapac*0.85)<=max) {
				if (kapac==max) {
					naplo("szem","Raktarfigyelo: Beltelt a raktar a "+rf+" auto-farm hely�n.");
					/*T�rold le s�tibe. N�V=SZEM3_raktarX, value="van", expdate=20p. El�tte n�zze meg hogy van e ilyen bejegyz�s. HANG mindig legyen */
					if (hang==1) playSound("Raktar02"); if (hang==2) playSmartSound(lapref,"Raktar02");
				} else {
					if (hang==1) playSound("Raktar01"); if (hang==2) playSmartSound(lapref,"Raktar01");
				}
	}}}}catch (e) {addError(1,"raktarf",lapref);}
}
	
function raktarf(){
		res_check();
		iraktarf=setTimeout("raktarf()",1000*60*5);
	}
raktarf();	 
void(0);	
