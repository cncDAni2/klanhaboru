javascript:
function ujertek(ez){
	try{var a=prompt("nyers?");
	if (a==null) return;
	ez.text(a);
	}catch(e){alert("Hiba:" + e);}
	return;
}
$("#1_T tr td:nth-child(5)").dblclick(function(){ujertek($(this));});
$("#2_T tr td:nth-child(5)").dblclick(function(){ujertek($(this));});
$("#3_T tr td:nth-child(5)").dblclick(function(){ujertek($(this));});
$("#4_T tr td:nth-child(5)").dblclick(function(){ujertek($(this));});
$("#5_T tr td:nth-child(5)").dblclick(function(){ujertek($(this));});
$("#6_T tr td:nth-child(5)").dblclick(function(){ujertek($(this));});
$("#7_T tr td:nth-child(5)").dblclick(function(){ujertek($(this));});
$("#8_T tr td:nth-child(5)").dblclick(function(){ujertek($(this));});
$("#9_T tr td:nth-child(5)").dblclick(function(){ujertek($(this));});
$("#10_T tr td:nth-child(5)").dblclick(function(){ujertek($(this));});
void(0);
