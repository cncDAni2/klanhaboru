javascript:
function openMail(){
		try{
		UKlap=lapkeres();
		if (UKlap==0){
			Ulap=window.open(WEBPAGE,"Uzenet");
		} else {Ulap=window["lap"+Flap];}
		return Ulap;
		} catch(e){ naplo("hiba","�zenetfigyel�: Hiba lapnyit�skor"); }
}

function mailkeres(uziref){
	try{
	if(uziref.document.readyState!="complete") throw "BeNemToltottLap";
	volte=getCookie("SZEM3_uzi");
	var x=uziref.document.links; var i=0;
	var talal=false;
	var uzi=parseInt(game_data.player.new_igm); if (uzi==1) talal=true;
	if (talal) {if (hang==1) playSound("Uzenet"); if (hang==2) playSmartSound(lapu,"Uzenet");}
	if (talal && volte=="Nem") {
		naplo("uzenet","Uj uzenete erkezett");
		setCookie("SZEM3_uzi","Van");
		}
	if (!talal && volte=="Van") setCookie("SZEM3_uzi","Nem"); /*�zenet elolvasva*/
	addError(-1,"uzif",uziref);
	}catch(e) {addError(1,"uzif",uziref);}
}

function MainMail(){
	lapu=openMail();
	uzido=(Math.floor(Math.random()*61)+20)*1000;;
	setTimeout("mailkeres(lapu)",3000);
	iuzif=setTimeout("MainMail()",uzido);
}
setCookie("SZEM3_uzi","Nem");
MainMail();
void(0);
