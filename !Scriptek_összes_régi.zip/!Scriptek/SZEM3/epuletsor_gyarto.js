javascript:
var cel="main 10;wall 10;main 15;wall 15;main 20;wall 20;storage 10;farm 10;main 10;MINES 10;smith 5;barracks 5;stable 5;main 15;storage 20;farm 20;market 10;main 22;smith 12;farm 25;storage 28;farm 26;MINES 24;market 19;barracks 15;stable 10;garage 5;MINES 26;farm 28;storage 30;barracks 20;stable 15;farm 30;barracks 25;stable 20;MINES 30;smith 20;snob 1";

var a=prompt("Mi van jelenleg bet�ve az �p�t�si sorba? (MAX 1, t�bbit m�gs�zd) �p�let nev�t a k�dja alapj�n add meg! (pl.: main)");
var str="";

var GD=game_data.village.buildings;
cel=cel.split(";");
var jel=new Array(); /*�p�letek szintjei*/
var ijel=new Array(); /*�p�let t�pusa*/

try{
var i=-2;
for (var elem in GD){
	i++;
	if (i==-1) continue;
	jel[i]=GD[elem];
	ijel[i]=elem;
	if (ijel[i]==a) {jel[i]++;a=""}
}

var vizsga="";
var mine=new Array(0,0,0);
for (i=0;i<cel.length;i++){
	vizsga=cel[i].split(" ")[0];
	for (var j=0;j<ijel.length;j++){ /*Keress�k a megfelel� �p�let jelenlegi szintj�t*/
		if (ijel[j]==vizsga) {	/*Megvan, jelenlegi szintja jel[j]*/
			/*alert("C�l: "+cel[i]+"\n Jelenleg: "+ijel[j]+" - "+jel[j]);*/
			for (var k=0;k<parseInt(cel[i].split(" ")[1])-jel[j];k++){
				str+=vizsga+";";
			}
			if (parseInt(cel[i].split(" ")[1])-jel[j]>0) jel[j]=parseInt(cel[i].split(" ")[1]);
		}
	}
	if (vizsga=="MINES"){
		/*3 indexet keresni: wood;stone;iron-�t*/
		for (var j=0;j<ijel.length;j++){
			if (ijel[j]=="wood") mine[0]=j;
			if (ijel[j]=="stone") mine[1]=j;
			if (ijel[j]=="iron") mine[2]=j;
		}
		for (var j=0;j<=parseInt(cel[i].split(" ")[1]);j++){
			for (var k=0;k<3;k++){
				if (jel[mine[k]] < j) {
					str+=k+";";
					jel[mine[k]]++;
				}
			}
		}
		str=str.replace(/0/g,"wood");
		str=str.replace(/1/g,"stone");
		str=str.replace(/2/g,"iron");
	}
}

str=GD.village+"."+str+"_";

$("body").append('<div style="background-color: white; color: #006; position: absolute; left:10%; top:260px; border:3px solid blue; padding: 5px; z-index:200;">\
	<b>�p�tkez�si lista �ssze�ll�tva, export�lja SZEM3 �p�t�j�be<br>\
	<textarea id="szem3_epit_lista" cols="80" rows="5">'+str+'</textarea><br>\
	C&amp;C M�hely ~ cncDAni2</div>');
	document.getElementById("szem3_epit_lista").select();
}catch(e){alert(e);}
void(0);