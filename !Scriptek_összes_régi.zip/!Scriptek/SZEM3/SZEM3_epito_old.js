javascript:
function epuletek(ezt){
	var bovebb="";
	switch (ezt) {
		case 'barracks': bovebb='Barakk'; break;
		case 'church': bovebb='Templom'; break;
		case 'farm': bovebb='Tanya'; break;
		case 'garage': bovebb='Muhely'; break;
		case 'hide': bovebb='Rejtekhely'; break;
		case 'iron': bovebb='Vasbanya'; break;
		case 'main': bovebb='Fohadiszallas'; break;
		case 'market': bovebb='Piac'; break;
		case 'place': bovebb='Gyulekezohely'; break;
		case 'smith': bovebb='Kovacsmuhely'; break;
		case 'snob': bovebb='Akademia'; break;
		case 'stable': bovebb='Istallo'; break;
		case 'statue': bovebb='Szobor'; break;
		case 'stone': bovebb='Agyagbanya'; break;
		case 'storage': bovebb='Raktar'; break;
		case 'wall': bovebb='Fal'; break;
		case 'wood': bovebb='Fatelep'; break;
		default: bovebb="HIBA"; break;
	}
	return '<img src="http://cncdani2.freeiz.com/SZEM3/epuletek/'+ezt+'.png" onclick="addBuild(this.parentNode.parentNode,\''+ezt+'\')" title="'+bovebb+'">';
}
function insertBuildRow(){
	try{
	epitoID=prompt("Adja meg a falu azonositojat, melybe epiteni szeretne!");
	patt=/[^0-9]/;
	if (patt.test(epitoID)) throw "A faluazonosito csak szambol �ll!";
	epito_url=WEBPAGE.replace(/(village=)[0-9]+/,"village="+epitoID);
	epito_url+="&screen=main";
	Bx=document.getElementById("epitotabla");
	NewLine=Bx.insertRow(-1); NewLine.insertCell(0); NewLine.insertCell(1); NewLine.insertCell(2);
	sor=(Bx.rows.length)-1;
	Bx.rows[sor].cells[0].innerHTML='<a href="'+epito_url+'" target="_blank">'+epitoID+'</a>';
	Bx.rows[sor].cells[1].innerHTML='<input type="text" size="50" value="">';
	Bx.rows[sor].cells[2].innerHTML=epuletek('main')+epuletek('barracks')+epuletek('stable')+epuletek('garage')+epuletek('church')+epuletek('snob')+epuletek('smith')+epuletek('place')+epuletek('statue')+epuletek('market')+epuletek('wood')+epuletek('stone')+epuletek('iron')+epuletek('farm')+epuletek('storage')+epuletek('hide')+epuletek('wall');
	} catch(e) {alert(e);}
}

function addBuild(ide,ezt){
	try{
	sor=ide.rowIndex;
	document.getElementById("epitotabla").rows[sor].cells[1].getElementsByTagName("input")[0].value+=ezt+";";
	} catch(e) {alert(e);}
}

function Epito_Export(){
	var str="";
	try{
	var X=document.getElementById("epitotabla");
	for (var i=1;i<X.rows.length;i++){
		str+=X.rows[i].cells[0].textContent+"."+X.rows[i].cells[1].getElementsByTagName("input")[0].value+"_";
	}
	alert("Masolja az alabbi kulcsadatot, melyet felhasznalhat a kesobbi importalashoz:\n"+str);
	} catch(e) {alert(e);}
}

function Epito_Import(){
	try{
	var adat=prompt("Adja meg a kulcsadatot, melyet importalni akar:\n");
	var sorok=adat.split("_");
	for (var i=0;i<sorok.length-1;i++){
		/*alert("Feldolgoz�s...\n"+sorok[i]+"\n\nBeilleszt�s: \nFalu:"+sorok[i].split(".")[0]+"\n�p�t�si lista: "+sorok[i].split(".")[1]);*/
		Bx=document.getElementById("epitotabla");
		NewLine=Bx.insertRow(-1); NewLine.insertCell(0); NewLine.insertCell(1); NewLine.insertCell(2);
		sor=(Bx.rows.length)-1;
			epito_url=WEBPAGE.replace(/(village=)[0-9]+/,"village="+sorok[i].split(".")[0]);
			epito_url+="&screen=main";
		Bx.rows[sor].cells[0].innerHTML='<a href="'+epito_url+'" target="_blank">'+sorok[i].split(".")[0]+'</a>';
		Bx.rows[sor].cells[1].innerHTML='<input type="text" size="50" value="">';
		Bx.rows[sor].cells[1].getElementsByTagName("input")[0].value=sorok[i].split(".")[1];
		Bx.rows[sor].cells[2].innerHTML=epuletek('main')+epuletek('barracks')+epuletek('stable')+epuletek('garage')+epuletek('church')+epuletek('snob')+epuletek('smith')+epuletek('place')+epuletek('statue')+epuletek('market')+epuletek('wood')+epuletek('stone')+epuletek('iron')+epuletek('farm')+epuletek('storage')+epuletek('hide')+epuletek('wall');
	}
	} catch(e){alert("HIBA:\n"+e);}
}

function open_epito(esor){
try{
	epito_ID=document.getElementById("epitotabla").rows[esor].cells[0].textContent;
	epito_url=WEBPAGE.replace(/(village=)[0-9]+/,"village="+epito_ID);
	epito_url+="&screen=main";
	if (SITTER!="") epito_url+=SITTER;
	epito_ablak=window.open(epito_url,'epito');
	return epito_ablak;
} catch(e) {naplo("hiba","Epito: (lapnyit�skor) - "+e);}
}
function epito(eref,esor){
	try{
	if (eref.document.readyState!='complete') {epito_toolongtime++; throw "ujra"; }
	if (isbot(eref)) return false;
	build=document.getElementById("epitotabla").rows[esor].cells[1].getElementsByTagName("input")[0].value.split(";")[0];
	if (build=="") {naplo("szem","Epito: "+document.getElementById("epitotabla").rows[esor].cells[0].innerHTML+". ID-ju faluban nincs tobb epiteni valo. Sor torolve."); document.getElementById("epitotabla").deleteRow(esor); return false;}
	epito_patt=new RegExp ("id="+build,"");
	epito_patt2=/action=build/;
	for (var i=0;i<eref.document.links.length;i++){
		if (epito_patt.test(eref.document.links[i].href) && epito_patt2.test(eref.document.links[i].href)) {
			eref.document.getElementById("main_buildlink_"+build).click();
			naplo("build","Epito: "+document.getElementById("epitotabla").rows[esor].cells[0].innerHTML+" ID-ju faluban "+build+" berakva.");
			document.getElementById("epitotabla").rows[esor].cells[1].getElementsByTagName("input")[0].value=document.getElementById("epitotabla").rows[esor].cells[1].getElementsByTagName("input")[0].value.replace(build+";","");
			break;
		}
	}
	/*if (i==eref.document.links.length) naplo("szem","Nem sikerult venni ezt: "+build+", itt: "+esor);*/
	} catch(e) {if (epito_toolongtime>10) {addError(5,'epito',eref); return false;} if (e=="ujra") {setTimeout("epito(eref,esor)",1000); return false;} naplo("hiba","Epito: (epites kozben) - "+e); }
}

function epitomain(){
try{
	epitosor=document.getElementById("epitotabla").rows.length;
	if (epitosor>1) epito_random=Math.floor((((Math.random()*4)+18)*1000*60)/(epitosor-1)); else epito_random=60000; 
	if (epitosor>1 && !bote) {epito_random2=Math.floor(Math.random()*(epitosor-1))+1;
	epito_toolongtime=0;
	epito_ablak=open_epito(epito_random2);
	setTimeout("epito(epito_ablak,epito_random2)",987+(epito_random2*7));}
	iepito=setTimeout("epitomain()",epito_random);
} catch(e) {naplo("hiba","Epito: (kezeloprogramban) - "+e);}
}
var epito_toolongtime=0;
epitomain();
