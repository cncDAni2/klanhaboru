javascript:
function jelenlegi(){
	var index=1; var isindex=false;
	VEGTELENCIKLUS=0;
	while (!isindex){
		VEGTELENCIKLUS++; if (VEGTELENCIKLUS>2000) {naplo("hiba","V�GTELEN CIKLUS ITT: check_result;p1"+e);return;}
		if (document.getElementById(index).style.display=="none") index++; else isindex=true;
		if (index>10) {naplo("hiba","HIBA, nem lehet lapozni"); return 1;}
	}
	return index;
} function lapoz(ide){
	index=jelenlegi();
	document.getElementById(index).style.display="none";
	x=document.getElementById("fnev");
	if (document.getElementById(index+ide)) {document.getElementById(index+ide).style.display="block"; x.innerHTML="Auto-farm "+(index+ide);} else{
		switch (ide){
			case -1: document.getElementById(10).style.display="block"; x.innerHTML="Auto-farm 10"; break;
			case  1: document.getElementById(1).style.display="block"; x.innerHTML="Auto-farm 1"; break;
			default: document.getElementById(1).style.display="block"; x.innerHTML="Auto-farm 1";
		}
	 }
	}
function setCookie(c_name,value){
localStorage.setItem(c_name,value);
return;
}
function getCookie(Name){try{
	return localStorage.getItem(Name);
}catch(e){return null;}
}

function kep(ez){
	if (ez=="szem") return '<img height="16px" src="http://cncdani2.freeiz.com/SZEM3/_SZEM.png" alt="" title="Megfigyel�s">';
	if (ez=="hiba") return '<img height="16px" src="http://cncdani2.freeiz.com/SZEM3/_WARN.png" alt="" title="Kritikus hiba">';
	if (ez=="kieg") return '<img height="16px" src="http://cncdani2.freeiz.com/SZEM3/_KIEG.png" alt="" title="Kieg�sz�t�">';
	if (ez=="uzenet") return '<img height="16px" src="http://cncdani2.freeiz.com/SZEM3/_UZI.png" alt="" title="�zenet �rkez�se">';
	if (ez=="tamadas") return '<img height="16px" src="http://cncdani2.freeiz.com/SZEM3/_TAMAD.png" alt="" title="Bej�v�/be�rkezett t�mad�s">';
	if (ez=="nyers") return '<img height="16px" src="http://cncdani2.freeiz.com/SZEM3/_RAKTAR.png" alt="" title="Megtelt rakt�r">';
	if (ez=="build") return '<img height="16px" src="http://cncdani2.freeiz.com/SZEM3/_BUILD.png" alt="" title="�p�t�s">';
	if (ez=="smile_1") return '<img src="http://cncdani2.freeiz.com/SZEM3/smile_1.gif" alt="" title="�llapotjelz�">';
	if (ez=="smile_2") return '<img src="http://cncdani2.freeiz.com/SZEM3/smile_2.gif" alt="" title="�llapotjelz�">';
	if (ez=="smile_3") return '<img src="http://cncdani2.freeiz.com/SZEM3/smile_3.gif" alt="" title="�llapotjelz�">';
	if (ez=="clock_OFF") return '<img src="http://cncdani2.freeiz.com/SZEM3/clock_OFF.png" name="oraikon" alt="OFF" title="Cs�rg��ra be�ll�t�sa">';
	return '<img height="16px" src="http://cncdani2.freeiz.com/SZEM3/'+ez+'.png" alt="'+ez+'" title="'+ez+'">';}
function naplo(tipus, szoveg){
	var d=new Date();
	perc=d.getMinutes(); mp=d.getSeconds(); if (perc<10) perc="0"+perc; if (mp<10) mp="0"+mp;
	var honap=new Array("Janu�r","Febru�r","M�rcius","�prilis","M�jus","J�nius","J�lius","Augusztus","Szeptember","Okt�ber","November","December");
	var table=document.getElementById("naplo");
	var row=table.insertRow(1);
	var cell1=row.insertCell(0);
	var cell2=row.insertCell(1);
	cell1.innerHTML=honap[d.getMonth()]+" "+d.getDate()+", "+d.getHours()+":"+perc+":"+mp;
	cell2.innerHTML=kep(tipus)+' '+szoveg;
}

function botriado(botref){
	try{
	if (hang==1) playSound("Bot");
	if (hang==2) playSmartSound(botref,"Bot");
	botref2=botref;
	ibotriado=setTimeout("botriado(botref2)",10000);
	} catch(e) {}
}
function isbot(reff){
try{
	if (bote) return true;
	if (reff!="undefined" && !reff.closed){
		if (reff.document.getElementById('bot_check') || reff.document.title=="Bot v�delem"){
			bote=true;
			document.getElementsByName("bot")[0].setAttribute("src","http://cncdani2.freeiz.com/SZEM3/bot_ON.png");
			naplo("hiba","BOT V�DELEM AKT�V! �rja be a k�dot, majd kattintson a piros BOT ikonra fel�l");
			botriado(reff);
			return true;
		}
	}
	return false;
} catch(e) {return false;}
} 
function bot_ok(){
	try{
	document.getElementsByName("bot")[0].setAttribute("src","http://cncdani2.freeiz.com/SZEM3/bot_OFF.png"); 
	bote=false;
	clearTimeout(ibotriado);
	for (var i=1;i<=10;i++){
		if (document.getElementById(i).innerHTML!=""){
			var lap=window["lap"+i];
			lap.location.reload();
	}}
	return;
	} catch(e){alert(e);}
}

function hangchg(){
	try{
	x=document.getElementsByName("hang")[0];
	switch(hang){
		case 0: x.setAttribute("src","http://cncdani2.freeiz.com/SZEM3/sound_ON.png");
				x.setAttribute("title","Hangok bekapcsolva"); hang=1; break;
		case 1: x.setAttribute("src","http://cncdani2.freeiz.com/SZEM3/sound_SMART.png");
				x.setAttribute("title","Hangok intelligens �zemm�dban"); hang=2; break;
		case 2: x.setAttribute("src","http://cncdani2.freeiz.com/SZEM3/sound_OFF.png");
				x.setAttribute("title","Hangok kikapcsolva"); hang=0; break;
		default: x.setAttribute("src","http://cncdani2.freeiz.com/SZEM3/sound_OFF.png");
				 x.setAttribute("title","Hiba t�rt�nt v�lt�skor. Hangok ki."); hang=0; break;
	}}catch(e) {naplo("hiba","Hangv�lt�s: v�gzetes hiba. "+e);}
}

function lapkeres(){
	var talal=false; var l=1;
	VEGTELENCIKLUS=0;
	while (!talal && l<11){
		VEGTELENCIKLUS++; if (VEGTELENCIKLUS>2000) {naplo("hiba","V�GTELEN CIKLUS ITT: check_result;p1"+e);return;}
		if (document.getElementById(l).innerHTML!="") talal=true; else l++;
	}
	if (!talal) return 0; else return l;
}

function sztorles(nev,kod){
		torolK=document.getElementById("kieg").innerHTML;
		str1='<tr><td>'+nev+'<\/td><td><a href=\'javascript: stop("'+kod+'");\'>Le�ll�t�s</a></td></tr>';
		torolK=torolK.replace(str1,"");
		document.getElementById("kieg").innerHTML=torolK;
		document.getElementById("naplo").innerHTML+="<tr><td>"+Date()+"</td><td>"+nev+" script <b>le�ll�tva</b>.</td></tr>";}

function stop(azon){
try{
	patt=/Farm/g;
	if (patt.test(azon)){
		fID=azon.replace("Farm","");fID=parseInt(fID);
		switch (fID) {case 1: clearTimeout(i1); break; case 2: clearTimeout(i2); break; case 3: clearTimeout(i3);
		break; case 4: clearTimeout(i4); break; case 5: clearTimeout(i5); break; case 6: clearTimeout(i6); break; case 7: clearTimeout(i7); 
		break; case 8: clearTimeout(i8); break; case 9: clearTimeout(i9); break; case 10: clearTimeout(i10); break; default: throw "nincs ilyen kieg�sz�t�"; }
		var keres=false; var F=0; patt=new RegExp(azon, "g");
		VEGTELENCIKLUS=0;
		while (!keres && (x=document.getElementById("kieg").rows[F])){
			VEGTELENCIKLUS++; if (VEGTELENCIKLUS>2000) {naplo("hiba","V�GTELEN CIKLUS ITT: check_result;p1"+e);return;}
			if (patt.test(x.cells[1].innerHTML)) keres=true; else F++;
		} x.innerHTML=""; document.getElementById("kieg").innerHTML=document.getElementById("kieg").innerHTML.replace("<tr></tr>","");
		document.getElementById(fID).innerHTML="";
		naplo("kieg","Kieg�sz�t� le�lltva: Auto-Farm "+fID);
		return;
	}
	if (azon=="VIJE") {clearTimeout(iVIJE);}
	if (azon=="tamadf") {clearTimeout(itamadf);}
	if (azon=="raktarf") {clearTimeout(iraktarf);}
	if (azon=="uzif") {clearTimeout(iuzif);}
	if (azon=="forumID") {clearTimeout(iforumID);}
	if (azon=="epito") {document.getElementsByTagName("tbody")[0].deleteRow(-1);}
		x=document.getElementById(azon).children[1];
		x.innerHTML='<a href=\'javascript: start("'+azon+'");\'><img src="http://cncdani2.freeiz.com/SZEM3/OFF.png"/> Start</a>';
		naplo("kieg","Kieg�sz�t� le�ll�tva: "+document.getElementById(azon).children[0].innerHTML);
	}catch(e){naplo("hiba",azon+" le�ll�t�sa sikertelen: "+e); void(0);}
}

function playSmartSound(ref,hang){
playSound(hang);
} function playSound(hang){
var play="http://cncdani2.freeiz.com/SZEM3/Sounds/"+hang+".wav";
document.getElementById("wavhang").src=play;
document.getElementById("audio1").load();
}

function start(kieg){
	try{
	switch(kieg){
		case "VIJE": $.getScript('http://cncdani2.freeiz.com/SZEM3/SZEM3_VIJE.js'); break;
		case "tamadf": $.getScript('http://cncdani2.freeiz.com/SZEM3/SZEM3_tamadf.js'); break;
		case "raktarf": $.getScript('http://cncdani2.freeiz.com/SZEM3/SZEM3_raktarf.js'); break;
		case "uzif": $.getScript('http://cncdani2.freeiz.com/SZEM3/SZEM3_uzif.js'); break;
		case "forumf": $.getScript('http://cncdani2.freeiz.com/SZEM3/SZEM3_forumID.js'); break;
		case "epito": EPX=document.getElementsByTagName("tbody")[0]; EPXR=EPX.insertRow(-1); EPXR.setAttribute("align","center"); EPXRL=EPXR.insertCell(0); EPXRL.colSpan='2'; EPXRL.innerHTML='<h1 align="center">�p�t� script</h1><table class="vis" align="center"><tbody id="epitotabla"><tr><th>Hol?</th><th>Mit?</th><th>Gyorsgomb</th></tr></tbody></table><br><a href="javascript: insertBuildRow(); void(0);"><img src="http://cncdani2.freeiz.com/SZEM3/epuletek/_Add.png" alt="(Hozz�ad) "/></a> <a href="javascript: Epito_Export();" ><img src="http://cncdani2.freeiz.com/SZEM3/epuletek/_export.png" alt="(Export�l�s)"/></a> <a href="javascript: Epito_Import();"><img src="http://cncdani2.freeiz.com/SZEM3/epuletek/_import.png" alt="(Import�l�s)"/></a>'; $.getScript('http://cncdani2.freeiz.com/SZEM3/SZEM3_epito.js'); break;
		case "nyerseloszto": $.getScript('http://cncdani2.freeiz.com/SZEM3/SZEM3_nyereloszto.js'); break;
		default: naplo("hiba","Helytelen kieg�sz�t�!"); return;
	}
	x=document.getElementById(kieg).children[1];
	x.innerHTML='<a href=\'javascript: stop("'+kieg+'");\'><img src="http://cncdani2.freeiz.com/SZEM3/ON.png"/> Stop</a>';
	naplo("kieg","�j kieg�sz�t�: "+document.getElementById(kieg).children[0].innerHTML);
	}catch(e){alert("Hiba a "+kieg+" script elind�t�sakor:\n"+e); void(0);}
}

function addError(num,azon,ref){
	try{
	if (ref!=undefined && num>0) {ref.location.reload();}
	var talal=false; var i=0; var hiba=parseInt(num);
	patt = new RegExp (azon);
	VEGTELENCIKLUS=0;
	while (!talal && (d=document.getElementById('kieg').rows[i])){
		VEGTELENCIKLUS++; if (VEGTELENCIKLUS>2000) {naplo("hiba","V�GTELEN CIKLUS ITT: check_result;p1"+e);return;}
		if (patt.test(d.cells[1].innerHTML)) {
			talal=true;
			if (parseInt(d.cells[2].innerHTML)>=0){
				d.cells[2].innerHTML=(parseInt(d.cells[2].innerHTML))+hiba;}
			if (parseInt(d.cells[2].innerHTML)>=10) {if (ref!=undefined) {ref.close();} d.cells[2].innerHTML=0; naplo("hiba","Folyamatos hiba a(z) "+azon+" scriptn�l."); if (hang==1) playSound("Hiba"); if (hang==2) playSmartSound(ref,"Hiba");}
			if (parseInt(d.cells[2].innerHTML)<0) d.cells[2].innerHTML=0;
		} i++;
	}
	return;
	}catch(e){naplo("hiba","Hiban�vel�si hiba: "+e);}
}

function VIJE_delfg(){
	try{
		var x=document.getElementsByName("vijedel")[0];
		if (x.getAttribute("alt")=="on"){
			x.setAttribute("alt","off");
			x.setAttribute("src",'http://cncdani2.freeiz.com/SZEM3/VIJE_delete_off.png');
			VIJE_del=false;
		} else {
			x.setAttribute("alt","on");
			x.setAttribute("src",'http://cncdani2.freeiz.com/SZEM3/VIJE_delete.png');
			VIJE_del=true;
		}
	}catch(e){alert("Hiba �t�ll�t�skor:\n"+e);}
}

function setting_ora(){
try{
	var ido=document.getElementById("clock").textContent.split(':');
	var now=new Date();
	var ido_d2=new Date(now.getFullYear(),now.getMonth(),now.getDate(),ido[0],ido[1],0,0);
	if (now>ido_d2){
		if (hang==1) playSound("clock");
		if (hang==2 || hang==0) {
			var islap=lapkeres(); if (islap==0) {A=window.open(WEBPAGE,"ora"); setTimeout('playSmartSound(A,"clock")',3000); } else {playSmartSound(window["lap"+islap],"clock"); }
		}
	}
	iclock=setTimeout("setting_ora()",15000);
}catch(e){naplo("hiba","Cs�rg��ra hiba: "+e); csorgoora(); }
}
function csorgoora(){ 
	try{
	var ORA=document.getElementById("clock");
	var ORAIKON=document.getElementsByName("oraikon")[0];
	if (ORAIKON.getAttribute("alt")=="OFF"){
		var set_ido=prompt("Cs�rg��ra be�ll�t�sa.\nAdja meg mikor cs�r�gj�n az �ra (�ra:perc alakban)\n");
		opatt=/^[0-9]{1,2}(:)[0-9]{1,2}$/; if (!opatt.test(set_ido)) {alert("Hib�s id�megad�s"); return;}
		if ((set_ido.split(":")[0]>23) || (set_ido.split(":")>59)) {alert("Hib�s id�megad�s"); return;}
		ORA.innerHTML+=set_ido;
		document.getElementsByName("oraikon")[0].setAttribute("src",'http://cncdani2.freeiz.com/SZEM3/clock_ON.png');
		document.getElementsByName("oraikon")[0].setAttribute("alt","ON");
		setting_ora();
	} else {
		clearTimeout(iclock);
		ORAIKON.setAttribute("alt","OFF");
		ORAIKON.setAttribute("src","http://cncdani2.freeiz.com/SZEM3/clock_OFF.png");
		document.getElementById("clock").textContent=document.getElementById("clock").textContent.replace(/(.)*/g,"");
	}
	}catch(e){alert(e);}
}
function maplink(link){
	var mapkordik=link.split("|");
	return '<a href="'+WEBPAGE+'&screen=map#'+mapkordik[0]+';'+mapkordik[1]+'" TARGET="_blank">'+link+'</a>';
}

function pause(){
	try{
	var X=document.getElementById("pause");
	if (bote && X.getAttribute("name")=="play") { alert("Nem �ll�thatod meg SZEM-et, mik�zben a bot v�delem akt�v!"); return; }
	if (!bote){ X.setAttribute("name","pause"); bote=true; X.setAttribute("src","http://cncdani2.freeiz.com/SZEM3/PAUSE.png");  return; }
	if (bote){ X.setAttribute("name","play"); bote=false; X.setAttribute("src","http://cncdani2.freeiz.com/SZEM3/PLAY.png"); return; }
	}catch(E){alert(E);}
}

try{
	var bote=false;
	var hang=0;
	var VIJE_del=false;
	patt=/game.php\?village=[0-9]+/g;
	if (!patt.test(document.location.href)) {alert("SZEM-et a kl�nh�bor�ba bejelentkezett fi�kb�l kell ind�tani.\n�gy v�lem, ez nem az, vagy �pp most l�pt�l be - ut�bbi eset�n kattints valamerre.\n Ha m�gis, �rtes�tsd a script k�sz�t�j�t a hib�r�l."); void(0);}
	patt=/class="timer"/g;
	if (patt.test(document.getElementsByTagName("body")[0].innerHTML)) alert("Vigy�zz! Ezen a megjelen�tett lapon visszasz�ml�l�t �rz�keltem. �gy SZEM3 a sz�ml�l� 0-hoz �r�sekor le fog �llni. Aj�nlott m�shonnan ind�tani.");
	patt=/&t=[0-9]+/g; if (patt.test(document.location.href)) {SITTER_s=document.location.href.match(patt); var SITTER=SITTER_s[0];} else SITTER="";
	WEBPAGE=document.location.href.substr(0,(document.location.href+"&").indexOf("&"));
	document.getElementsByTagName("body")[0].removeAttribute("id");
	document.getElementsByTagName('head')[0].innerHTML='<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-2"/><title>SZEM3 info center</title> <link rel="stylesheet" type="text/css" href="http://cncdani2.freeiz.com/SZEM3/style6.css"><script type="text/javascript" src="http://mediaplayer.yahoo.com/js"></script>';
	document.getElementsByTagName("body")[0].innerHTML='<audio id="audio1" controls="controls" autoplay="autoplay" style="display:none"><source id="wavhang" src="" type="audio/wav"></audio><p align="center"><img src="http://cncdani2.freeiz.com/pic/Focim/Scriptgen_SZEM3.png"/></p> <table align="center" border="0" cellpadding="0px" cellspacing="25px">  <tr>  <td rowspan="2" align="center" valign="top"><h1 align="center"><i>Farmkezel� lista</i></h1>  <table  class="HL" align="center" width="100%" cellspacing="10px"><tr><td align="left"><a href="javascript: lapoz(-1);">&lt; El�re </a></td><td id="fnev" align="center">Auto-farm 1</td><td align="right"><a href="javascript: lapoz(1);">H�tra &gt;</a></td></tr></table>  <table class="vis" align="center" style="display:block" ID="1"></table>  <table class="vis" align="center" style="display:none" ID="2"></table>  <table class="vis" align="center" style="display:none" ID="3"></table>  <table class="vis" align="center" style="display:none" ID="4"></table>  <table class="vis" align="center" style="display:none" ID="5"></table>  <table class="vis" align="center" style="display:none" ID="6"></table>  <table class="vis" align="center" style="display:none" ID="7"></table>  <table class="vis" align="center" style="display:none" ID="8"></table>  <table class="vis" align="center" style="display:none" ID="9"></table>  <table class="vis" align="center" style="display:none" ID="10"></table>  <table align="center"><tr valign="top"><td id="ExpImp"><h2 align="left" style="display: none">Ismeretlen</h2><textarea style="background-color: #c0c0c0; display: none; opacity:0.6; filter:alpha(opacity=60);" id="alap_box" rows=10 cols=30 onclick="{document.getElementById(\'alap_box\').focus(); document.getElementById(\'alap_box\').select();}">Nincs adat</textarea></td></tr></table>  <table align="center"><tr valign="top"><td id="AddVill" style="display: none"><h2 align="left">Falu hozz�ad�s</h2>Falu koordin�ta: <input type="text" name="koord" size=8 value=""><br> K�ldend� egys�gek: <input type="text" name="egyseg" size=4 value=""><br>     <a href="javascript: add_village(0); void(0);" style="color:red;">Bez�r</a></td></tr></table>  </td>  <td><h1 align="center">Kieg�sz�t� kezel�</h1>  <p align="center"> <a href="javascript: hangchg();"><img name="hang" src="http://cncdani2.freeiz.com/SZEM3/sound_OFF.png" alt="Hangjelz�" title="Hangok kikapcsolva"/></a> <a href="javascript: pause();"><img id="pause" name="play" src="http://cncdani2.freeiz.com/SZEM3/PLAY.png" title="SZEM meg�ll�t�s�hoz/folytat�s�hoz kattintson ide" /> </a> <a href="javascript: bot_ok();"> <img name="bot"  src="http://cncdani2.freeiz.com/SZEM3/bot_OFF.png" alt=""title="Jelzi ha bot v�delmet tal�l. Ha vil�g�t, kattints r� miut�n be�rtad a k�dot."/></a> <a href="javascript: VIJE_delfg();"> <img name="vijedel"  src="http://cncdani2.freeiz.com/SZEM3/VIJE_delete_off.png" alt="off" title="Ha vil�g�t, a VIJE �ltal elemzett z�ld jelent�sek t�rl�dnek (t�mad�said, sz�modra vesztes�gn�lk�l)."/></a><a href="javascript: csorgoora();">'+kep("clock_OFF")+'</a></p> <p align="center" id="clock"></p><table align="center" class="vis"><tbody id="kieg">  <tr><th>Komponensek</th><th>Start/Stop</th><th>Hiba</th></tr>  <tr id="VIJE"><td>Val�s Idej� Jelent�s Elemz�</td><td> <a href=\'javascript: start("VIJE");\'><img src="http://cncdani2.freeiz.com/SZEM3/OFF.png"/> Start</a></td><td>0</td></tr>  <tr id="tamadf"><td>T�mad�s�rz�kel�</td><td> <a href=\'javascript: start("tamadf");\'><img src="http://cncdani2.freeiz.com/SZEM3/OFF.png"/> Start</a></td><td>0</td></tr>  <tr id="raktarf"><td>Rakt�rfigyel�</td><td> <a href=\'javascript: start("raktarf");\'><img src="http://cncdani2.freeiz.com/SZEM3/OFF.png"/> Start</a></td><td>0</td></tr>  <tr id="uzif"><td>�zenetfigyel�</td><td> <a href=\'javascript: start("uzif");\'><img src="http://cncdani2.freeiz.com/SZEM3/OFF.png"/> Start</a></td><td>0</td></tr>  <tr id="forumf"><td>F�rum ID �r�</td><td> <a href=\'javascript: start("forumf");\'><img src="http://cncdani2.freeiz.com/SZEM3/OFF.png"/> Start</a></td><td>-</td></tr> <tr id="epito"><td>�p�t�</td><td> <a href=\'javascript: start("epito");\'><img src="http://cncdani2.freeiz.com/SZEM3/OFF.png"/> Start</a></td><td>0</td></tr> </tbody></table>  </td>  </tr>  <tr valign="top">  <td><h1 align="center">Napl�</h1>  <table cellpadding="3px" align="center" class="vis">  <tbody id="naplo"><tr><th>D�tum</th><th>Esem�ny</th></tr>  </tbody>  </table></td></tr></table>';
	naplo("szem","SZEM3 elindult.");
	if (SITTER!="") naplo("szem","Helyettes�tett fi�kb�l ("+SITTER+") val� ind�t�s �szlelve.");
} catch(err) {alert("Helyrehozhatatlan hiba t�rt�nt SZEM bet�lt�d�sekor :( \n Nyisd meg �J lapon az �sszes jelent�s lapot, majd pr�b�ld �jra.\n"+err);}
var VEGTELENCIKLUS=0;
void(0);