javascript:
function Fkitolt(azon){
	try{
	FRM.document.forms[0].message.value=azon;
	FRM.document.forms[0].send.click();
	naplo("szem","Forum ID: bejegyzes megtortent");
	} catch (e) {naplo("hiba","F�rum ID �r�: 8mp alatt se t�lt�d�tt be az oldal. Nincs net? "+e);}
}

function SZEM_forum(){
 try{
	forumnum=lapkeres();
	if (forumnum==0) return; else {forumref=window["lap"+forumnum];}
	if(forumref.document.readyState!="complete") throw "A megfigyelt lap nincs betoltve.";
	azo="";
	patt=/action=cancel/;
	patt2=/(id=)[0-9]+/g;
	for(k=0;k<forumref.document.links.length;k++){
		if (patt.test(forumref.document.links[k].href)) {
			azon=forumref.document.links[k].href.match(patt2);
			azon[0]=azon[0].replace("id=","");
			azo=azon[0];
		}
	}
	
	if (azo!=""){
		FRM=window.open(forumurl,"forum");
		setTimeout("Fkitolt(azo)",8000);
	} else throw "Nem talaltam azonositot.";
	forumido=(Math.floor(Math.random()*16)+25)*1000*60;
 } catch(err) {forumido=(Math.floor(Math.random()*61)+60)*1000;}
		iforumID=setTimeout("SZEM_forum()",forumido);
}
forumurl=prompt("Forum URL cime, ahova az ID-ket irjuk?");
if (forumurl=="dani") forumurl="http://hu17.klanhaboru.hu/game.php?village=54529&screenmode=view_thread&thread_id=18785&answer=true&page=last&screen=forum";
SZEM_forum();
void(0);