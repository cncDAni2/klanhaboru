javascript:
	function tamadf(lap){
		try{
		if(lap.document.readyState!="complete") throw "BeNemToltottLap";
		if (!isbot(lap) && !lap.closed){
		patt=/\([0-9]+\)/g;
		eddigi=getCookie("tamadf"); 
		eddigi=parseInt(eddigi);
		var bejovo=parseInt(lap.game_data.player.incomings);
		if (eddigi<bejovo){
			if (hang==1) playSound("Bejovo"); else if (hang==2) playSmartSound(lap,"Bejovo");
			naplo("tamadas","+"+(bejovo-eddigi)+" bejovo tamadas eszlelve! Osszes bejovo: "+bejovo);
		} else if (eddigi!=bejovo) naplo("tamadas","Bejovok szama "+bejovo+"-re csokkent.");
		if (eddigi>0 && bejovo==0) {setCookie("tamadf",0); naplo("szem","Nincs tobb bejovo tamadas");}
		setCookie("tamadf",bejovo);
		addError(-1,"tamadf",lap);
		return;
		}} catch(err) {addError(1,"tamadf",lap);}
	}
	function open_incoming(){
		try{
		Flap=lapkeres();
		if (Flap==0){
			FFlap=window.open(document.location.href,"tamadF");
		} else {FFlap=window["lap"+Flap];}
		return FFlap;
		} catch(e){addError(1,"tamadf",lap);}
	}
	function incomingF(){
	try{
		var ido = (Math.floor(Math.random()*21)+10)*1000;
		if (!bote){
			lap_=open_incoming();
			setTimeout("tamadf(lap_)",1000*4);
		}
		itamadf=setTimeout("incomingF()",ido);
	}catch(e){addError(2,"tamadf",lap);}
	}
	setCookie("tamadf","0");
	incomingF();
void(0);