javascript:
function shortjelkeres(VIJE_REF){
	try{
		VIJE_REF2=window.open(VIJE_REF.document.location.href+"&view="+VIJE_ID,"VIJE_elemzolap");
		VIJE_ID=0;
		return true;
	} catch(e) {return false;}
}
function jelkeres(VIJE_REF){
	try{
	VIJE_table=VIJE_REF.document.getElementById("report_list");
	NO=VIJE_table.rows.length;
	var i=NO-1; var Vtalal=false;
	var VIJE_ik = new Array(); var k=0;
	while (i>=1){
		if (VIJE_table.rows[i].cells[0].lastChild.textContent.search(/\((.)*\)/g)>=0) {
			VIJE_ik[k]=i; 
			k++;
			Vtalal=true;
		}
		i--;
	} if(!Vtalal) return false;
	/*Megvannak azon sorindexek, ahol (UJ) jelentesek talalhatoak, forditott sorrendben. Leellenorizzuk hogy a farm-listaban van e ilyen kozotte?*/
	var j=0; var OK=false;
	while (!OK && j<VIJE_ik.length){
		Falu=VIJE_table.rows[VIJE_ik[j]].cells[0].textContent.match(/[0-9]+(\|)[0-9]+/g);
		VIJE_koord=Falu[Falu.length-1];
		var V_i=0; /*V_i: Auto-farm TABLE ID-je*/
		while (!OK && V_i<=10){
			var V_k=0; V_i++;
			if (document.getElementById(V_i+"_T")){
			while (!OK && document.getElementById(V_i+"_T").rows[V_k]){
				if (document.getElementById(V_i+"_T").rows[V_k].cells[1].innerHTML==VIJE_koord) {if (document.getElementById(V_i+"_T").rows[V_k].cells[3].innerHTML!="X") OK=true;} else V_k++; /*V_k: Sorszama a TABLE-nak (V_i-ben)*/
			}}
		}
		j++;
	}
	j--; /*j: jelentes sorszama (VIJE_REF lapon)*/
	 if (OK) {
		var szin=VIJE_REF.document.getElementById("report_list").rows[VIJE_ik[j]].cells[0].getElementsByTagName("img")[0].getAttribute("src").match(/\/[a-z_A-Z]+\.png/g)[0];
		szin=szin.replace("/",""); szin=szin.replace(".png","");
		szinmod=document.getElementById(V_i+"_T").rows[V_k].cells[3];
		switch (szin){
			case "green": szinmod.innerHTML="G"; break;
			case "yellow": if (szinmod.innerHTML!="Y") naplo("szem","VI Jelentes Elemzo: "+maplink(VIJE_koord)+" falun egysegvesztes tortent."); szinmod.innerHTML="Y";  break;
			case "blue": szinmod.innerHTML="B"; break;
			default: szinmod.innerHTML="R"; naplo("szem","VI Jelentes Elemzo: "+maplink(VIJE_koord)+" tovabbi tamadasa veszelyesnek itelve");
					 if (hang==1) playSound("Falukihagy"); if (hang==2) playSmartSound(VIJE_REF,"Falukihagy"); break;
		}		
		JEL_cime=VIJE_table.rows[VIJE_ik[j]].cells[0].getElementsByTagName("a")[0].getAttribute("href");
		/*javascript: A=document.getElementById("report_list").rows[1].cells[0].getElementsByTagName("a")[0].getAttribute("href");
		try{B=A.match(/&view=[0-9]+/g);} catch(e){alert(e);} alert(B); 
		javascript: try{document.getElementsByName("id_11346822")[0].checked=true;} catch(e){alert(e);} void(0);*/
		VIJE_OPEN=JEL_cime.match(/&view=[0-9]+/g)[0];
		VIJE_REF2=window.open(VIJE_REF.document.location.href+VIJE_OPEN,"VIJE_elemzolap");
		/*Bepip�l�s (VIJE_ID-j�t)*/
			if (szin=="blue"){
			VIJE_ID=VIJE_OPEN.match(/[0-9]+/g)[0];
			VIJE_REF.document.getElementsByName("id_"+VIJE_ID)[0].checked=true;
			}
		/*END OF: Bepip�l�s*/
		koord=VIJE_koord;
		hely1=V_i+"_T";
		hely2=V_k;
		addError(-1,"VIJE",VIJE_REF);
		return true;
	} else {addError(-1,"VIJE",VIJE_REF);return false;}
	} catch(e){addError(1,"VIJE",VIJE_REF); return false;}
}
function jelelemez(VIJE_REF){
	try{
		if (VIJE_REF2.document.getElementById("attack_spy")){
			var x=VIJE_REF2.document.getElementById("attack_spy").innerHTML;
			x=x.replace(/<span class="grey">.<\/span>/g,"");
			var nyers=x.match(/(>)[0-9]+( <)/g); var ossz=0;
			for (var i=0;i<nyers.length;i++) {nyers[i]=nyers[i].replace(">",""); nyers[i]=nyers[i].replace(" <",""); ossz+=parseInt(nyers[i]);}
			if (ossz>80000) {naplo("szem","Extr�m magas nyersanyag ("+ossz+") �szlelve itt: "+maplink(document.getElementById(hely1).rows[hely2].cells[1].innerHTML)); ossz=80000;}
			document.getElementById(hely1).rows[hely2].cells[4].innerHTML=ossz;
		}
		if (VIJE_del) VIJE_REF.document.forms[0].del.click();
		addError(-1,"VIJE",VIJE_REF);
		VIJE_ID=0;
		return;
	}catch(e) {addError(1,"VIJE",VIJE_REF2);}
}
/*November 14, 12:11:31	 TypeError: Cannot convert 'JEL_cime.match(/&view=[0-9]+$/g)' to object
November 14, 12:11:18	 TypeError: Cannot convert 'JEL_cime.match(/&view=[0-9]+$/g)' to object*/
function VIJE_main(folyt2){
	try{
	var VIJE_ido=(Math.floor(Math.random()*61)+37)*500;
	if (folyt2==true) VIJE_ido=Math.floor(VIJE_ido/3);
	if (!bote){
	  var vijeurl=WEBPAGE+"&screen=report&mode=attack&group_id=0"+SITTER;
	  if (VIJE_ID==0) {VIJE_lap=window.open(vijeurl,"VIJE");}
	  var folyt=false;
	  setTimeout("isbot(VIJE_lap)",2800);
	  setTimeout("if (VIJE_ID!=0) folyt=shortjelkeres(VIJE_lap); else folyt=jelkeres(VIJE_lap);",3000);
	  setTimeout("if (folyt) jelelemez(VIJE_lap);",5500);
	}}catch(e){naplo("hiba","VIJE: Hiba jelentes-elemzes kozben: "+e);}
	iVIJE=setTimeout("VIJE_main(folyt)",VIJE_ido);	
}
var VIJE_ID=0;
VIJE_REF2=window.open(WEBPAGE,"VIJE_elemzolap");
var koord=""; var hely1=""; var hely2="";
VIJE_main(true);
void(0);