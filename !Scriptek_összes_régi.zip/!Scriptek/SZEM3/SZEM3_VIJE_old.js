javascript:
function jelkeres(VIJE_REF){
	try{
	VIJE_table=VIJE_REF.document.getElementById("report_list");
	NO=VIJE_table.rows.length;
	var i=NO-1; var Vtalal=false;
	var VIJE_ik = new Array(); var k=0;
	while (i>=1){
		if (VIJE_table.rows[i].cells[0].lastChild.textContent.search(/\((.)*\)/g)>=0) {
			VIJE_ik[k]=i; 
			k++;
			Vtalal=true;
		}
		i--;
	} if(!Vtalal) return false;
	/*Megvannak azon sorindexek, ahol (UJ) jelentesek talalhatoak, forditott sorrendben. Leellenorizzuk hogy a farm-listaban van e ilyen kozotte?*/
	var j=0; var OK=false;
	while (!OK && j<VIJE_ik.length){
		Falu=VIJE_table.rows[VIJE_ik[j]].cells[0].textContent.match(/[0-9]+(\|)[0-9]+/g);
		VIJE_koord=Falu[Falu.length-1];
		var V_i=0; /*V_i: Auto-farm TABLE ID-je*/
		while (!OK && V_i<=10){
			var V_k=0; V_i++;
			if (document.getElementById(V_i+"_T")){
			while (!OK && document.getElementById(V_i+"_T").rows[V_k]){
				if (document.getElementById(V_i+"_T").rows[V_k].cells[1].innerHTML==VIJE_koord) OK=true; else V_k++; /*V_k: Sorszama a TABLE-nak (V_i-ben)*/
			}}
		}
		j++;
	}
	j--; /*j: jelentes sorszama (VIJE_REF lapon)*/
	 if (OK) {
		var szin=VIJE_REF.document.getElementById("report_list").rows[VIJE_ik[j]].cells[0].getElementsByTagName("img")[0].getAttribute("src").match(/\/[a-z_A-Z]+\.png/g)[0];
		szin=szin.replace("/",""); szin=szin.replace(".png","");
		if (document.getElementById(V_i+"_T").rows[V_k].cells[3].innerHTML=="X") {addError(-1,"VIJE",VIJE_REF); return false;}
		switch (szin){
			case "green": document.getElementById(V_i+"_T").rows[V_k].cells[3].innerHTML="G"; break;
			case "yellow": document.getElementById(V_i+"_T").rows[V_k].cells[3].innerHTML="Y"; naplo("szem","VI Jelentes Elemzo: "+VIJE_koord+" falun egysegvesztes tortent."); break;
			case "blue": document.getElementById(V_i+"_T").rows[V_k].cells[3].innerHTML="B"; break;
			default: document.getElementById(V_i+"_T").rows[V_k].cells[3].innerHTML="R"; naplo("szem","VI Jelentes Elemzo: "+VIJE_koord+" tovabbi tamadasa veszelyesnek itelve");
					 if (hang==1) playSound("Falukihagy"); if (hang==2) playSmartSound(VIJE_REF,"Falukihagy"); break;
		}		
		VIJE_OPEN=VIJE_table.rows[VIJE_ik[j]].cells[0].getElementsByTagName("a")[0].getAttribute("href").match(/&view=[0-9]+$/g)[0];
		VIJE_REF.location=(VIJE_REF.document.location.href+VIJE_OPEN);
		koord=VIJE_koord;
		hely1=V_i+"_T";
		hely2=V_k;
		addError(-1,"VIJE",VIJE_REF);
		return true;
	} else {addError(-1,"VIJE",VIJE_REF);return false;}
	} catch(e){addError(1,"VIJE",VIJE_REF); return false;}
}
function jelelemez(VIJE_REF){
	try{
		if (VIJE_REF.document.getElementById("attack_spy")){
			var x=VIJE_REF.document.getElementById("attack_spy").innerHTML;
			x=x.replace(/<span class="grey">.<\/span>/g,"");
			var nyers=x.match(/(>)[0-9]+( <)/g); var ossz=0;
			for (i=0;i<nyers.length;i++) {nyers[i]=nyers[i].replace(">",""); nyers[i]=nyers[i].replace(" <",""); ossz+=parseInt(nyers[i]);}
			document.getElementById(hely1).rows[hely2].cells[4].innerHTML=ossz;
		}
		addError(-1,"VIJE",VIJE_REF);
		return;
	}catch(e) {addError(1,"VIJE",VIJE_REF);}
}
function VIJE_main(folyt2){
	try{
	var VIJE_ido=(Math.floor(Math.random()*61)+37)*500;
	if (folyt2==true) VIJE_ido=Math.floor(VIJE_ido/3);
	if (!bote){
	  var vijeurl=WEBPAGE+"&screen=report&mode=attack&group_id=0"+SITTER;
	  VIJE_lap=window.open(vijeurl,"VIJE");	  
	  var folyt=false;
	  setTimeout("isbot(VIJE_lap)",2800);
	  setTimeout("folyt=jelkeres(VIJE_lap)",3000);
	  setTimeout("if (folyt) jelelemez(VIJE_lap)",5500);
	}}catch(e){naplo("hiba","VIJE: Hiba jelentes-elemzes kozben: "+e)};
	iVIJE=setTimeout("VIJE_main(folyt)",VIJE_ido);	
}
var koord=""; var hely1=""; var hely2="";
VIJE_main(true);
void(0);