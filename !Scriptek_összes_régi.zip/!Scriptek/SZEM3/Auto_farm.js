javascript:
function isido(sorsz){
	try{
	I=document.getElementById(sorsz).getElementsByTagName("div");
	for (u=1;u<I.length;u++){
	if (I[u].getAttribute("class")=="sor") {
		if(I[u].children[0].innerHTML=="Script utols� k�re") var IDO=I[u].children[1].innerHTML;
		if(I[u].children[0].innerHTML=="Cirkul�l�s (perc)") var cirk=I[u].children[1].innerHTML;
	}} cirk=parseInt(cirk);
	var t=IDO.split("."); var d=new Date(t[0],t[1],t[2],t[3],t[4],t[5],0);
	d.setMinutes(d.getMinutes()+cirk);
	var now=new Date();
	if (now>d) { ugras(sorsz);}
	} catch(E){ naplo("hiba","Auto-Farm "+sorsz+": Id�n�z�si probl�ma: "+E); }
}
function felezo(sorsz){
	try{
	naplo("szem","Auto-farm "+sorsz+": Felezem az elemzett nyerseket, mert nem haladok.");
	aldozat=document.getElementById(sorsz+"_T").rows;
	var hossz=aldozat.length;
	for (var i=0;i<hossz;i++){
		if (aldozat[i].cells[4].innerHTML!="Nincs") {aldozat[i].cells[4].innerHTML=Math.floor((parseInt(aldozat[i].cells[4].innerHTML)/2));}
	}
	}catch(E){naplo("hiba","Felezni k�ne az �sszes nyerset, de nem siker�lt: "+E);}
}

function ugras(sorsz){
	try{
		var talal=false; var sor=0; 
		while (!talal && (x=document.getElementById(sorsz+"_T").rows[sor])){
		if (x.cells[0].innerHTML=="O") talal=true; else sor++;
		}
	if(talal) { /*VAN O, 1el od�bb kell rakni, ha van helye.  Meg kell m�g n�zni hogy �jra kell e kezdeni!.*/
		x.cells[0].innerHTML="";
		if (document.getElementById(sorsz+"_T").rows[(sor+1)]!=undefined) document.getElementById(sorsz+"_T").rows[(sor+1)].cells[0].innerHTML="O";
	}
	
	I=document.getElementById(sorsz).getElementsByTagName("div");
	for (u=1;u<I.length;u++){
	if (I[u].getAttribute("class")=="sor") {
		if(I[u].children[0].innerHTML=="Munkateljes�tm�ny (%)") { try{fej=I[u].children[1].getElementsByTagName("img")[0];} catch(e){fej=""; }}
		if(I[u].children[0].innerHTML=="Script utols� k�re") var IDO=I[u].children[1].innerHTML;
		if(I[u].children[0].innerHTML=="Cirkul�l�s (perc)") var cirk=I[u].children[1].innerHTML;
	}} cirk=parseInt(cirk);
	var t=IDO.split("."); var d=new Date(t[0],t[1],t[2],t[3],t[4],t[5],0);
	d.setMinutes(d.getMinutes()+cirk);
	var now=new Date();
	if (now>d) {
		WatcH=document.getElementById(sorsz+"_T").rows; if (WatcH[0].cells[0].innerHTML=="O" || WatcH[1].cells[0].innerHTML=="O") felezo(sorsz);
		if (talal) {if (x=document.getElementById(sorsz+"_T").rows[sor+1]) {x.cells[0].innerHTML=""; fej.setAttribute('src',smile(3)); }} else if (fej.getAttribute("src")==smile(3)) {fej.setAttribute('src',smile(2));}
		document.getElementById(sorsz+"_T").rows[0].cells[0].innerHTML="O";
		for (u=1;u<I.length;u++){
			if (I[u].getAttribute("class")=="sor") { if (I[u].children[0].innerHTML=="Script utols� k�re") I[u].children[1].innerHTML=now.getFullYear()+"."+now.getMonth()+"."+now.getDate()+"."+now.getHours()+"."+now.getMinutes()+"."+now.getSeconds();}
		}
	}} catch(err) {naplo("hiba","Ugr�si hiba: "+err); addError(1,"Farm"+sorsz);}
	return;
}
function ugras_vissza(sorsz){
try{
	var talal=-1; var max=0;
	while ((x=document.getElementById(sorsz+"_T").rows[max])){
		if (x.cells[0].innerHTML=="O") talal=max;
		max++;
	}
	if (talal==-1) document.getElementById(sorsz+"_T").rows[max-1].cells[0].innerHTML="O"; else{
		if (talal!=0) {
			document.getElementById(sorsz+"_T").rows[talal-1].cells[0].innerHTML="O";
			document.getElementById(sorsz+"_T").rows[talal].cells[0].innerHTML="";
		}
	}
} catch(e) {alert("hiba","Hiba visszafel� ugr�skor: "+e);}
}
function smile(look){
	var ret="http://cncdani2.freeiz.com/SZEM3/";
	switch (look){
		case 1: ret+="smile_1.gif"; break;
		case 2: ret+="smile_2.gif"; break;
		case 3: ret+="smile_3.gif"; break;
		default: ret+="_WARN.png";
	}
	return ret;
}
function del(tabla,sor){
	try{ var sure=confirm("Biztos kit�rli ezt a sort?");
	if (!sure) return;
	d=document.getElementById(tabla+"_T");
	if (!d.rows[1]) {alert("Legal�bb 1 sornak maradnia kell"); return;}
	if (d.rows[sor].cells[0].innerHTML=="O") ugras(tabla);
	d.rows[sor].innerHTML="";
	d.innerHTML=d.innerHTML.replace("<tr></tr>","");
	var i=0;
	while (d=document.getElementById(tabla+"_T").rows[i]){
		d.cells[5].innerHTML=d.cells[5].innerHTML.replace(/[0-9]+(,)[0-9]+/g,tabla+","+i);
		i++;
	}
	} catch(e) {alert("Hiba t�rt�nt sort�rl�skor: "+e);}}
function complete(tabla,sor){try{document.getElementById(tabla+"_T").rows[sor].cells[4].innerHTML="Nincs";} catch(e) {alert("Hiba t�rt�nt semleges�t�skor: "+e);}}

function showExp(FarmID){
	try{
	/*ExpImp a cella ahova �runk, alap_box a hely neve. V�g�n legyen kieg. a cell�nak, mint bez�r�s (ugyanez a link j� lesz :-))*/
	var X=document.getElementById("ExpImp");
	var d=document.getElementById("ExpImp").getElementsByTagName("h2")[0];
	var d2=document.getElementById("alap_box");
	if (d2.style.display=="block") { d.style.display="none"; d2.style.display="none"; X.removeChild(X.getElementsByTagName("a")[0]); return;}
	d2.innerHTML=document.getElementById(FarmID).innerHTML;
	d2.style.display="block"; d.style.display="inline";
	d.innerHTML="Export�l�s";
	X.innerHTML+='<a href="javascript: showExp(0);" style="color:red;">Bez�r</a>';
	return;
	}catch(e){"Hiba Export�l�skor: "+alert(e);}
}
function showImp(FarmID){
	try{
	var X=document.getElementById("ExpImp");
	var d=document.getElementById("ExpImp").getElementsByTagName("h2")[0];
	var d2=document.getElementById("alap_box");
	if (d2.style.display=="none") { d.innerHTML="Import�l�s"; d2.style.display="block"; d2.innerHTML="Ide m�solja a kor�bban import�lt k�dot"; d.style.display="inline"; X.innerHTML+='<a href="javascript: showExp(0);"  style="color:red;">Bez�r</a>'; return;}
	if (isNaN(parseInt(FarmID)) || parseInt(FarmID)>10 || parseInt(FarmID)<0) throw "Ide nem import�lhatsz.";
	var str=d2.value;
	if (str.length<1500) throw "Ez biztos nem j�, t�l r�vid";
	str=str.replace("'","\'");
	str=str.replace(/>/g,">");
	str=str.replace(/</g,"<");
	str=str.replace(/(id=")[0-9]+/g,'id="'+FarmID);
	str=str.replace(/\([0-9]+(\);)/g,'('+FarmID+');');
	str=str.replace(/(complete\([0-9]+)/g,'complete('+FarmID);
	str=str.replace(/(del\([0-9]+)/g,'del('+FarmID);
	str=str.replace(/(void\(1\));/g,'void(0);');
	document.getElementById(FarmID).innerHTML="";
	document.getElementById(FarmID).innerHTML+=str;
	naplo("szem","Import�l�s sikeres az Auto-Farm "+FarmID+" helyen");
	showExp(0);
	}catch(e){alert("Hiba Import�l�skor:\n "+e);}
}
function modify_spy(FarmID){
	try{
		var uj=prompt("Mennyi legyen az �j �rt�k?");
		uj=parseInt(uj);
		if (isNaN(uj) || uj<0) throw "Nem megengedett �rt�k.";
		var Y=document.getElementById(FarmID).getElementsByTagName("div");
		var z=0;
		for (z=1;z<Y.length;z++){
			if (Y[z].getAttribute("class")=="sor") {
				if(Y[z].children[0].innerHTML=="K�ldend� k�mek") Y[z].children[1].innerHTML=uj;
		}}
	} catch(e){alert("Hiba k�mek sz�m�nak m�dos�t�sakor:\n "+e);}
}
function munka(FarmID,num){
	try{
		szam=parseInt(num); if(isNaN(szam)) throw "Nem sz�mmal val� m�dos�t�si pr�b�lkoz�s"; else szam=szam/10;
		var Y=document.getElementById(FarmID).getElementsByTagName("div");
		var z=0;
		for (z=1;z<Y.length;z++){
			if (Y[z].getAttribute("class")=="sor") {
				if(Y[z].children[0].innerHTML=="Munkateljes�tm�ny (%)"){
					fej=Y[z].children[1].innerHTML.match(/(<img)(.)*(>)/g); if (fej==null) fej=""; else	
					fejT=Y[z].children[1].getElementsByTagName("img")[0];
					if (szam>0) {if (fejT.getAttribute("src")==smile(1)) fejT.setAttribute('src',smile(2));}
					if (szam<0) fejT.setAttribute('src',smile(1));
					jelen=parseFloat(Y[z].children[1].innerHTML.match(/[0-9]+(\.)?[0-9]*/g)[0]);
					if (jelen>=100 && szam>0) return;
					if (jelen<=0 && szam<0) return;
					var ujmunka=(jelen+szam).toFixed(1);
					fej=Y[z].children[1].innerHTML.match(/(<img)(.)*(>)/g);
					Y[z].children[1].innerHTML=ujmunka+" "+fej;
				}
		}}
	} catch(e){naplo("hiba","Szerkezeti hiba, nem lehet a munkateljes�tm�nyt �ll�tani. "+e);}
}
function add_village(FarmID){
	/*AddVill a cella, azon bel�l vannak input-ok (name-val): koord �s egyseg. */
	try{
	var koordchk=/[0-9]{1,3}(\|)[0-9]{1,3}/g;
	var egysegchk=/[0-9]+/g;
	var d=document.getElementById("AddVill");
	if (FarmID=="0"){ d.style.display="none"; return; }
	if (d.style.display=="none") {d.style.display="block"; return;}
	if (!koordchk.test(d.children[1].value) || !egysegchk.test(d.children[3].value)) throw "Hib�s megad�si form�tum.\n Koordin�ta: xxx|xxx. \nEgys�g: egy eg�sz sz�m";
	var dupla=false; var i=0;
	while (Y=document.getElementById(FarmID+"_T").rows[i]){
		if (Y.cells[1].innerHTML==d.children[1].value) dupla=true;
		i++;
	} if (dupla) if (!confirm("M�r szerepel ilyen koordin�ta, m�gis hozz�adod?")) return;
	i++;
	document.getElementById(FarmID+"_T").innerHTML+='<tr><td></td><td>'+d.children[1].value+'</td><td>'+d.children[3].value+'</td><td>Nincs</td><td>Nincs</td><td><a href="javascript: complete('+FarmID+','+i+');">'+kep("complete")+'</a><a href="javascript: del('+FarmID+','+i+');">'+kep("del")+'</a></td></tr>';
	d.children[3].value=""; d.children[1].value="";
	} catch(e){alert("Hiba falu hozz�ad�sakor:\n "+e);}
}

try{
	var talal=false; T=1;
	while (!talal && T<11){
		if (document.getElementById(T).innerHTML=="") talal=true; else T++;
	}if (!talal) throw "Nincs t�bb szabad hely!";
/*DIREKT-HELY*/
	T=3;
/*DIREKT-HELY*/
	var b=new Array();b[0] = new Array(518,617);b[1] = new Array(519,616);b[2] = new Array(520,617);b[3] = new Array(520,618);b[4] = new Array(518,618);b[5] = new Array(519,615);b[6] = new Array(517,617);b[7] = new Array(520,615);b[8] = new Array(516,617);b[9] = new Array(522,618);b[10] = new Array(518,620);b[11] = new Array(520,620);b[12] = new Array(517,614);b[13] = new Array(515,616);b[14] = new Array(520,621);b[15] = new Array(522,620);b[16] = new Array(516,620);b[17] = new Array(515,615);b[18] = new Array(521,621);b[19] = new Array(523,620);b[20] = new Array(519,622);b[21] = new Array(515,620);b[22] = new Array(516,621);b[23] = new Array(514,618);b[24] = new Array(524,618);b[25] = new Array(514,615);b[26] = new Array(524,619);b[27] = new Array(514,620);b[28] = new Array(521,624);b[29] = new Array(516,624);b[30] = new Array(513,612);b[31] = new Array(511,617);b[32] = new Array(526,621);b[33] = new Array(512,621);b[34] = new Array(527,618);b[35] = new Array(513,623);b[36] = new Array(511,620);b[37] = new Array(523,625);b[38] = new Array(510,617);b[39] = new Array(528,619);b[40] = new Array(526,623);b[41] = new Array(527,622);b[42] = new Array(524,625);b[43] = new Array(510,614);b[44] = new Array(515,626);b[45] = new Array(511,623);b[46] = new Array(527,624);b[47] = new Array(510,623);b[48] = new Array(511,625);b[49] = new Array(510,625);b[50] = new Array(510,625);
 var KL=new Array( 4, 7, 29, 38, 7, 6, 12, 5, 16, 6, 5, 4, 14, 41, 7, 37, 6, 7, 4, 6, 6, 5, 13, 3, 7, 31, 23, 5, 5, 6, 7, 4, 7, 5, 6, 4, 4, 11, 6, 5, 7, 5, 7, 8, 5, 6, 6, 5, 7, 6, 2);
 var faluazon=13564;var egyseg="light";var kemek=1;var helyettes="";var cirka="1";var gamers="NE";var d=new Date();
	x=document.getElementById(T);
	x.innerHTML='<div class="tablazat"><div class="info"><div class="bal">Inform�ci�s t�bla</div><div class="jobb"></div></div><div class="sor"><div class="bal">Munkateljes�tm�ny (%)</div><div class="jobb">50 '+kep("smile_2")+'</div></div><div class="sor"><div class="bal">Faluazonos�t�</div><div class="jobb">'+faluazon+'</div></div><div class="sor"><div class="bal">Egys�gt�pus</div><div class="jobb">'+egyseg+'</div></div><div class="sor"><div class="bal">K�ldend� k�mek</div><div class="jobb">'+kemek+'</div></div><div class="sor"><div class="bal">Helyettes�tett fi�k ID</div><div class="jobb">'+helyettes+'</div></div><div class="sor"><div class="bal">Cirkul�l�s (perc)</div><div class="jobb">'+cirka+'</div></div><div class="sor"><div class="bal">J�t�kos t�mad�sa</div><div class="jobb">'+gamers+'</div></div><div class="sor"><div class="bal">Script utols� k�re</div><div class="jobb">'+d.getFullYear()+"."+d.getMonth()+"."+d.getDate()+"."+d.getHours()+"."+d.getMinutes()+"."+d.getSeconds()+'</div></div></div>';
	x.innerHTML+='<tbody id="'+T+'_T"></tbody>';
	for (var i=0;i<KL.length;i++){
		document.getElementById(T+"_T").innerHTML+='<tr><td></td><td>'+b[i][0]+'|'+b[i][1]+'</td><td>'+KL[i]+'</td><td>Nincs</td><td>Nincs</td><td><a href="javascript: complete('+T+','+i+');">'+kep("complete")+'</a><a href="javascript: del('+T+','+i+');">'+kep("del")+'</a></td></tr>';
	} document.getElementById(T+"_T").rows[0].cells[0].innerHTML="O";
	x.innerHTML+='<br><a href="javascript: ugras_vissza('+T+');"><img src="http://cncdani2.freeiz.com/SZEM3/Backward.png" height="32px" title="Ugr�s visszafel�"/></a>���<a href="javascript: ugras('+T+');"><img src="http://cncdani2.freeiz.com/SZEM3/Forward.png"  height="32px" title="Ugr�s el�re"></a>���<a href="javascript: showExp('+T+');"><img src="http://cncdani2.freeiz.com/SZEM3/Export.png"  height="32px" alt="Export" title="Export�l�s"/></a>���<a href="javascript: showImp('+T+');"><img src="http://cncdani2.freeiz.com/SZEM3/Import.png" height="32px" alt="Import" title="Import�l�s"/></a>���<a href="javascript: modify_spy('+T+');"><img src="http://cncdani2.freeiz.com/SZEM3/spy.png" height="32px" alt="k�m" title="K�ldend� k�mek sz�mainak m�dos�t�sa"/></a>���<a href="javascript: add_village('+T+');"><img src="http://cncdani2.freeiz.com/SZEM3/Add.png" height="32px" alt="Hozz�ad" title="Egy falut hozz�adni a list�hoz"/></a>';
	document.getElementById('kieg').innerHTML+='<tr><td>Auto-Farm '+T+'</td><td><a href=\'javascript: stop("Farm'+T+'");\'>Le�ll�t�s</a></td><td>0</td></tr>';
	naplo("kieg","�j kieg�sz�t�: Auto-Farm "+T);
} catch(err) {alert("Hiba megnyit�skor:\n"+err); void(0);}

function open_window(ID){ 
	try{
		var urll=WEBPAGE;
		urll+="&screen=place";
		x=document.getElementById(ID).getElementsByTagName("div");
		for (var i=1;i<x.length;i++){
			if (x[i].getAttribute("class")=="sor") {
				if(x[i].children[0].innerHTML=="Helyettes�tett fi�k ID") var FSITTER=x[i].children[1].innerHTML;
				if(x[i].children[0].innerHTML=="Faluazonos�t�") var faluazon=x[i].children[1].innerHTML;
		}} if (FSITTER!="") urll+="&t="+FSITTER; urll=urll.replace(/(village=)[0-9]+/g,("village="+faluazon));
		if (FSITTER==undefined || faluazon==undefined) throw "Nem tal�lok adatokat az info-t�bl�ba.";
		aktualis=window.open(urll,ID);
		return aktualis;
	} catch(e) { naplo("hiba","Auto-farm "+ID+": SZEM3 szerkezete hib�snak �t�lve. "+e); addError(1,"Farm"+ID); }
}
function fill_place(ID,lapref){
	try{
		if (bote) return 0;
		var i=0;
		var i=0; var avg=0; 
		while (x=document.getElementById(ID+"_T").rows[i]){
			if (x.cells[2].innerHTML!="Nincs") avg+=parseInt(x.cells[2].innerHTML);
			i++;
		} if (avg>0) {avg=Math.floor(avg/i);} else avg=0; /*�tlag EGYS�GSZ�M!*/
		/*Adatlek�r�s*/
		Y=document.getElementById(ID).getElementsByTagName("div");
		for (z=1;z<Y.length;z++){
			if (Y[z].getAttribute("class")=="sor") {
				if(Y[z].children[0].innerHTML=="Egys�gt�pus")   var egyseg=Y[z].children[1].innerHTML;
				if(Y[z].children[0].innerHTML=="K�ldend� k�mek") var kem=Y[z].children[1].innerHTML;
		}}
		/*END OF Adatlek�r�s*/
		switch (egyseg){ /*�tlag egy�g -> �tlag nyers.*/
			case 'spear':	avg*=25; break;
			case 'sword':	avg*=15; break;
			case 'axe':		avg*=10; break;
			case 'archer':	avg*=10; break;
			case 'light':	avg*=80; break;
			case 'marcher':	avg*=50; break;
			case 'heavy':	avg*=50; break;
			default: throw "Ismeretlen egys�g";
		}
		
		var k=0; var max=0; while (x=document.getElementById(ID+"_T").rows[k]){/*max keres�s, i hellyel*/
			if (x.cells[4].innerHTML!="Nincs") if (parseInt(x.cells[4].innerHTML)>max) {i=k; max=parseInt(x.cells[4].innerHTML);}
			k++;
		}
/* Keress�k az i-t! Ha a max > avg*2, akkor m�r meg is van - ellenben keress�k hol j�runk (az O-t)
   Az O ugr�skor az utols� ut�n ugrik: elt�nik! Ilyenkor lehet nemtal�l. Ekkor j� lenne ha ablakot se nyitna. ~~>k�s�bb...*/		
		var talal=false; var maxi=false;
		if (max<(avg*2)) { /*O helyzet�t kell megkeresni. Ha nincs, nincs munka! ELSE max-ot fosztunk*/
			var i=0;
			while(!(talal) && (x=document.getElementById(ID+"_T").rows[i])){
				if (x.cells[0].innerHTML=="O") talal=true; else i++;
			}
		} else {talal=true; maxi=true;}
		if (!talal) {munka(ID,-1); ugras(ID); return 0;}
/* Biztos hogy megvan az i, �s biztos h t�madnunk is kell. maxi==true, ha csak a jelent�s nyers�t hozzuk.*/
		x=document.getElementById(ID+"_T").rows[i];

		if (x.cells[3].innerHTML=="R" || x.cells[3].innerHTML=="X") {ugras(ID); return 0;}
		E=lapref.document.forms["units"];
		E.x.value=x.cells[1].innerHTML.split("|")[0]; E.y.value=x.cells[1].innerHTML.split("|")[1];
		KL=x.cells[2].innerHTML; KL=parseInt(KL); Enyers=x.cells[4].innerHTML;
		if (Enyers!="Nincs") { Enyers=parseInt(Enyers); switch (egyseg){
			case 'spear':	var KL_extra=Math.floor(Enyers/25); break;
			case 'sword':	var KL_extra=Math.floor(Enyers/15); break;
			case 'axe':		var KL_extra=Math.floor(Enyers/10); break;
			case 'archer':	var KL_extra=Math.floor(Enyers/10); break;
			case 'light':	var KL_extra=Math.floor(Enyers/80); break;
			case 'marcher':	var KL_extra=Math.floor(Enyers/50); break;
			case 'heavy':	var KL_extra=Math.floor(Enyers/50); break;
			default:	var KL_extra=0;}} else KL_extra=0;
		if (maxi) KL=KL_extra; else KL+=KL_extra;
		/*Van e el�g egys�g?*/
		if (parseInt(lapref.document.getElementById("unit_input_"+egyseg).parentNode.children[2].innerHTML.match(/[0-9]+/g)[0])<KL) {munka(ID,1); isido(ID); return 0; }
		if (parseInt(lapref.document.getElementById("unit_input_spy").parentNode.children[2].innerHTML.match(/[0-9]+/g)[0])<kem) {munka(ID,1); isido(ID); return 0;}
		/*Van e el�g egys�g?*/
		lapref.document.getElementById("unit_input_"+egyseg).value=KL;
		if (maxi) kem=0;
		E.spy.value=kem;
		E.attack.click();
		addError(-1,"Farm"+ID,lapref);
		if (maxi) return 2; else return 1;
	} catch(e) {
		addError(2,"Farm"+ID,lapref);
		return 0;
	}
}
function isGamer(REF,ID){
	try{
	var Y=document.getElementById(ID).getElementsByTagName("div"); var z=1;
	for (z=1;z<Y.length;z++){
		if (Y[z].getAttribute("class")=="sor") {
			if(Y[z].children[0].innerHTML=="J�t�kos t�mad�sa") var doc=Y[z].children[1].innerHTML;
	}}
	if (doc=="IGEN") return false;
	var patt5=/info_player/g; 
	if (patt5.test(REF.document.getElementById("content_value").getElementsByTagName("table")[0].innerHTML)) return true; else return false;
	} catch(e) { adderror(1,"Farm"+ID,REF); return false;}
}
function check_result(ID,lapref,isMax){
	try{
		if (bote) return;
		var talal=false; var i=0;
		if (isMax){
		var max=0; var k=0;
		while (x=document.getElementById(ID+"_T").rows[k]){
			if (x.cells[4].innerHTML!="Nincs") if (parseInt(x.cells[4].innerHTML)>max) {i=k; max=parseInt(x.cells[4].innerHTML);}
			k++;
		}
		} else {
		while (!talal && (x=document.getElementById(ID+"_T").rows[i])){
			if (x.cells[0].innerHTML=="O") talal=true; else i++;
		}}
		x=document.getElementById(ID+"_T").rows[i];
		var teszt=lapref.document.getElementById("content_value").innerHTML;
		var patt=/Gy�lekez�hely/g;
		if (!(patt.test(teszt))) {
			x.cells[4].innerHTML="Nincs";
			if (!isMax) ugras(ID);
			if (isGamer(lapref,ID)) { x.cells[3].innerHTML="X"; naplo("szem","Auto-Farm "+ID+": J�t�kost �szleltem "+x.cells[1].innerHTML+" helyen."); return;}
			lapref.document.forms[0].submit.click();
		} else if (lapref.document.getElementById("error")) {
			munka(ID,1);
			hiba=lapref.document.getElementById("error").innerHTML;
			patt1=/A t�mad� seregnek/; patt2=/csak akkor t�madhat�/; patt3=/nem l�tezik/; patt4=/Ez a c�lpont m�g/;
			/*X=lapref.document.getElementById("inputx").value;
			Y=lapref.document.getElementById("inputy").value;*/
			if (patt1.test(hiba) || patt2.test(hiba) || patt3.test(hiba) || patt4.test(hiba)) {
				if (isGamer(lapref,ID)) naplo("szem","Auto-farm "+ID+": J�t�kost �szleltem "+maplink(x.cells[1].innerHTML)+" helyen, melyet nem is t�madhatn�l."); else naplo("szem","Auto-farm "+ID+": Nem t�madhatod  tov�bb "+maplink(x.cells[1].innerHTML)+" falut, ellen�rizd. Falu kihagyva."); 
				x.cells[3].innerHTML="X"; if (isMax) x.cells[4].innerHTML="Nincs"; else ugras(ID);}
		}
		isido(ID);
		addError(-1,"Farm"+ID);
	} catch (e) {addError(1,"Farm"+ID,lapref);}
}
try{
switch (T){
	case 1: function munka1(){ var ido1 = (Math.floor(Math.random()*21)+10)*1000; if (!bote) { lap1=open_window(1); setTimeout("isbot(lap1)",1800); setTimeout("var IsOk=fill_place(1,lap1)",2000); setTimeout("if (IsOk==1) check_result(1,lap1,false); else if (IsOk==2) check_result(1,lap1,true);",5555);} i1=setTimeout("munka1()",ido1);} munka1(); break;
	case 2: function munka2(){ var ido2 = (Math.floor(Math.random()*21)+10)*1000; if (!bote) { lap2=open_window(2); setTimeout("isbot(lap2)",1800); setTimeout("var IsOk=fill_place(2,lap2)",2000); setTimeout("if (IsOk==1) check_result(2,lap2,false); else if (IsOk==2) check_result(2,lap2,true);",5555);} i2=setTimeout("munka2()",ido2);} munka2(); break;
	case 3: function munka3(){ var ido3 = (Math.floor(Math.random()*21)+10)*1000; if (!bote) { lap3=open_window(3); setTimeout("isbot(lap3)",1800); setTimeout("var IsOk=fill_place(3,lap3)",2000); setTimeout("if (IsOk==1) check_result(3,lap3,false); else if (IsOk==2) check_result(3,lap3,true);",5555);} i3=setTimeout("munka3()",ido3);} munka3(); break;
	case 4: function munka4(){ var ido4 = (Math.floor(Math.random()*21)+10)*1000; if (!bote) { lap4=open_window(4); setTimeout("isbot(lap4)",1800); setTimeout("var IsOk=fill_place(4,lap4)",2000); setTimeout("if (IsOk==1) check_result(4,lap4,false); else if (IsOk==2) check_result(4,lap4,true);",5555);} i4=setTimeout("munka4()",ido4);} munka4(); break;
	case 5: function munka5(){ var ido5 = (Math.floor(Math.random()*21)+10)*1000; if (!bote) { lap5=open_window(5); setTimeout("isbot(lap5)",1800); setTimeout("var IsOk=fill_place(5,lap5)",2000); setTimeout("if (IsOk==1) check_result(5,lap5,false); else if (IsOk==2) check_result(5,lap5,true);",5555);} i5=setTimeout("munka5()",ido5);} munka5(); break;
	case 6: function munka6(){ var ido6 = (Math.floor(Math.random()*21)+10)*1000; if (!bote) { lap6=open_window(6); setTimeout("isbot(lap6)",1800); setTimeout("var IsOk=fill_place(6,lap6)",2000); setTimeout("if (IsOk==1) check_result(6,lap6,false); else if (IsOk==2) check_result(6,lap6,true);",5555);} i6=setTimeout("munka6()",ido6);} munka6(); break;
	case 7: function munka7(){ var ido7 = (Math.floor(Math.random()*21)+10)*1000; if (!bote) { lap7=open_window(7); setTimeout("isbot(lap7)",1800); setTimeout("var IsOk=fill_place(7,lap7)",2000); setTimeout("if (IsOk==1) check_result(7,lap7,false); else if (IsOk==2) check_result(7,lap7,true);",5555);} i7=setTimeout("munka7()",ido7);} munka7(); break;
	case 8: function munka8(){ var ido8 = (Math.floor(Math.random()*21)+10)*1000; if (!bote) { lap8=open_window(8); setTimeout("isbot(lap8)",1800); setTimeout("var IsOk=fill_place(8,lap8)",2000); setTimeout("if (IsOk==1) check_result(8,lap8,false); else if (IsOk==2) check_result(8,lap8,true);",5555);} i8=setTimeout("munka8()",ido8);} munka8(); break;
	case 9: function munka9(){ var ido9 = (Math.floor(Math.random()*21)+10)*1000; if (!bote) { lap9=open_window(9); setTimeout("isbot(lap9)",1800); setTimeout("var IsOk=fill_place(9,lap9)",2000); setTimeout("if (IsOk==1) check_result(9,lap9,false); else if (IsOk==2) check_result(9,lap9,true);",5555);} i9=setTimeout("munka9()",ido9);} munka9(); break;
	case 10: function munka10(){ var ido10 = (Math.floor(Math.random()*21)+10)*1000; if (!bote) { lap10=open_window(10); setTimeout("isbot(lap10)",1800); setTimeout("var IsOk=fill_place(10,lap10)",2000); setTimeout("if (IsOk==1) check_result(10,lap10,false); else if (IsOk==2) check_result(10,lap10,true);",5555);} i10=setTimeout("munka10()",ido10);} munka10(); break;
	default: throw "Nem tal�lok helyet a cell�k k�zt.";
}}catch(err) { naplo("hiba","V�gzetes hiba l�pett fel az Auto-farm ind�t�sakor: "+err); void(0);}
void(0);