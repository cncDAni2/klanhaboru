javascript:
function feltolt(ezt,ezt2,a0,a1,a2,a3,a4,a5,a6,a7,a8,a9,aA,aB){
	honnan.push(ezt);
	hova.push(ezt2);
	l.push(a0); k.push(a1); b.push(a2); ij.push(a3); kem.push(a4); kl.push(a5); lij.push(a6); nl.push(a7); kos.push(a8); kata.push(a9); nemes.push(aA); lovag.push(aB); 
	return;
}
if (LEPES == undefined) {
		var d=document;	
		if(window.frames.length>0) d=window.main.document;
		url=d.URL;
		if(url.indexOf('screen=overview_villages')==-1) {
			alert('�ttekint�sben kell futtatni a scriptet!');
			exit(0);
		}
		var LEPES=1;
}
function openIt(no,je){
	oldal=faluk[no].cells[sor].getElementsByTagName("a")[0].href.replace("overview","place");
	neve="web" + je;
	RefArray[je]=window.open(oldal,neve);
	return;
}

if (LEPES==1) {try{
	var RefArray=new Array();
	var honnan = new Array();
	var hova = new Array();
	l = new Array(); k = new Array(); b = new Array(); ij = new Array(); kem = new Array(); kl = new Array(); lij = new Array(); nl = new Array(); kos = new Array(); kata = new Array(); nemes = new Array(); lovag = new Array();
	
	 feltolt("515|386","513|382",0,0,"max",0,0,0,0,0,0,0,0,0); 
	 feltolt("515|386","513|382",0,0,"max",0,0,0,0,0,0,0,0,0); 
	 feltolt("515|386","513|382",0,0,"max",0,0,0,0,0,0,0,0,0); 
	
	var szam=honnan.length;
	/*ID Meg�llap�t�s*/
	var faluk=document.getElementById("production_table").rows;
	if (faluk[0].cells.length==10) sor=1; else sor=0;
	ok=false;
	CIK = 0;
	for (var i=0;i<szam;i++){
		setTimeout(function(){
			for (var j=1;j<faluk.length;j++){
				if (faluk[j].cells[sor].innerText.match(/[0-9]+(\|)[0-9]+/g).indexOf(honnan[CIK])>-1){
					openIt(j,CIK);
					ok=true; break;
				}
			}
			CIK++;
		},250*i,'JScript');
		
		if (!ok) RefArray[i]=false;
	}
	LEPES=2;
}catch(e){alert(e);}} else if (LEPES==2) {try{
	var ijasz=true; var lovagok=true;
	CIK=0;
	for (i=0;i<szam;i++){
		if(RefArray[i]==false) {CIK++; continue;}
		rov=RefArray[i].document;
		rov.forms[0].x.value=hova[i].split("|")[0];
		rov.forms[0].y.value=hova[i].split("|")[1];
		
		if (l[i]=="max") l[i]=rov.getElementById("units_entry_all_spear").innerText.match(/[0-9]+/g)[0];
		if (k[i]=="max") k[i]=rov.getElementById("units_entry_all_sword").innerText.match(/[0-9]+/g)[0];
		if (b[i]=="max") b[i]=rov.getElementById("units_entry_all_axe").innerText.match(/[0-9]+/g)[0];		
		if (ijasz){try{
			if (rov.getElementById("units_entry_all_archer") == null) throw "NoArcher";
			if (ij[i]=="max") ij[i]=rov.getElementById("units_entry_all_archer").innerText.match(/[0-9]+/g)[0];
			if (lij[i]=="max") lij[i]=rov.getElementById("units_entry_all_marcher").innerText.match(/[0-9]+/g)[0];
		}catch(e){ijasz=false;}}
		if (kem[i]=="max") kem[i]=rov.getElementById("units_entry_all_spy").innerText.match(/[0-9]+/g)[0];
		if (kl[i]=="max") kl[i]=rov.getElementById("units_entry_all_light").innerText.match(/[0-9]+/g)[0];		
		if (nl[i]=="max") nl[i]=rov.getElementById("units_entry_all_heavy").innerText.match(/[0-9]+/g)[0];
		if (kos[i]=="max") kos[i]=rov.getElementById("units_entry_all_ram").innerText.match(/[0-9]+/g)[0];
		if (kata[i]=="max") kata[i]=rov.getElementById("units_entry_all_catapult").innerText.match(/[0-9]+/g)[0];
		if (nemes[i]=="max") nemes[i]=rov.getElementById("units_entry_all_snob").innerText.match(/[0-9]+/g)[0];
		if (lovagok){try{ temp=rov.getElementById("units_entry_all_knight").innerText.match(/[0-9]+/g)[0];
		if (lovag[i]=="max") lovag[i]=rov.getElementById("units_entry_all_knight").innerText.match(/[0-9]+/g)[0];}catch(e){lovagok=false;}}
		
		rov.forms[0].spear.value=l[i];
		rov.forms[0].sword.value=k[i];
		rov.forms[0].axe.value=b[i];
		if (ijasz){rov.forms[0].archer.value=ij[i];
		rov.forms[0].marcher.value=lij[i];}
		
		rov.forms[0].spy.value=kem[i];
		rov.forms[0].light.value=kl[i];
		rov.forms[0].heavy.value=nl[i];
		
		rov.forms[0].ram.value=kos[i];
		rov.forms[0].catapult.value=kata[i];
		
		rov.forms[0].snob.value=nemes[i];
		if(lovagok) rov.forms[0].knight.value=lovag[i];
		
		setTimeout(function(){
			RefArray[CIK].document.forms[0].attack.click();
			CIK++;
		}, 200*i);
	}
	LEPES=3;
}catch(e){alert(e);}} else if (LEPES==3) {
	function elkuld(){
		if (i>=szam) {clearInterval(ZZ);return;}
		if (RefArray[i]==false) return;
		try{RefArray[i].document.forms[0].submit.click();}catch(e){
			document.getElementById("header_info").innerHTML+="<br>Gond van <b>"+honnan[i]+"</b> faluban! -- "+RefArray[i].document.getElementById("error").innerText;
		}
		i++;
		return;
	}
	var i=0;
	LEPES=4;
	ZZ=setInterval("elkuld()",300);
} else if (LEPES==4) {
	for (var i=0;i<szam;i++){
		RefArray[i].close();
	}
}
void(0);