javascript:
function setCookie(name, value, expire) {
	document.cookie = name + "=" + escape(value)
	+ ((expire == null) ? "" : ("; expires=" + expire.toGMTString()));
}

function getCookie(Name){
	var search = Name + "=";
	if (document.cookie.length > 0) {
		offset = document.cookie.indexOf(search);
		if (offset != -1) {
			offset += search.length;
			end = document.cookie.indexOf(";", offset);
			if (end == -1) end = document.cookie.length;
			return unescape(document.cookie.substring(offset, end));
		}
	}
}
	
function kuld(celpont,XX,YY){
	expDate = new Date();
	expDate.setTime(expDate.getTime() + (60*1000));
	VISITED = getCookie('visited');
	if (VISITED==null || VISITED=="") {
		VISITED=0;
	} else {
		VISITED++;
	}
	if (VISITED >= (hossz)){
			LEPES++;
			setCookie('lepes', LEPES, expDate);
			expDate = new Date(); 
			expDate.setTime(expDate.getTime() - (100));
			setCookie('visited', 0, expDate);
			if (d.forms[0].name!='units') {
					d.forms[0].elements['building'].value=celpont;
					d.forms[0].submit.click();
					}
	} else {
		setCookie('visited', VISITED, expDate);
		if(d.forms[0].name=='units')
		{
		d.forms[0].x.value=XX;
		d.forms[0].y.value=YY;
		d.forms[0].catapult.value=KL[VISITED];
		d.forms[0].attack.click();
		} else {
		d.forms[0].elements['building'].value=celpont;
		d.forms[0].submit.click();
		setCookie('visited', VISITED-1, expDate);
	}}
}
	
	var d=document;	
	if(window.frames.length>0) d=window.main.document;
	url=d.URL;
	if(url.indexOf('screen=place')==-1) {
		alert('Gy�l. helyen pr�b�ld...');
		exit(0);
	}
	LEPES = getCookie('lepes');
	
	MAXDB=10;
	
	if (LEPES==null || LEPES=="") LEPES=1;
	if (LEPES>MAXDB) {
		alert("Katapultoz�s k�sz.\n A script �jraindul...");
		expDate = new Date();
		expDate.setTime(expDate.getTime() + (100));
		setCookie('visited', 0, expDate);
		expDate = new Date();
		expDate.setTime(expDate.getTime() + (100));
		setCookie('lepes', 0, expDate);
	} else {
		if (LEPES==1){
			var KL=new Array(2,1); hossz=KL.length; kuld('smith',318,379);
		} else if (LEPES==2) {
			var KL=new Array(3,1); hossz=KL.length; kuld('market',319,379);
		} else if (LEPES==3) {
			var KL=new Array(3,2,2,2); hossz=KL.length; kuld('smith',123,123);
		} else if (LEPES==4) {
			var KL=new Array(3,2,2,2); hossz=KL.length; kuld('smith',123,123);
		} else if (LEPES==5) {
			var KL=new Array(3,2,2,2); hossz=KL.length; kuld('smith',123,123);
		} else if (LEPES==6) {
			var KL=new Array(3,2,2,2); hossz=KL.length; kuld('smith',123,123);
		} else if (LEPES==7) {
			var KL=new Array(3,2,2,2); hossz=KL.length; kuld('smith',123,123);
		} else if (LEPES==8) {
			var KL=new Array(3,2,2,2); hossz=KL.length; kuld('smith',123,123);
		} else if (LEPES==9) {
			var KL=new Array(3,2,2,2); hossz=KL.length; kuld('smith',123,123);
		} else if (LEPES==10) {
			var KL=new Array(3,2,2,2); hossz=KL.length; kuld('smith',123,123);
		} else alert("Bazz.....");
	}
	void(0);
/*	NEM M�K�DIK VALAMI�RT
	switch (LEPES)
		{
			case 1: var KL=new Array(2,1); hossz=KL.length; kuld('smith',318,379); break;
			case 2: var KL=new Array(3,1); hossz=KL.length; kuld('market',319,379); break;
			case 3: var KL=new Array(3,2,2,2); hossz=KL.length; kuld('smith',123,123); break;
			case 4: var KL=new Array(3,2,2,2); hossz=KL.length; kuld('smith',123,123); break;
			case 5: var KL=new Array(3,2,2,2); hossz=KL.length; kuld('smith',123,123); break;
			case 6: var KL=new Array(3,2,2,2); hossz=KL.length; kuld('smith',123,123); break;
			case 7: var KL=new Array(3,2,2,2); hossz=KL.length; kuld('smith',123,123); break;
			case 8: var KL=new Array(3,2,2,2); hossz=KL.length; kuld('smith',123,123); break;
			case 9: var KL=new Array(3,2,2,2); hossz=KL.length; kuld('smith',123,123); break;
		   case 10: var KL=new Array(3,2,2,2); hossz=KL.length; kuld('smith',123,123); break;
		   default: alerts("Nem tudom eld�nteni hogy mi ez!");
		}		*/