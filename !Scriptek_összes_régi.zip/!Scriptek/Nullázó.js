javascript:
if (typeof(expDate)!="undefined") exit(0);
function setCookie(name, value, expire) {
	document.cookie = name + "=" + escape(value)
	+ ((expire == null) ? "" : ("; expires=" + expire.toGMTString()));
}

function getCookies(){
  var pairs = document.cookie.split(";");
  var cookies = new Array();
  for (var i=0; i<pairs.length; i++){
    var pair = pairs[i].split("=");
    cookies[i] = pair[0]+";"+pair[1]; /*pair 1: need unescape*/
  }
  return cookies;
}

function torol(tipus,nev,cella){try{
	if (tipus=="suti"){
		setCookie(nev,"",expDate);
		cella.innerHTML="T�r�lve";
	}
	if (tipus=="LS"){
		localStorage.removeItem(nev);
		cella.innerHTML="T�r�lve";
	}
	return;
}catch(e){alert(e);}}

function init(){try{
	document.getElementsByTagName("body")[0].innerHTML+='<div id="nullazo" style="width: 1000px; background-color: #CDE; color: black; position: absolute; left:10%; top:10%; border:3px solid black; padding: 10px; z-index:500;"><div id="nullazofej" style="width: 100%; text-align:center; background: #FFF"><h2>NULL�Z�</h2><br></div><table style="width:100%" id="eredm"><tr><th>T�pus</th><th>N�v</th><th>Tartalom</th><th style="width:165px">Le�r�s</th><th>T�rl�s</th></tr></table><br>C&amp;C M�hely ~ cncDAni2<div style="height: 50px; margin: 0 0 -50px 0; background:transparent;"></div></div>';
	var tabla=document.getElementById("eredm");
	
	for (var i=0;i<SUTIK.length;i++){
		var row=tabla.insertRow(-1); row.style.backgroundColor="#BCD";
		var n=SUTIK[i].split(";")[0];
		var cell=row.insertCell(0); cell.innerHTML="S�ti";
		var cell=row.insertCell(1); cell.innerHTML=n;
		var cell=row.insertCell(2); cell.innerHTML='<div style="width:500px; word-wrap: break-word;">'+unescape(SUTIK[i].split(";")[1])+'</div>';
		var cell=row.insertCell(3);
			if (n=="memo_selection" || n.indexOf("tracking_page")>-1 || n.indexOf("ref")>-1 || n.indexOf("mobile")>-1 || n.indexOf("global_village_id")>-1 || n.indexOf("__utm")>-1 || n.indexOf("portal_")>0)
				cell.innerHTML="Kl�nh�bor� rendszer-s�ti";
			else if (n=="visited") cell.innerHTML="<b>Tech2 scriptekhez haszn�lt seg�ds�ti</b>";
			else if (n=="lepes") cell.innerHTML="<b>Tech2/Katapultoz� �ltal haszn�lt l�p�ssz�ml�l� s�ti</b>";
			else if (n=="falu0") cell.innerHTML="<b>Tech2/Tanul� farmol� �ltal haszn�lt seg�ds�ti</b>";
			else cell.innerHTML="<i>Ismeretlen</i>";
		var cell=row.insertCell(4); cell.innerHTML='<a style="cursor: pointer;" onclick="torol(\'suti\',\''+n+'\',this.parentNode)">X T�rl�s</a>';
	}
	for (var i=0;i<LSK.length-1;i++){
		var row=tabla.insertRow(-1); row.style.backgroundColor="#FAA";
		var cell=row.insertCell(0); cell.innerHTML="LocalStorage";
		var cell=row.insertCell(1); cell.innerHTML=LSK[i];
		var cell=row.insertCell(2); cell.innerHTML='<div style="width:500px; word-wrap: break-word;">'+unescape(localStorage.getItem(LSK[i]))+'</div>';
		var cell=row.insertCell(3); 
			if (LSK[i].indexOf("cnc_csoport")>-1) cell.innerHTML="<b>Csoportkezel� adata</b>";
			else if (LSK[i].indexOf("SZEM3_epito")>-1) cell.innerHTML="<b>SZEM3 �p�t�j�nek list�ja</b>";
			else if (LSK[i].indexOf("cnc_ID")>-1) cell.innerHTML="<b>ID Kalkul�tor lementett id�:ID p�rosai.</b>";
			else cell.innerHTML="<i>Ismeretlen</i>";
		var cell=row.insertCell(4); cell.innerHTML='<a style="cursor: pointer;" onclick="javascript: torol(\'LS\',\''+LSK[i]+'\',this.parentNode)">X T�rl�s</a>';
	}
	return;
}catch(e){alert("Hiba:\n"+e);}}


var expDate = new Date();
expDate.setTime(expDate.getTime() - 3600);
/*visited: Norm�l farm; lepes: kat�kn�l, falu0: Tanul� farmol� script*/

var SUTIK = getCookies();
var LSK = Object.keys(localStorage);
if (confirm("Csak gyorst�rl�s?")){
	setCookie("lepes","",expDate);
	setCookie("visited","",expDate);
	setCookie("falu0","",expDate);
} else {
init();
}


$(document).ready(function(){
	$(function() {
        $("#nullazo").draggable({handle: $('#nullazofej')});
	}); 
});
void(0);
