javascript:
document.getElementsByTagName("body")[0].innerHTML+='<div id="IDLearner" style="width: 300px; background-color: #333; color: white; font-weight:bold; position: fixed; left:10%; top:10%; border:3px solid black; padding: 10px; z-index:500;">ID K�VETKEZTET�<BR><table style="background-color: black;"><tr><th>Id�pont</th><th>ID</th></tr></table><br><b>�j ID felv�tele: (Id�, ID)</b><br><input type="text" id="LearnerIDO"><input type="text" size="10" id="LearnerID"><input type="button" value="Felvisz" onclick="addID()"><br><br>Melyik ID idej�re vagy k�v�ncsi?<input type="text" id="QID" value=""> <input type="button" value="Calculate (Rename)" onclick="calc()"></div>';
$(function() {
        $( "#IDLearner" ).draggable();
});

inic();
betolt();
/*F�rum beolvas�s/komment ideje: match(sz�mok) -> ha 2db van akkor az mai; ha 5, akkor az nap;h�+1;�v id�. Ha nem csak-sz�m a bejegyz�s, jel�lje meg piros h�tt�rrel.*/
function inic(){
	var jelenido=document.getElementById("serverDate").innerHTML+" "+document.getElementById("serverTime").innerHTML;
	var datum=jelenido.match(/[0-9]+/g);
	var CT = new Date(datum[2],datum[1]-1,datum[0],datum[3],datum[4],datum[5],0);
	document.getElementById("LearnerIDO").value=CT.getFullYear()+"."+(CT.getMonth()+1)+"."+CT.getDate()+". "+CT.getHours()+":"+CT.getMinutes();
	
	if (document.location.href.indexOf("screen=info_command")>0) document.getElementById("QID").value=document.location.href.match(/id=[0-9]+/g)[0].replace("id=","");
}

function addID(){
	try{
		var ID=document.getElementById("LearnerID").value;
		var IDO=document.getElementById("LearnerIDO").value;
		if (ID=="" || IDO=="") throw "NoData"; 
		if (isNaN(ID)) throw "BadID";
		var datum=IDO.match(/[0-9]+/g); if (datum.length!=5) throw "InvalidData";
		for (i=0;i<5;i++){
			datum[i]=datum[i].replace(/^0*/g,"");
			if (isNaN(datum[i])) throw "BadData"; else datum[i]=parseInt(datum[i]); 
			if (datum[i]<0) throw "NegativeDate";
		}
	if (datum[1]>12 || datum[2]>31 || datum[3]>23 || datum[4]>59) throw "badData";
	} catch(e){alert("Bad data added\n"+e); return;}
	/*Data OK*/
	var X2=document.getElementById("IDLearner").getElementsByTagName("table")[0];
	var newRow=X2.insertRow(-1);
	newRow.setAttribute("ondblclick","torol(this)");
	var newLine=newRow.insertCell(0);
	newLine.innerHTML=IDO;
	newLine=newRow.insertCell(1);
	newLine.innerHTML=ID;
	lement();
	return;
}

function torol(x){
	document.getElementById("IDLearner").getElementsByTagName("table")[0].deleteRow(x.rowIndex);
	lement();
	return;
}

function lement(){
	var str="";
	var X3=document.getElementById("IDLearner").getElementsByTagName("table")[0];
	for (var i=1;i<X3.rows.length;i++){
		str+=X3.rows[i].cells[0].innerHTML+";"+X3.rows[i].cells[1].innerHTML+"_";
	}
	localStorage.setItem("cnc_ID",str);
	return;
}
function betolt(){try{
	var str=localStorage.getItem("cnc_ID");
	if (str==undefined) return;
	var sorok=str.split("_");
	var X2=document.getElementById("IDLearner").getElementsByTagName("table")[0];
	for (var i=0;i<sorok.length-1;i++){
		var newRow=X2.insertRow(-1);
		newRow.setAttribute("ondblclick","torol(this)");
		var newLine=newRow.insertCell(0);
		newLine.innerHTML=sorok[i].split(";")[0];
		newLine=newRow.insertCell(1);
		newLine.innerHTML=sorok[i].split(";")[1];
	}
	return;
}catch(e){alert("Bet�lt�si hiba\n"+e);}}

function calc(){
	try{var X3=document.getElementById("IDLearner").getElementsByTagName("table")[0];
	if (X3.rows.length<3) throw "T�l kev�s adat van megadva a sz�m�t�shoz.";
	KID=parseInt(document.getElementById("QID").value);
	
	/*1. K�t legk�zelebbi ID megtal�l�sa*/
	var min2ID=new Array(); var min2Date=new Array();
	var minID=1;
	for (var i=2;i<X3.rows.length;i++){
		var ii=parseInt(X3.rows[i].cells[1].innerHTML);
		if (ii==KID) {alert("Ez az ID megtal�lhat� az adatb�zisba. Ind�t�si ideje:\n"+X3.rows[i].cells[0].innerHTML); return;}
		ii=Math.abs(ii-KID);
		if (ii<Math.abs(KID-X3.rows[minID].cells[1].innerHTML)) minID=i;
	}
	min2ID[0]=X3.rows[minID].cells[1].innerHTML; min2Date[0]=X3.rows[minID].cells[0].innerHTML;
	
	if (minID==1) var minID2nd=2; else var minID2nd=1;
	for (i=1;i<X3.rows.length;i++){
		if (minID==i) continue;
		var ii=parseInt(X3.rows[i].cells[1].innerHTML);
		ii=Math.abs(ii-KID);
		if (ii<Math.abs(KID-X3.rows[minID2nd].cells[1].innerHTML)) minID2nd=i;
	}
	min2ID[1]=X3.rows[minID2nd].cells[1].innerHTML; min2Date[1]=X3.rows[minID2nd].cells[0].innerHTML;
	var csere=true;
	if (min2ID[0]>min2ID[1]) {var temp=min2ID[0]; min2ID[0]=min2ID[1];min2ID[1]=temp; temp=min2Date[0]; min2Date[0]=min2Date[1];min2Date[1]=temp;} else csere=false;
	
	var db=min2Date[0].match(/[0-9]+/g);
	min2Date[0]=new Date(db[0],db[1]-1,db[2],db[3],db[4],0,0);
	var db=min2Date[1].match(/[0-9]+/g);
	min2Date[1]=new Date(db[0],db[1]-1,db[2],db[3],db[4],0,0);
	
	/*2. Eltelt perc*/
	var Eperc=Math.round((min2Date[1]-min2Date[0])/60000);
	
	/*3. n�vekm�ny*/
	var nov=(min2ID[1]-min2ID[0])/Eperc;
	
	/*4. Percv�ltoz�s */
	var Pvalt=KID-parseInt(X3.rows[minID].cells[1].innerHTML);
	Pvalt=Math.round(Pvalt/nov);
	
	/*5. V�gs� id�meg�llapt�s*/
	
	if (csere){
		min2Date[1].setMinutes(min2Date[1].getMinutes()+Pvalt);
		var vegido=min2Date[1];
	} else {
		min2Date[0].setMinutes(min2Date[0].getMinutes()+Pvalt);
		var vegido=min2Date[0];
	}
	
	alert("A t�mad�s becs�lt ind�t�si ideje: \n"+vegido);
}catch(e){alert("Error:\n"+e); return;}}

void(0);