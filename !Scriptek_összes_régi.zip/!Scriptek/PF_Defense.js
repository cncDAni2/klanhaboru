javascript:
A=document.getElementById("units_table").rows;
var defarray = {"spear" : "15,45,20", "sword" : "50,15,40", "axe":"10,5,10", "archer":"50,40,5", "spy":"2,1,2", "light":"30,40,30", "marcher":"40,30,50", "heavy":"200,80,180", "ram":"20,50,20", "catapult":"100,50,100", "knight":"250,400,150", "snob": "100,50,100", "militia":"15,45,25"};
var defi=new Array(0,0,0);
var archer=false;
var egyseg=new Array();
var ossz=0; var extra="";
if (document.location.href.indexOf("mode=units")==-1) {alert("\"Csapatok\"\\\"A faluban\"-ba kell futtatni a scriptet!"); exit(0);}
if (document.location.href.indexOf("type=complete")>0) {alert("\"�sszesen\" n�zetbe ez a script nem m�k�dik. Javasolt a \"Faluban\" n�zet!"); exit(0);}
try{
var cik=A[0].cells.length-1;
for (var i=2;i<cik;i++){
	egyseg[i-2]=A[0].cells[i].getElementsByTagName("img")[0].getAttribute("src").match(/unit_[a-z]+/g)[0].replace("unit_","");
	if (egyseg[i-2]=="archer") archer=true;
}
A[0].cells[1].innerHTML="V�delem";
for (var i=1;i<A.length;i++){
	for (var j=2;j<cik;j++){
		defi[0]+=parseInt(defarray[egyseg[j-2]].split(",")[0])*parseInt(A[i].cells[j].innerHTML);
		defi[1]+=parseInt(defarray[egyseg[j-2]].split(",")[1])*parseInt(A[i].cells[j].innerHTML);
		defi[2]+=parseInt(defarray[egyseg[j-2]].split(",")[2])*parseInt(A[i].cells[j].innerHTML);
	}
	if (archer) ossz=defi[0]+defi[1]+defi[2]; else ossz=defi[0]+defi[1]; ossz=Math.round(ossz/10000);
	if (ossz<500) extra=ossz+"k"; if (ossz>=500) extra="<b>"+ossz+"k</b>"; if (ossz>1222) extra='<font color="red"><b>'+ossz+'k</b></font>'; if (ossz>2500) extra='<img src="http://www.iconsdb.com/icons/download/black/skull-73-24.jpg"><font color="red"><b>'+ossz+'k</b></font>'; if (ossz>5000) extra='<img src="http://www.iconsdb.com/icons/download/black/skull-73-24.jpg">'+extra;
	A[i].cells[1].innerHTML='<img  src="http://alumni.georgetown.edu/schools/Georgetown/Images/v2/shield.png">'+extra;/*+' <img src="http://hu17.tribalwars.net/graphic/unit/def.png">'+defi[0]+' <img src="http://hu17.tribalwars.net/graphic/unit/def_cav.png">'+defi[1]+' <img src="http://hu17.tribalwars.net/graphic/unit/def_archer.png">'+defi[2];*/
	defi[0]=0;defi[1]=0;defi[2]=0;
}
}catch(e){alert(e+j+egyseg[j-2]);}
void(0);