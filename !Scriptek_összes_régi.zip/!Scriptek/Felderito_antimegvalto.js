javascript: 
/*
 - Fel�l j�l l�that� m�don n�zetv�lt�s: falu �s j�t�kos. Ekkor
   �sszegzi a faluba ill. j�t�kosn�l l�v� sereget, �s �gy �ll�tja �ssze a t�bl�zatot.
   Ekkor a "n�h�ny/�sszes" gombok m�r scriptvez�reltek
   Class-okkal d�ntse el melyik sor mit takar, a v�g�n legyenek meg az �j oszlopok (�rtelmetlen mez� "�sszes")
 - Kellene %-os visszah�v�st megadni.
 - Extra: az els� 3 oszlopb�l az 1ik �rt�kre kattintva sz�r�st v�gez, 
   �s csak azok az oszlopok jelennek meg ami ezt tartalmazza
  - Utols� oszlop a sorba l�v� �ssz sereg legyen, egy s�rga DIV-be, aminek width-je n� a sereggel*/

try {
    var N = 5; /*Lapok sz�ma*/
    if (document.location.href.indexOf("screen=overview_villages") == -1) {
        alert("Ez a script az �ttekint�sben fut le csak.\n\nPr�miumosoknak el�sz�r �ttekint�s �talak�t� futtat�s�ra van sz�ks�g a Termel�i n�zetbe!");
        exit(0);
    }
    RefArray = new Array(); /*Window pointers*/
    WAIT = new Array(); /*Mennyiszer pr�b�ltuk sikertelen�l elemezni (lapID~dbsz�m)*/
    FELDOLG = new Array(); /*Miket dolgozunk fel �pp (lapID~FALUK t�mb elemei)*/
    FALUK = new Array(); /*Munkalista*/
    init();
    var LAP = 0; /*Aktu�lis lapmunka*/
    var BASE_URL = document.location.href.split("game.php")[0] + "game.php";
    if (document.location.href.indexOf("t=") > 0) BASE_URL += "?" + document.location.href.match(/t=[0-9]+/g)[0] + "&";
    else BASE_URL += "?";
    var egysegnevek = new Array();
	var FEJLEC=false; /*true, ha m�r az 1ik lap megn�zte a t�bl�zat fejl�c�t*/
    eloszto();
} catch (e) {
    alert("Ind�t�si hiba:\n" + e);
}

function init() {
    try {
		for (var i = 0; i < N; i++) {
			WAIT[i] = 0;
			FELDOLG[i] = 0;
		}
		document.title = "Anti-megv�lt�";
		document.getElementsByTagName("head")[0].innerHTML += '<style type="text/css">body{ background: #C0E0C0; } .vis{margin-left: 15px;} .vis tr td, .vis tr th {padding: 4px;} .selector{font-size: larger; font-weight: bold; margin: 15px 0px 20px 20px; padding: 20px; width: 888px; border: 2px solid blue; background: #CCEECC; } .selectorBox{padding: 12px; background:#FBB; display:inline; margin:10px; cursor:pointer; border: 2px solid transparent;} .selectorBox:hover{background:#F99; border:2px dotted black;} .exportBox{ background: #AAA; margin-left: 60px;} #alertBox{display: none; position:fixed; left: 100px; top: 200px; background: #999; padding: 15px;}';
		var PFA = document.getElementById("production_table");
		var patt=new RegExp(/[0-9]+\|[0-9]+/);
		if (game_data.player.premium && patt.test(PFA.rows[1].cells[1].textContent)) var oszlop=1; else var oszlop=0;
		
        for (var i = 1; i < PFA.rows.length; i++) {
            FALUK[i - 1] = parseInt(PFA.rows[i].cells[oszlop].getElementsByTagName("span")[0].getAttribute("data-id").match(/[0-9]+/g)[0]);
        }
        document.getElementsByTagName("body")[0].innerHTML = '<br><h1 align="center">C&C M�hely - Anti megv�lt� / Er�s�t�s felm�r�</h1><br><br><p id="DEBUG"></p><div class="selector">�sszes�tett n�zet: <div class="selectorBox" onclick="szur(\'jatekos\')">J�t�kos szerint</div> <div class="selectorBox" onclick="szur(\'celpont\')">C�lfaluk szerint</div> <div class="selectorBox" onclick="szur(\'default\')">Norm�l n�zet</div> <div class="selectorBox exportBox" onclick="exportView()">EXPORT�L�S</div></div><div id="tartalom"></div><div id="alertBox"></div>';
    } catch(e) {alert(e);}
}

function exportView(){try{
	var X=document.getElementById("antimegvalto-table").rows;
	var mezo, str="[b]Kint el�v� er�s�t�sek[/b]\n", temp, temp2;
	for (var i=1;i<X.length;i++){
		if (X[i].style.display=="none") continue;
		str+="\n";
		for (var j=0;j<X[0].cells.length-1;j++) {
			if (typeof mezo == "undefined" && X[0].cells[j].getElementsByTagName("img")[0]) mezo=j;
			temp=X[i].cells[j].innerText;
			console.info(temp);
			if (temp=="�sszes" || temp=="---" || temp=="0") continue;
			if (j==mezo) {str+="("+temp+" mez�) "; continue}
			if (j>mezo) {str+=temp+"[unit]"+X[0].cells[j].getElementsByTagName("img")[0].src.match(/unit_[a-zA-Z]+/g)[0].replace("unit_","")+"[/unit] "; continue}
			str+="[b]"+X[0].cells[j].innerText+":[/b] ";
			if (j==0) str+="[player]"+temp+"[/player]"; else {
			if (j==1 || j==2) str+=temp.match(/[0-9]+(\|)[0-9]+/)[0];}
			str+=" | ";
		}
	}
	displayMessage('<textarea onclick=\'this.select();\' cols="100" rows="10">'+str+'</textarea>');
}catch(e){alert("Hiba t�rt�nt "+j+"\n"+e)}}

function alert_bezar(){
	document.getElementById("alertBox").style.display="none";
}

function szur(tipus){
	var X=document.getElementById("antimegvalto-table").rows;
	for (var i=1;i<X.length;i++){
		if (X[i].getAttribute("class")==tipus) X[i].style.display=""; else X[i].style.display="none";
	}
}

function lement(tipus,groupId,szamok){
	console.info("Lement�s: "+tipus+" - "+groupId+" - "+szamok);
	var row = document.getElementById("antimegvalto-table").insertRow(-1);
	row.setAttribute("class",tipus);
	row.style.display="none";
	var cell = row.insertCell(0); 
	switch(tipus) {
		case "jatekos": cell.innerHTML=groupId[0]; break;
		case "celpont": cell.innerHTML=groupId[0]; break;
	}
	cell = row.insertCell(1); cell.innerHTML="<i>�sszes</i>";
	cell = row.insertCell(2);
	switch(tipus) {
		case "jatekos": cell.innerHTML="<i>�sszes</i>"; break;
		case "celpont": cell.innerHTML=groupId[1]; break;
	}
	cell = row.insertCell(3); cell.innerHTML="---";
	
	for (var i=0;i<szamok.length;i++){
		cell = row.insertCell(i+4); cell.innerHTML=szamok[i];
		if (szamok[i]==0) cell.setAttribute("class","hidden");
	}
	cell = row.insertCell(i+4);
	switch(tipus) {
		case "jatekos": cell.innerHTML='<a href="#" onclick="visszahiv(\'some\',\''+tipus+'\',\''+groupId[0]+'\')">[N�h�ny]</a> <a href="#" onclick="visszahiv(\'all\',\''+tipus+'\',\''+groupId[0]+'\')">[�sszes]</a>'; break;
		case "celpont": cell.innerHTML='<a href="#" onclick="visszahiv(\'some\',\''+tipus+'\',\''+groupId[1]+'\')">[N�h�ny]</a> <a href="#" onclick="visszahiv(\'all\',\''+tipus+'\',\''+groupId[1]+'\')">[�sszes]</a>'; break;
	}
}

function displayMessage(str){
	var a=document.getElementById("alertBox");
	a.style.display="block";
	a.innerHTML = '<b>�zenet</b><br><br>' + str + '<br><br><a href="#" style="float:right; text-align:center; padding: 5px; background: gray;" onclick="alert_bezar()">Rendben</a>';
}

function visszahiv(mit,tipus,celpont){
	var X=document.getElementById("antimegvalto-table").rows;
	var linkNo=(mit=="some"?0:1);
	var linkLoc=X[0].cells.length-1;
	var k=0;
	for (var i=1;i<X.length;i++){
		if (X[i].getAttribute("class")=="jatekos" || X[i].getAttribute("class")=="celpont") continue;
		switch(tipus){
			case "jatekos": if (X[i].cells[0].innerText!==celpont) continue; break;
			case "celpont": if (X[i].cells[2].innerText!==celpont) continue; break;
		}
		RefArray[k]=window.open(X[i].cells[linkLoc].getElementsByTagName("a")[linkNo].href,"ero"+k);
		k++
	}
	displayMessage(k+' db ablak nyitva lett. Klikkelj a bez�r�sra, ha be szeretn�d �ket z�rni mind.<br><input style="margin-top:15px;" type="button" onclick="closeAllWindow()" value="BEZ�R">');
	return k;
}

function closeAllWindow(){
	for (var i=0;i<RefArray.length;i++) {
		try{
			RefArray[i].close();
		}catch(e){}
	}
	RefArray=new Array();
	return;
}
function recalc() {try { /*V�g�sszegz�s*/
	closeAllWindow();
	
	var X=document.getElementById("antimegvalto-table");
	var a,b,curr; var temp=new Array();
	var hossz=X.rows.length;
	var noOfCell=X.rows[0].cells.length-1;

	$("a").attr("target","_BLANK");
	/*J�t�kos szerint �sszegz�s*/
	X.rows[0].cells[0].click();	
	for (var i=1;i<hossz;i++){
		if (X.rows[i].getAttribute("class")!=="default") continue;
		b=X.rows[i].cells[0].textContent;
		if (temp.length==0) a=b;
		if (a!=b && temp.length>0) {
			lement("jatekos",curr,temp);
			temp=new Array();
			a=b;
		}

		for (var j=4;j<X.rows[i].cells.length-1;j++){
			if (temp.length==j-4) temp[j-4]=0;
			temp[j-4]+=parseInt(X.rows[i].cells[j].textContent);
		}
		curr=[X.rows[i].cells[0].textContent,"----"];
	}
	lement("jatekos",curr,temp);
	
	/*C�lpont szerint �sszegz�s*/
	temp=new Array();
	X.rows[0].cells[2].click();	
	for (var i=1;i<X.rows.length;i++){
		if (X.rows[i].getAttribute("class")!="default") continue;
		b=X.rows[i].cells[2].textContent;
		if (temp.length==0) a=b;
		if (a!=b && temp.length>0) {
			lement("celpont",curr,temp);
			temp=new Array();
			a=b;
		}

		for (var j=4;j<X.rows[i].cells.length-1;j++){
			if (temp.length==j-4) temp[j-4]=0;
			temp[j-4]+=parseInt(X.rows[i].cells[j].textContent);
		}
		curr=[X.rows[i].cells[0].textContent,X.rows[i].cells[2].textContent ];
	}
	lement("celpont",curr,temp);
} catch (e) {alert("Hiba �jrasz�m�t�skor:\n" + e);}}

function debug(str) {
	return;
    document.getElementById("DEBUG").innerHTML += "<br>" + str;
    return;
}

function rendez(tipus,bool,thislink,table_azon,oszlop){try{
/*Tipus: "szoveg" v "szam"*/
	var OBJ=document.getElementById(table_azon).getElementsByTagName("tbody")[0];
	var prodtable=document.getElementById(table_azon).rows;
	if (prodtable.length<2) return;
	var tavok=new Array(); var sorok=new Array(); var indexek=new Array();
	var no=0;
	var vizsgal=$.trim(prodtable[1].cells[oszlop].innerText).replace(" ","");
	
	for (var i=1;i<prodtable.length;i++){
		switch (tipus) {
			case "szoveg": tavok[i-1]=prodtable[i].cells[oszlop].innerText; break;
			case "szam": tavok[i-1]=parseFloat(prodtable[i].cells[oszlop].innerText); break;
			default: throw("Nem �rtelmezhet� mi szerint k�ne rendezni."); return;
		}
		sorok[i-1]=prodtable[i];
		indexek[i-1]=i-1;
	}
	
	for (var i=0;i<tavok.length;i++){
		var min=i;
		for (var j=i;j<tavok.length;j++){
			if (bool) {if (tavok[j]>tavok[min]) min=j;}
			else {if (tavok[j]<tavok[min]) min=j;}
		}
		var Ttemp=tavok[i];
		tavok[i]=tavok[min];
		tavok[min]=Ttemp;
		
		var Ttemp=indexek[i];
		indexek[i]=indexek[min];
		indexek[min]=Ttemp;
	}
	
	for (var i=prodtable.length-1;i>0;i--){
		OBJ.deleteRow(i);
	}
	
	for (var i=0;i<tavok.length;i++){
		OBJ.appendChild(sorok[indexek[i]]);
	}
	
	thislink.setAttribute("onclick","rendez(\""+tipus+"\","+!bool+",this,\""+table_azon+"\","+oszlop+")");
	return;
}catch(e){debug("Hiba rendez�skor:\n"+e);}}

function addSeregSor(nev,forras,sor){
	var row = document.getElementById("antimegvalto-table").insertRow(-1);
	row.setAttribute("class","default");
	var cell = row.insertCell(0); cell.innerHTML=nev;
	forras=forras.replace('<span class="icon header village">','');
	cell = row.insertCell(1); cell.innerHTML=forras;
	for (var i=1;i<sor.cells.length;i++){
		cell = row.insertCell(i+1); cell.innerHTML=sor.cells[i].innerHTML;
		if (i==1) cell.innerHTML=cell.innerHTML.replace("("+nev+")","").replace('<a class="ctx" href="#">','');
		cell.setAttribute("class",sor.cells[i].getAttribute("class"));
	}
}
function setDefaultTable(sor){try{
	var temp='<table id="antimegvalto-table" class="vis"><tr><th>J�t�kos</th><th>Honnan</th><th>C�l�llom�s</th>';
	for (var i=2;i<sor.cells.length;i++){
		temp+='<th>'+sor.cells[i].innerHTML+'</th>';
	}
	temp+='</table>';
	document.getElementById("tartalom").innerHTML=temp;
	var a=document.getElementById("antimegvalto-table").rows[0].cells;
	for (var i=0;i<a.length-1;i++){
		var tip="szam"; if (i<3) tip="szoveg";
		a[i].setAttribute("onclick","rendez('"+tip+"',false,this,'antimegvalto-table',"+i+')');
		a[i].setAttribute("style","cursor: pointer");
	}
}catch(e){alert(e)}}
function szamol(P_IND){try{ /*Aktu�lis lapon val� feladatv�gz�s. False: sikertelen;True: sikeres*/
/*Hib�k/bet�lt�d�s*/
	if (!RefArray[P_IND].document.getElementById("serverTime")) {return false;}
	if ((WAIT[P_IND]==10)) {FELDOLG[P_IND]=0; return false;}
/*ID egyez�s keres�s*/
	if (RefArray[P_IND].game_data.village.id!=FELDOLG[P_IND]) { return false;}
/*Bot V�delem �rz�kel�se*/
	if (RefArray[P_IND].document.getElementById('bot_check') || RefArray[P_IND].document.title=="Bot v�delem") {
	 BOT=true;
	 Botvedelem();
	 return false;
	}
	
	try { /*Van e kint l�v� sereg? */
		var XX = RefArray[P_IND].document.getElementById("units_away").rows;
	} catch (e) {
		FALUK[FALUK.indexOf(RefArray[P_IND].game_data.village.id)] = 0;
		return true;
	}
	
	if (!FEJLEC) {
		debug("Fejl�c l�trehoz�sa: "+XX[0].innerHTML);
		setDefaultTable(XX[0]);
		FEJLEC=true;
	}
	
	for (var i = 1; i < XX.length - 1; i++) {try {
		var darabka = XX[i].cells[1].textContent.match(/\([^\(]+\)/g);
		var nev = darabka[darabka.length - 2].replace("(", "").replace(")", "");
		var vill = darabka[darabka.length - 1].replace("(", "").replace(")", "");
		/*var villname = ;*/
		addSeregSor(nev,RefArray[P_IND].document.getElementById("menu_row2").innerHTML,XX[i]);
	}catch(e){debug("Hiba_for_"+e)}}
	
/*FALUK munkat�mb m�dos�t�sa: --> 0 = k�sz*/
	FALUK[FALUK.indexOf(RefArray[P_IND].game_data.village.id)]=0;
	return true;
}catch(e){debug(e);}
return false;}

function kovetkezo() {
    var nx = -1;
    for (var i = 0; i < FALUK.length; i++) {
        if (FALUK[i] != 0 && FELDOLG.indexOf(FALUK[i]) == -1) {
            nx = i;
            break;
        }
    } /*feldolg-ba betenni faluk[i]-t*/
    return nx;
}
function eloszto() {
    try {
        var nextindex = kovetkezo();
        if (nextindex == -1) {
            var kilep = true;
            for (var i = 0; i < FELDOLG.length; i++) {
                if (FELDOLG[i] != 0) {
                    kilep = false;
                    break;
                }
            }
            if (kilep) {
                recalc();
                return;
            }
        }
        if (((RefArray[LAP] == undefined) || (RefArray[LAP].closed) || (RefArray[LAP].location.href.indexOf("screen=place&mode=units") == -1) || (WAIT[LAP] == 0)) && (nextindex != -1)) {
            RefArray[LAP] = window.open(BASE_URL + "village=" + FALUK[nextindex] + "&screen=place&mode=units", "ero" + LAP);
            FELDOLG[LAP] = FALUK[nextindex];
        }
        debug(LAP + ": Feldolg: " + FELDOLG + " - FALUK: " + FALUK);
        if (szamol(LAP, nextindex)) {
            FELDOLG[LAP] = 0;
            nextindex = kovetkezo();
            if (nextindex != -1) {
                RefArray[LAP] = window.open(BASE_URL + "village=" + FALUK[nextindex] + "&screen=place&mode=units", "ero" + LAP);
                FELDOLG[LAP] = FALUK[nextindex];
            }
            WAIT[LAP] = 0;
        } else {
            WAIT[LAP]++;
            if (WAIT[LAP] > 10) {
                RefArray[LAP].window.close();
                WAIT[LAP] = 0;
            }
        }
    } catch (e) {
        alert(e);
    }
    LAP++;
    if (LAP > N) LAP = 0;
    setTimeout("eloszto()", 100);
    return;
}
void(0);