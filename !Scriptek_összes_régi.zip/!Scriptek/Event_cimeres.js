javascript:
var REF = window.open('https://hup4.klanhaboru.hu/game.php?village=12415&screen=event_crest&page=0', 'cnc_event');
var STATE = 0;
var SZUMM=3;

function clickChallange() {try{
	var doc = REF.document.getElementById('challenge_table');
	if (!doc && !doc.rows) return true;
	for (var i=1;i<doc.rows.length;i++) {
		var chall_link = doc.rows[i].cells[3].getElementsByTagName('a');
		if (chall_link && chall_link.length > 0) {
			chall_link[0].click();
			SZUMM++;
			return true;
		}
	}
	return false;
}catch(e){return false;}}

function main() {
	var next = 5000;
	switch (STATE) {
		case 0: if (clickChallange()) STATE = 0; else STATE = 1; break;
		case 1: REF = window.open('https://hup4.klanhaboru.hu/game.php?village=12415&screen=event_crest&page=0', 'cnc_event'); STATE = 0; next = 60000; break;
	}
	next = Math.round(next * (Math.random() + 0.5));
	document.getElementsByTagName('body')[0].innerHTML = '<h2 align="center" style="margin-top: 200px">Active: '+new Date()+'<br>Waiting ' + next + ' millisec<br>Paladin sent: ' + SZUMM + '</h2>'
	setTimeout(main, next);
}
setTimeout(main, 3000);