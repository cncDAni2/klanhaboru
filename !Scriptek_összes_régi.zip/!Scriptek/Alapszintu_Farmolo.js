javascript:
var farmolando_faluk="274|562 275|560 276|561 276|554"; /*Mely falukat farmolsz? X �s Y koordin�t�kat |-vel v�lasztjuk el egym�st�l, a kh-t�l megszokott m�don - a koordikat egym�st�l pedig teljesen mindegy, vagy legyen valami :-)*/
var kuldendo_egysegek="10 20, meg 50, t�bbi majd alapszam lesz..."; /*Mennyi egys�get k�ldesz az egyes falukra? sorrendben az 1. az el�z� lista 1. faluj�ra vonatkozik. Hagyd �resen, ha az "alapsz�m"-ot szeretn�d �rni a megmaradt helyekre. Sz�mok, egym�st�l mindegy mivel elv�lasztva*/
var alapszam=30; /*Sz�m. Alap�rtelmez�sk�nt ennyi egys�g megy egy falura.*/
var felderitok=1; /*Mennyi felder�t� menjen egy-egy falura? (Ne menjen = 0)*/
var egysegtipus="light"; /*Mivel t�madsz? light=k�nny�lovas, spear=l�ndzsa, ... lsd. Alapok/tech2*/

function setCookie(name, value, expire) {
	document.cookie = name + "=" + escape(value)
	+ ((expire == null) ? "" : ("; expires=" + expire.toGMTString()));
}

function getCookie(Name){
	var search = Name + "=";
	if (document.cookie.length > 0) {
		offset = document.cookie.indexOf(search);
		if (offset != -1) {
			offset += search.length;
			end = document.cookie.indexOf(";", offset);
			if (end == -1) end = document.cookie.length;
			return unescape(document.cookie.substring(offset, end));
		}
	}
}	

try{

farmolando_faluk=farmolando_faluk.match(/[0-9]+(\|)[0-9]+/g);
try{kuldendo_egysegek=kuldendo_egysegek.match(/[0-9]+/g);
var h=kuldendo_egysegek.length;}catch(e){var h=0;}
var b = new Array();
var KL=new Array();
for (var i=0;i<farmolando_faluk.length;i++){
	b[i]=farmolando_faluk[i].split("|");
	if (i>(h-1)) KL[i]=alapszam; else KL[i]=kuldendo_egysegek[i];
}

var hossz=KL.length;
var d=document;
	
function munka(){
var VISITED = 0;
	VISITED = getCookie('visited');
if (VISITED==null || VISITED=="") {
	VISITED=0;
} else {
	VISITED++;
}
	
if (VISITED >= (hossz)){
		alert("K�rbe�rt�l! Ez volt az utols� falu.\n A script �jraindul...");
		expDate = new Date();
		expDate.setTime(expDate.getTime() + (100));
		setCookie('visited', 0, expDate);
		return;
	} else {
		expDate = new Date();
		expDate.setTime(expDate.getTime() + (60*1000));
		setCookie('visited', VISITED, expDate);
	}
if(d.forms[0].name=='units')
	{
		d.forms[0].x.value=b[VISITED][0];
		d.forms[0].y.value=b[VISITED][1];
		d.forms[0].spy.value=felderitok;
		d.getElementById("unit_input_"+egysegtipus).value=KL[VISITED];
		d.forms[0].attack.click();
	} else {
		d.forms[0].submit.click();
		setCookie('visited', VISITED-1, expDate);
	}
}
munka();
}catch(e){alert(e);}
void(0);