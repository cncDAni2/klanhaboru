javascript:
EXP="1sor"; EZT="mind";
lista(false); 

function SelectAll(id){
    document.getElementById(id).focus();
    document.getElementById(id).select();
}

function lista(kivag){try{
	var X=document.getElementById("villages_list").rows;
	var str="";
	if (X[X.length-1].cells[0].getAttribute("colspan")==3){
		var a=confirm("Vigy�zat!\nNincs minden falu kilist�zva! Ha szeretn� list�ztatni, nyomjon OK gombot, �s futtassa �jra a scriptet\n\n"+$.trim(X[X.length-1].cells[0].innerText)+"?");
		if (a) {
			X[X.length-1].cells[0].getElementsByTagName("a")[0].click();
			return;}
	}
	if (kivag) {if (confirm("A kiv�g m�velettel a list�zott sorok maradnak csak meg, a t�bbi pedig t�rl�dik, �gy k�s�bb m�r nem \"l�tom\" ezeket, am�g �jra nem friss�ted az oldalt!\n\nFolytatja?")) kivag=true; else kivag=false;} else kivag=false;
	
	var mind=true;
	var Kkonti=new Array();
	var Inputhossz=document.getElementsByTagName("input").length;
	for (var i=0;i<Inputhossz;i++) {
		if (document.getElementsByTagName("input")[i].checked==true) {
			mind=false;
			if (Kkonti.indexOf(document.getElementsByTagName("input")[i].name)==-1) Kkonti.push(document.getElementsByTagName("input")[i].name);
		}
	}
	if (document.getElementById("T_F")){
		var T_Falu=document.getElementById("T_F").value;
		var T_FaluTav=document.getElementById("T_FT").value;
	} else {
		var T_Falu="";
		var T_FaluTav="";
	}
	
	if (document.getElementById("T_KIZ")){
		try{
			if (document.getElementById("T_KIZ").value!="") var kiz_lista=document.getElementById("T_KIZ").value.match(/[0-9]+(\|)[0-9]+/g); else var kiz_lista=new Array();
		}catch(e){alert("�rv�nytelen koordin�ta megad�s Kiz�r�si list�ba!"); var kiz_lista=new Array();}
	} else {
		var kiz_lista=new Array();
	}
	
	if (T_Falu!="") {try{
		T_Falu=T_Falu.match(/[0-9]+(\|)[0-9]+/g); 
		if (T_Falu.length<1) throw "error";  
	}catch(e){alert("�rv�nytelen koordin�ta megad�s Ter�leti keres�sn�l!"); T_Falu="";}}
	
	if (T_FaluTav!="") T_FaluTav=T_FaluTav.replace(/[^0-9]/g,"");
	
	var T_Ok=false;
	if( (T_Falu=="") ? !(T_FaluTav=="") : (T_FaluTav=="") ) {
		alert("Ter�leti keres�shez mind a t�vols�g �s mind a falu mez� kit�lt�se sz�ks�ges.\n\n Ter�leti keres�s figyelmen k�v�l hagyva.");
	} else {if (T_FaluTav!="") {T_FaluTav=parseInt(T_FaluTav); if (T_Falu!="") T_Ok=true;}}
	
	if (document.getElementById("PMin")){
		var MinPont=document.getElementById("PMin").value.replace(/[^0-9]+/g,""); if (MinPont=="") MinPont=""; else MinPont=parseInt(MinPont);
		var MaxPont=document.getElementById("PMax").value.replace(/[^0-9]+/g,""); if (MaxPont=="") MaxPont=""; else MaxPont=parseInt(MaxPont);
	} else {MaxPont=""; MinPont="";}
	
	var kontik=new Array(); var konti=""; var benne=false;
	var XF=document.getElementById("villages_list").parentNode.parentNode.parentNode.parentNode.rows[0];
	XF.cells[0].style.width="";
	XF.cells[1].style.width="";
	XF.cells[1].style.minWidth="578px";
	
	for (var i=X.length-1;i>0;i--){ try{
		benne=false;
		if (X[i].cells[0].getAttribute("colspan")==3) continue;
		konti = X[i].cells[1].innerHTML.split("|")[1][0]+X[i].cells[1].innerHTML.split("|")[0][0];
		if (kontik.indexOf(konti)==-1) kontik.push(konti);
		if (Kkonti.indexOf(konti)==-1 && !mind) { X[i].cells[1].style.fontWeight="normal"; continue;}
		if (T_Ok){ /*T�vols�g vizsg�lat*/
			for (var j=0;j<T_Falu.length;j++){
				var temp=Math.abs(Math.sqrt(Math.pow(T_Falu[j].split("|")[0]-X[i].cells[1].innerHTML.split("|")[0],2)+Math.pow(T_Falu[j].split("|")[1]-X[i].cells[1].innerHTML.split("|")[1],2)));
				if (temp<=T_FaluTav) {benne=true; break;}
			}
		} else benne=true;
		if (kiz_lista.indexOf(X[i].cells[1].innerHTML.match(/[0-9]+(\|)[0-9]+/g)[0])>-1) benne=false;
		if (MinPont!="") if (parseInt(X[i].cells[2].textContent.replace(/[^0-9]+/g,""))<MinPont) benne=false;
		if (MaxPont!="") if (parseInt(X[i].cells[2].textContent.replace(/[^0-9]+/g,""))>MaxPont) benne=false;
		if (!benne) {X[i].cells[1].style.fontWeight="normal"; if (kivag) document.getElementById("villages_list").deleteRow(i); continue;}
		X[i].cells[1].style.fontWeight="bold";
		switch (EXP) {
			case "1sor": str+=X[i].cells[1].innerHTML+" "; break;
			case "ujsor": str+=X[i].cells[1].innerHTML+"\n"; break;
			case "BB": str+="[coord]"+X[i].cells[1].innerHTML+"[/coord]\n";
		}
	} catch(e){} }
	
	if (!document.getElementById("faluexp")){
	var prof=document.getElementById("villages_list").parentNode.parentNode.parentNode.rows[0].cells[1];
	$(prof).prepend('<div id="faluexp"></div>');
	}
	Z=document.getElementById("faluexp");
	Z.innerHTML='<form name="lista"><b>Ki�r�si m�dszer: <a href="javascript: EXP=\'BB\'; lista();">BB k�ddal</a> | <a href="javascript: EXP=\'1sor\'; lista();">Egy sorba</a> | <a href="javascript: EXP=\'ujsor\'; lista();">Soronk�nt 1-et</a><br><br>Kontinensek:</b> ';

	for (var i=0;i<kontik.length;i++){
		if (Kkonti.indexOf(kontik[i])==-1){
			Z.innerHTML+='<input type="checkbox" name="'+kontik[i]+'"><b>K'+kontik[i]+"</b> ";
		} else {
			Z.innerHTML+='<input type="checkbox" name="'+kontik[i]+'" checked="true"><b>K'+kontik[i]+"</b> ";
		}
	}
	var row=Math.ceil(str.length/70);
	if (str.length>6) var dbszam=str.match(/[0-9]+(\|)[0-9]+/g).length; else var dbszam=0;
	try{if (str.match(/\n/g).length>row) row=str.match(/\n/g).length;}catch(e){}
	if (row>30) row=30;
	Z.innerHTML+='<br><br><b>Ter�let keres�:</b> <input type="text" id="T_F" placeholder="Minden" value="'+T_Falu+'" size="35"> falu(k) k�r�l <input type="text" placeholder="999" id="T_FT" value="'+T_FaluTav+'" size="3"> mez� t�von bel�l.<br><br><b>Kiz�r�si lista:</b> <input type="text" id="T_KIZ" placeholder="Koordin�t�k" size="35" value='+kiz_lista+'><br><br><b>Faluk pont�rt�ke:</b> Minimum <input type="text" placeholder="0" value="'+MinPont+'" id="PMin" size="4"> Maximum <input id="PMax" type="text" placeholder="99999" value="'+MaxPont+'" size="4"><br><br><p style="color:black; display:inline; padding:2px; margin-left: 10px; width: 50px; border: 1px solid black; background: #BBB;"><a href="javascript: lista(false);">List�zd</a></p> <p style="color:black; padding:2px; display:inline; width: 50px; border: 1px solid black; background: #BBB;"><a href="javascript: lista(true);">Kiv�g</a></p></form><hr>Eredm�ny ('+dbszam+' falu)<br><textarea rows="'+(row+1)+'" cols="70" id="elem" style="margin-top: 5px" onclick=\'SelectAll("elem");\'>'+str+"</textarea>";
	}catch(e){alert(e);}
	
	SelectAll("elem");
	return;
}
void(0);