javascript:
function setCookie(name, value, expire) {
	document.cookie = name + "=" + escape(value)
	+ ((expire == null) ? "" : ("; expires=" + expire.toGMTString()));
}

function getCookie(Name){
	var search = Name + "=";
	if (document.cookie.length > 0) {
		offset = document.cookie.indexOf(search);
		if (offset != -1) {
			offset += search.length;
			end = document.cookie.indexOf(";", offset);
			if (end == -1) end = document.cookie.length;
			return unescape(document.cookie.substring(offset, end));
		}
	}
}
	
function kuld(celpont,XX,YY){try{
	expDate = new Date();
	expDate.setTime(expDate.getTime() + (60*1000));
	VISITED = getCookie('visited');
	if (VISITED==null || VISITED=="") {
		VISITED=0;
	} else {
		VISITED=parseInt(VISITED);
		VISITED++;
	}
	if (VISITED >= (hossz)){
			LEPES++;
			setCookie('lepes', LEPES, expDate);
			expDate = new Date(); 
			expDate.setTime(expDate.getTime() - (100));
			setCookie('visited', 0, expDate);
			if (A.document.forms[0].name!='units') {
					A.document.forms[0].elements['building'].value=celpont;
					A.document.forms[0].submit.click();
					}
	} else {
		setCookie('visited', VISITED, expDate);
		if(A.document.forms[0].name=='units')
		{
		A.document.forms[0].x.value=XX;
		A.document.forms[0].y.value=YY;
		if (parseInt(A.document.forms[0].catapult.value)<KL[VISITED]) return false;
		A.document.forms[0].catapult.value=KL[VISITED];
		A.document.forms[0].attack.click();
		} else {
		A.document.forms[0].elements['building'].value=celpont;
		A.document.forms[0].submit.click();
		setCookie('visited', VISITED-1, expDate);
	}}
	return true;
	}catch(e){return true;}
}

function auto_kuld(){
	try{
	if (A.document.readyState!="complete") {setTimeout("auto_kuld()",250); return; }
	LEPES = getCookie('lepes');
	LEPES=parseInt(LEPES);	
	if (LEPES>MAXDB) {	
		alert("Script v�ge!"); 
		expDate = new Date();
		expDate.setTime(expDate.getTime() + (100));
		setCookie('visited', 0, expDate);
		expDate = new Date();
		expDate.setTime(expDate.getTime() + (100));
		setCookie('lepes', 0, expDate); 
		return;
	}
	
	switch (LEPES){
			case 1: KL=new Array(2,1); hossz=KL.length; Check=kuld('smith',263,564); break;
			case 2: KL=new Array(3,1); hossz=KL.length; Check=kuld('main',263,564); break;
			default: Check=false; alert("Script v�ge!!!");
		}
	if (!Check) {alert("V�ge, nincs t�bb egys�g"); return;} else setTimeout("auto_kuld()",250);
	}catch(e){alert("Auto_kuld hiba:"+e); return;}
}
/*------------------------------------*/
	var d=document;	
	if(window.frames.length>0) d=window.main.document;
	url=d.URL;
	if(url.indexOf('screen=place')==-1) {
		alert('Gy�l. helyen pr�b�ld...');
		exit(0);
	}
	var LEPES = getCookie('lepes');
	
	MAXDB=2;
	var KL=new Array();
	var hossz=0;
	var A=window.open(document.location.href);
	
	expDate = new Date();
	expDate.setTime(expDate.getTime() + (60*1000));
	if (LEPES==null || LEPES=="") {LEPES=1;setCookie('lepes', LEPES, expDate);}
	if (LEPES>MAXDB) {
		alert("Katapultoz�s k�sz.\n A script �jraindul...");
		expDate = new Date();
		expDate.setTime(expDate.getTime() + (100));
		setCookie('visited', 0, expDate);
		expDate = new Date();
		expDate.setTime(expDate.getTime() + (100));
		setCookie('lepes', 0, expDate);
	} else {
		auto_kuld();
	}
	void(0);