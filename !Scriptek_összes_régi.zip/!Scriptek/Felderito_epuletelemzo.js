javascript:
/*Felderítő váz!*/
var N=5; /*Lapok száma*/
if (document.location.href.indexOf("screen=overview_villages")==-1) {alert("Ez a script az áttekintésben fut le csak.\n\nPrémiumosoknak először áttekintés átalakító futtatására van szükség a Termelői nézetbe!"); exit(0);}
try{
	RefArray=new Array(); /*Window pointers*/
	WAIT=new Array(); /*Mennyiszer próbáltuk sikertelenül elemezni (lapID~dbszám)*/
	FELDOLG=new Array(); /*Miket dolgozunk fel épp (lapID~FALUK tömb elemei)*/
	FALUK=new Array(); /*Munkalista*/
	BOT=false;
	var epuletek=new Array("main","barracks","stable","garage","church_f","church","smith","snob","place","statue","market","wood","stone","iron","farm","storage","hide","wall");
	if (!init()) throw "Kinézet kialakításakor.";
	var LAP=0; /*Aktuális lapmunka*/
	var BASE_URL=document.location.href.split("game.php")[0]+"game.php";
	if (document.location.href.indexOf("t=")>0) BASE_URL+="?"+document.location.href.match(/t=[0-9]+/g)[0]+"&"; else BASE_URL+="?";
	
eloszto();
}catch(e){alert("Indítási hiba:\n"+e);}

function init(){try{
	/*tömb nullázások, N-ig*/
	for (var i=0;i<N;i++){
		WAIT[i]=0; FELDOLG[i]=0;
	}
	document.title="Épület Felderítő";
	
	/*PF-átalakítás*/
	var PFA=document.getElementById("production_table");
	var patt=new RegExp("[0-9]+(\|)[0-9]+","g");
	if (patt.test(PFA.rows[1].cells[0].textContent)) var f=0; else 
	if (patt.test(PFA.rows[1].cells[1].textContent)) var f=1; else return false;
	for (var i=0;i<PFA.rows[0].cells.length;i++){
		try{if (PFA.rows[0].cells[i].getElementsByTagName("a")[0].href.indexOf("order=points")>-1 || PFA.rows[0].cells[i].getAttribute("id")=="pont") var p=i;} catch(e){}
		try{if (PFA.rows[0].cells[i].getElementsByTagName("a")[0].href.indexOf("order=pop")>-1 || PFA.rows[0].cells[i].getAttribute("id")=="tanya") var t=i;} catch(e){}
	}
	var del_oszlop=new Array();
	for (j=0;j<PFA.rows[i].cells.length;j++){
		if (j!=f && j!=p && j!=t) del_oszlop.push(j);
	}
	for (i=0;i<PFA.rows.length;i++){
		for (j=PFA.rows[i].cells.length;j>=0;j--){
			if (del_oszlop.indexOf(j)>-1) PFA.rows[i].deleteCell(j);
		}
	}
	
	/*Faluk felvétele munkatömbbe*/
	for (var i=1;i<PFA.rows.length;i++){
		
		FALUK[i-1]=parseInt(PFA.rows[i].cells[0].getElementsByTagName("span")[0].getAttribute("data-id").match(/[0-9]+/g)[0]);
	}
	
	/*Weboldal szerkezeti kialakítása; lehetőség adása "BOT=false;" értékadásra!*/
	for (var i=0;i<PFA.rows.length;i++){
		for (var j=3;j<epuletek.length+3;j++){
			newcell=PFA.rows[i].insertCell(j);
			if (i==0) newcell.innerHTML='<img onclick="rendez(this,false)" style="cursor: pointer;" src="/graphic/buildings/'+epuletek[j-3]+'.png" alt="'+epuletek[j-3]+'">';
		}
	}
	document.getElementById("header_info").innerHTML+='<tr><td colspan="4"><a href="javascript:BOT=false; void(0);">Klikk, ha bejött a bot védelem, de már beírtad a kódot</a><p id="DEBUG"></p></td></tr>';
	return true;
}catch(e){alert(e+"\n"+(j-3));}}

function rendez(obj,bool){try{
	var oszlop=obj.parentNode.cellIndex;
	var prodtable=document.getElementById("production_table").rows;
	var tavok=new Array(); var sorok=new Array(); var indexek=new Array();
	var no=0;
	var fix=0; if (prodtable[0].cells.length!=prodtable[prodtable.length-1].cells.length) fix=1;
	var vizsgal=$.trim(prodtable[1].cells[oszlop].innerText).replace(" ","");
	for (var i=1;i<prodtable.length-fix;i++){
		tavok[i-1]=parseInt(prodtable[i].cells[oszlop].innerText.replace(".",""));
		sorok[i-1]=prodtable[i];
		indexek[i-1]=i-1;
	}
	
	for (var i=0;i<tavok.length;i++){
		var min=i;
		for (var j=i;j<tavok.length;j++){
			if (bool) {if (tavok[j]>tavok[min]) min=j;}
			else {if (tavok[j]<tavok[min]) min=j;}
		}
		var Ttemp=tavok[i];
		tavok[i]=tavok[min];
		tavok[min]=Ttemp;
		
		var Ttemp=indexek[i];
		indexek[i]=indexek[min];
		indexek[min]=Ttemp;
	}
	
	var TT=document.getElementById("production_table");
	for (var i=prodtable.length-1;i>0;i--){
		TT.deleteRow(i);
	}
	
	for (var i=0;i<tavok.length;i++){
		TT.appendChild(sorok[indexek[i]]);
	}
	
	obj.setAttribute("onclick","rendez(this,"+!bool+")");
	try{szamlal();}catch(e){}
	return;
}catch(e){alert("Hiba rendezéskor:\n"+e);}}

function debug(str){
	return;
	document.getElementById("DEBUG").innerHTML+="<br>"+str;
	return;
}

function recalc(){try{
	/*Végeredménnyel való művelet*/
	for (var i=0;i<RefArray.length;i++){
		try{RefArray[i].window.close();}catch(e){}
	}
}catch(e){alert("Hiba újraszámításkor:\n"+e);}}

function kovetkezo(){ /*Visszaadja melyik a következő faluazonosító amit nézni kell. -1 ha nincs már több feldolgozandó falu*/
	var nx=-1;
	for (var i=0;i<FALUK.length;i++){
		if (FALUK[i]!=0 && FELDOLG.indexOf(FALUK[i])==-1) {
			nx=i;
			break;
		}
	}
	/*feldolg-ba betenni faluk[i]-t*/
	return nx;
}

function Botvedelem(){
	/*Figyelmeztető, stb.*/
	alert("Bot védelem!");
	BOT=true;
	for (var i=0;i<RefArray.length;i++){
		try{RefArray[i].window.close();}catch(e){}
	}
	window.open(BASE_URL);
	return;
}

function szamol(P_IND){try{ /*Aktuális lapon való feladatvégzés. False: sikertelen;True: sikeres*/
/*Hibák/betöltődés*/
	if (!RefArray[P_IND].document.getElementById("serverTime")) {return false;}
	if ((WAIT[P_IND]==10)) {FELDOLG[P_IND]=0; return false;}
/*ID egyezés keresés*/
	if (RefArray[P_IND].game_data.village.id!=FELDOLG[P_IND]) { return false;}
/*Bot Védelem érzékelése*/
	if (RefArray[P_IND].document.getElementById('bot_check') || RefArray[P_IND].document.title=="Bot védelem") {
	 BOT=true;
	 Botvedelem();
	 return false;
	}
	
	/*ID -> sor konvertálás*/
	var X=document.getElementById("production_table").rows;
	var sor=-1;
	for (var i=1;i<X.length;i++){
		if (X[i].cells[0].getElementsByTagName("a")[0].href.match(/village=[0-9]+/g)[0].replace("village=","")==RefArray[P_IND].game_data.village.id){
			sor=i;
			break;
		}
	}
	if (sor==-1) {debug("Nem találom a sort :/"); return false;}
	
	var Cep=0;
	for (var i=0;i<epuletek.length;i++){
		try{
			Cep=RefArray[P_IND].game_data.village.buildings[epuletek[i]];
		}catch(e){Cep=0;}
		X[sor].cells[3+i].innerHTML=Cep;
	}
	
/*FALUK munkatömb módosítása: --> 0 = kész*/
	FALUK[FALUK.indexOf(RefArray[P_IND].game_data.village.id)]=0;
	return true;
}catch(e){}
return false;}

function eloszto(){try{ /*A Motor*/
	if (!BOT){
	var nexttime=200;
	var nextindex=kovetkezo();
	var end=false;
	if (nextindex==-1) { 
		var kilep=true; 
		for (var i=0;i<FELDOLG.length;i++) {if (FELDOLG[i]!=0 && FELDOLG[i]!="" && FELDOLG[i]!=undefined) {kilep=false; break;}}
		if (kilep) {recalc(); return;}
		if (FELDOLG[LAP]!=0 && FELDOLG[LAP]!="" && FELDOLG[LAP]!=undefined) end=true;
	}
	
/*Lapmegnyitás!*/
	if (end && (RefArray[LAP].closed || RefArray[LAP]==undefined)){
/*(!)*/	RefArray[LAP]=window.open(BASE_URL+"village="+FALUK[nextindex]+"&screen=main","ep_"+LAP);
		FELDOLG[LAP]=FALUK[nextindex];
	} else 
/*(!)*/if (((RefArray[LAP]==undefined) || (RefArray[LAP].closed) || (RefArray[LAP].location.href.indexOf("screen=main")==-1) || (WAIT[LAP]==0)) && (nextindex!=-1)) {
/*(!)*/	RefArray[LAP]=window.open(BASE_URL+"village="+FALUK[nextindex]+"&screen=main","ep"+LAP);
		FELDOLG[LAP]=FALUK[nextindex];
	}
	
	if (szamol(LAP,nextindex)) {
		FELDOLG[LAP]=0;
		nextindex=kovetkezo();
/*(!)*/	if (nextindex!=-1) {RefArray[LAP]=window.open(BASE_URL+"village="+FALUK[nextindex]+"&screen=main","ep"+LAP); FELDOLG[LAP]=FALUK[nextindex];}
		WAIT[LAP]=0;
	} else {
		WAIT[LAP]++;
		if (WAIT[LAP]>10) {
			RefArray[LAP].window.close();
			WAIT[LAP]=0;
		}
	}} else var nexttime=5000;
}catch(e){alert(e);}
	LAP++; if (LAP>N) LAP=0;
	nexttime=Math.round(nexttime*((Math.random()*0.4)+0.75));
	setTimeout("eloszto()",nexttime);
	return;
}

void(0);