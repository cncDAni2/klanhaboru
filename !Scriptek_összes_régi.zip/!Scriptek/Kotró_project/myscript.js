$(document).ready(function(){
	$(".menu").mouseover(function(a){
		/*console.log(a.clientX);
		if ($(this).hasClass("actived")) {
			$(".menu").removeClass("actived");
		} else {
			$(".menu").removeClass("actived");
			$(this).addClass("actived");
		}*/
		/*$(".submenu").css()*/
	});
});
/*

-ms-transform: rotate(90deg);
-webkit-transform: rotate(90deg);
transform: rotate(90deg);
margin-right:0px;
margin-top:10px;

margin-right:-5px;
margin-top:7px;*/