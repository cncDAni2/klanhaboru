javascript:
/*incomings_table
combined_table
production_table
units_table
buildings_table
techs_table
group_assign_table
commands_table

Speci: 
	ha csak 1 kép van -> src alapján
	ha (szám per szám) van -> jó volna rákérdezni hogy mi szerint (1,2 == jelen,teljes)
	ha (szám pont szám) van -> nem kell a pont --->
	 csak szám van -> esetleges pontokat törölni
	termelés/toborzás; épületek/építési sor
	nyersanyagos: 3 szám, 3 kép -> jó volna rákérdezni hogy mi szerint (1,2,3 == fa,agyag,vas)

	RegExp szűrő: csak innerText-et néz
*/
var tables=new Array("incomings_table","combined_table","production_table","units_table","buildings_table","techs_table","group_assign_table","commands_table");
if (init()) {
	stop();
} else {
	alert("Ez a script ilyen áttekintésen nem képes lefutni :(");
}
function init(){
	for (var i=0;i<tables.length;i++){
		if (document.getElementById(tables[i])){
			OBJ=document.getElementById(tables[i]);
			break;
		}
	}
	if (i==tables.length) return false; else {
		if (OBJ.getAttribute("id")=="incomings_table"){
			/*Osztlopkieg: ID-k!*/
			try{for (j=0;j<OBJ.rows.length-1;j++){
				var newline=OBJ.rows[j].insertCell(0);
				if (j==0) newline.innerHTML="ID"; else{
					newline.innerHTML=OBJ.rows[j].cells[1].getElementsByTagName("a")[0].href.match(/id=[0-9]+/g)[0].replace("id=","");
				}
			}}catch(e){alert(e);}
		}
		for (var i=0;i<OBJ.rows[0].cells.length;i++){
			OBJ.rows[0].cells[i].innerHTML+=' <a href="javascript: rend(false,'+i+');"><img alt="" src="http://www.olcso-alkatresz.hu/templates/default/images/arrowup_grey.gif" title="Növekvő"></a> <a href="javascript: rend(true,'+i+');"><img alt="" src="http://www.olcso-alkatresz.hu/templates/default/images/arrowdown_grey.gif" title="Csökkenő"></a>';
		}
		return true;
	}
	return false;
}
function stop(){
var x = setTimeout('',100); for (var i = 0 ; i < x ; i++) clearTimeout(i);}

function rend(bool,oszlop){try{
	var prodtable=OBJ.rows;
	var tavok=new Array(); var sorok=new Array(); var indexek=new Array();
	var no=0;
	var fix=0; if (prodtable[0].cells.length!=prodtable[prodtable.length-1].cells.length) fix=1;
	var vizsgal=$.trim(prodtable[1].cells[oszlop].innerText).replace(" ","");
	var tipus="";
		if (isNaN(vizsgal)) {
			var patt=new RegExp(/^[0-9]+(\/)[0-9]+$/g);
			if (patt.test(vizsgal)) tipus="peres"+prompt("Válasszon, mi szerint rendezne!\n1: A / jel előtti szám szerint\n2: A / jel utáni szám szerint");
			if ((prodtable[1].cells[oszlop].innerHTML.indexOf("wood")>0) && (prodtable[1].cells[oszlop].innerHTML.indexOf("stone")>0) && (prodtable[1].cells[oszlop].innerHTML.indexOf("iron")>0)){
				tipus="nyers"+prompt("Válasszon, mi szerint rendezne!\n1: Fa\n2: Agyag\n3: Vas");
			}
			patt=new RegExp(/^[0-9][0-9](\:)[0-9][0-9](\:)[0-9][0-9]$/g);
			if (patt.test(vizsgal)) tipus="ido";
		} else { /*szám lesz, a pont is OKÉ*/
			if (vizsgal=="") {tipus="src";
			if (prodtable[1].cells[oszlop].getElementsByTagName("img").length==0) tipus="szoveg";}
			if (tipus=="") tipus="szam";
			if (prodtable[1].cells[oszlop].innerHTML.indexOf('class="rename-icon"')>0 || prodtable[1].cells[oszlop].innerHTML.indexOf('screen=info_player')>0) tipus="szoveg";
		}
		if (tipus=="") tipus="szoveg";
	for (var i=1;i<prodtable.length-fix;i++){
/*(!)	switch (tipus) case "" ---> speci típusok*/
		switch (tipus) {
			case "szoveg": tavok[i-1]=prodtable[i].cells[oszlop].innerText; break;
			case "peres1": tavok[i-1]=parseInt(prodtable[i].cells[oszlop].innerText.split("/")[0]); break;
			case "peres2": tavok[i-1]=parseInt(prodtable[i].cells[oszlop].innerText.split("/")[1]); break;
			case "nyers1": tavok[i-1]=parseInt(prodtable[i].cells[oszlop].innerText.split(" ")[0].replace(".","")); break;
			case "nyers2": tavok[i-1]=parseInt(prodtable[i].cells[oszlop].innerText.split(" ")[1].replace(".","")); break;
			case "nyers3": tavok[i-1]=parseInt(prodtable[i].cells[oszlop].innerText.split(" ")[2].replace(".","")); break;
			case "ido": if (parseInt(prodtable[i].cells[oszlop].innerText.split(":")[0])<10) tavok[i-1]="0"+prodtable[i].cells[oszlop].innerText; else tavok[i-1]=prodtable[i].cells[oszlop].innerText; break;
			case "szam": tavok[i-1]=parseInt(prodtable[i].cells[oszlop].innerText.replace(".","")); break;
			default: alert("Nem értelmezhető mi szerint kéne rendezni."); return;
		}
			
		/*switch vége*/
		sorok[i-1]=prodtable[i];
		indexek[i-1]=i-1;
	}
	for (var i=0;i<tavok.length;i++){
		var min=i;
		for (var j=i;j<tavok.length;j++){
			if (bool) {if (tavok[j]>tavok[min]) min=j;}
			else {if (tavok[j]<tavok[min]) min=j;}
		}
		var Ttemp=tavok[i];
		tavok[i]=tavok[min];
		tavok[min]=Ttemp;
		
		var Ttemp=indexek[i];
		indexek[i]=indexek[min];
		indexek[min]=Ttemp;
		
	}
	
	for (var i=prodtable.length-1;i>0;i--){
		OBJ.deleteRow(i);
	}
	
	for (var i=0;i<tavok.length;i++){
		OBJ.appendChild(sorok[indexek[i]]);
	}
	return;
}catch(e){alert("Hiba rendezéskor:\n"+e);}}

void(0);