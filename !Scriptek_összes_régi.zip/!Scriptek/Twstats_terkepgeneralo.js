javascript:
if (document.location.href.indexOf("contracts")==-1) {alert("Ez a script csak a diplom�cia n�zetbe m�k�dik");exit(0);}
try{
myAlly=game_data["player"]["ally"];
X=document.getElementById("partners").rows;
link="http://hu.twstats.com/"+game_data["world"]+"/index.php?page=map&ti0="+myAlly+"&tc0=0000F4&";
status="";
index=1;
for (i=0;i<X.length;i++){
	if (X[i].innerHTML.indexOf("Sz�vets�g")>-1) status="A";
	if (X[i].innerHTML.indexOf("MNT")>-1) status="M";
	if (X[i].innerHTML.indexOf("Ellens�g")>-1) status="E";
	if (!X[i].getElementsByTagName("a")[0]) continue;
	
	switch (status){
		case "A": link+="ti"+index+"="+(X[i].getElementsByTagName("a")[0].href.match(/id=[0-9]+/g)[0].match(/[0-9]+/g)[0])+"&tc"+index+"=00A0F4&"; break;
		case "M": link+="ti"+index+"="+(X[i].getElementsByTagName("a")[0].href.match(/id=[0-9]+/g)[0].match(/[0-9]+/g)[0])+"&tc"+index+"=800080&"; break;
		case "E": link+="ti"+index+"="+(X[i].getElementsByTagName("a")[0].href.match(/id=[0-9]+/g)[0].match(/[0-9]+/g)[0])+"&tc"+index+"=F40000&"; break;
		default: alert("Nem t�mogatott nyelvezet"); exit(0);
	}
	index++;
}
link+="pi0="+game_data["player"]["id"]+"&pc0=f0c800&zoom=100&centrex=500&centrey=500&nocache=1&fill=000000";
document.getElementById("ally_content").getElementsByTagName("p")[0].innerHTML+='<br><a href="'+link+'">TwStats t�rk�p</a>';
}catch(e){alert(e);}
window.open(link);
void(0);