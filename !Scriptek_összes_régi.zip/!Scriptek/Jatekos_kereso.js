javascript:
try{if (data.innerHTML.length>10) throw "fut"; }catch(e){if (e=="fut") exit(0);}
try{
if (document.location.href.indexOf("mode=villages")==-1 || document.location.href.indexOf("twstats")==-1) alert("V�lhet�leg rossz helyen futtatod a scriptet. A script a TWStats-on fut le, egy kl�n profilj�ban tal�lhat� falulist�z�ban.");

sor=document.documentElement.innerHTML.split("\n");
img1 = new Image();
img1.src = "http://muhely2.cncdani2.freeiz.com/images/preloader-w8-line-black.gif";
$('body').append('<div id="options" style="width: 270px;  background: #222; background-image: url(\'http://muhely2.cncdani2.freeiz.com/images/Script/Jat_ker.jpg\');background-repeat:no-repeat; background-position:left top; color: white;  position: fixed; left:10%; top:10%; border:3px solid black; font-family:Lucida Sans Unicode; padding: 15px; z-index:2;"><br><p style="display:inline">Faluk: </p> <input type="text" value="" size="20"><br>Max t�v:<input type="text" value="10.0" size="4"> mez�<input type="button" onclick="keres()" value="Keres�s..."><br><input type="checkbox"> R�szletez�s BB k�dok n�lk�l<br>Eredm�ny:<br><textarea style="background-color: #c0c0c0; opacity: 0.8;" id="result" onclick=\'this.select();\' rows="10" cols="32"  readonly="readonly"></textarea><p id="munka"></p></div>');
data=document.getElementById("options");
result=document.getElementById("result");
}catch(e){alert(e);}
/*---------------------------*/

function keres(){try{
	document.getElementById("munka").innerHTML="Feldolgoz�s folyamatban...";
	if (data.getElementsByTagName("input")[0].value.search(/[0-9]+(\|)[0-9]+/g)==-1) throw "Nincs egy koordin�ta sem megadva";
	var faluk = data.getElementsByTagName("input")[0].value.match(/[0-9]+(\|)[0-9]+/g);

	var reszletezo=new Array(); /* Szerkezet: J�t�kos_neve;koordik;...*/

	var tav=data.getElementsByTagName("input")[1].value;
	tav=tav.replace(/[^0-9\.]/g,""); data.getElementsByTagName("input")[1].value=tav;
	if (tav=="") {alert("A t�vols�g egy pozit�v val�s sz�m lehet. Tizedesvessz� elv�laszt�s�ra .-ot haszn�lj!");return;}
	tav=parseFloat(tav); data.getElementsByTagName("input")[1].value=tav;
	/*if (tav<1) {alert("Ilyen t�vols�gra ("+tav+" mez�) csak a megadott falu lehet. Adj meg egy nagyobb �rt�ket."); return;}*/

	var str="";
	str=document.getElementById("main").getElementsByTagName("h3")[0].getElementsByTagName("a")[0].innerText+'\n\nKeres�s [i]'+faluk+'[/i] falu(k) k�r�l, '+tav+' mez�t�vols�gra.\n\n[b]�rintett j�t�kosok[/b] (falusz�m):\n';
	var TT=document.getElementById("main").getElementsByTagName("table");
	for (var i=1;i<TT.length;i++){
		for (var j=1;j<TT[i].rows.length;j++){
			x=parseInt(TT[i].rows[j].cells[2].innerText.split("|")[0]);
			y=parseInt(TT[i].rows[j].cells[2].innerText.split("|")[1]);
			/*if (faluk.indexOf(x+"|"+y)>-1) continue;*/
			
			for (var k=0;k<faluk.length;k++){
				var RTav=Math.abs(Math.sqrt(Math.pow(faluk[k].split("|")[0]-x,2)+Math.pow(faluk[k].split("|")[1]-y,2)));
				if (RTav<=tav) {
					var CurrPlayer=TT[i].rows[j].cells[3].innerText;
					var poz=-1; /*Van e m�r ilyen j�t�kos a t�mb�nkbe? -1, ha nincs*/
					for (var l=0;l<reszletezo.length;l++) {if(reszletezo[l].indexOf(CurrPlayer+";")>-1) {poz=l;break;}}
					if (poz==-1){
						reszletezo.push(CurrPlayer+";"+x+"|"+y);
					} else {
						reszletezo[poz]+=";"+x+"|"+y;
					}
					break;
				}
			}
		}
	}
	for (var i=0;i<reszletezo.length;i++){
		str+="[player]"+reszletezo[i].split(";")[0]+"[/player] ("+(reszletezo[i].split(";").length-1)+" falu)\n";
	}
	str+="\n[b]R�szletezve:[/b]\n";
	if (data.getElementsByTagName("input")[3].checked){
		for (var i=0;i<reszletezo.length;i++){
			str+=reszletezo[i]+"\n\n";
		}
	} else {
		for (var i=0;i<reszletezo.length;i++){
			var seg=reszletezo[i].split(";");
			str+="[player]"+seg[0]+"[/player]:\n";
			for (var j=1;j<seg.length;j++){
				str+="- [coord]"+seg[j]+"[/coord]\n";
			}
			str+="\n";
	}}
	result.innerHTML=str;
	document.getElementById("munka").innerHTML="Feldolgoz�s k�sz.";
}catch(e){alert(e); document.getElementById("munka").innerHTML="Hiba.";}}

$(document).ready(function(){
$(function() {
        $( "#options" ).draggable();
});
});
void(0);