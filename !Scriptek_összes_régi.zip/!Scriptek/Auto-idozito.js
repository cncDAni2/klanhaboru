javascript:
var URL = "https://hup4.klanhaboru.hu/game.php?village=14588&screen=place";
var TIME = new Date(); TIME.setHours(16); TIME.setMinutes(58);
var STATE = 0;
var REF;
function main(){
	console.info(STATE);
	switch(STATE) {
		case 0: if (new Date() > TIME) { REF = window.open(URL, "ido1"); STATE++; } break;
		case 1: if (REF.document.getElementById("serverTime") && REF.document.getElementById("place_target")) STATE++; break;
		case 2:
			REF.document.forms[0].heavy.value = "28";
			//REF.document.forms[0].heavy.value = "7";
			REF.document.forms[0].spear.value = "173";
			REF.document.forms[0].snob.value = "1";
			REF.document.getElementById("place_target").getElementsByTagName("input")[0].value = "523|381";
			REF.document.getElementById("target_attack").click();
			STATE++;
			break;
		case 3: if (REF.document.getElementById("serverTime") && REF.document.getElementById("troop_confirm_go")) STATE++; break;
		case 4: REF.document.getElementById("troop_confirm_go").click(); STATE++; break;
	}
	setTimeout(function(){main()}, 1000);
}
main();
void(0);