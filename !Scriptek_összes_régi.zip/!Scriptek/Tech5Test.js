javascript:
function inic() {
    document.getElementsByTagName("head")[0].innerHTML += '<style type="text/css">body{ background: #000; color: rgb(192,192,192); font-family:"Lucida Console", Monaco, monospace; }';
    document.getElementsByTagName("body")[0].innerHTML = '<br><div align="center">\
.██████╗███╗...██╗.██████╗....████████╗███████╗.██████╗██╗..██╗███████╗<br>\
██╔════╝████╗..██║██╔════╝....╚══██╔══╝██╔════╝██╔════╝██║..██║██╔════╝<br>\
██║.....██╔██╗.██║██║............██║...█████╗..██║.....███████║███████╗<br>\
██║.....██║╚██╗██║██║............██║...██╔══╝..██║.....██╔══██║╚════██║<br>\
╚██████╗██║.╚████║╚██████╗.......██║...███████╗╚██████╗██║..██║███████║<br>\
.╚═════╝╚═╝..╚═══╝.╚═════╝.......╚═╝...╚══════╝.╚═════╝╚═╝..╚═╝╚══════╝<br></div><br><br><p id="console">Initializing OK<br>Deploying page... </p>';
        }
function console(str) {
    var d = new Date();
    document.getElementById("console").innerHTML += d.getHours() + ":" + d.getMinutes() + ":" + d.getSeconds() + " &rarr; " + str;
}
function openPage() {
    return window.open(document.location.href);
}
function pageClosed() {
}
function currentPageScreen() {
    if (PM.closed) {
        pageClosed();
        return "closed";
    }
    try {
        if (PM.document.getElementById("serverTime").innerHTML.length < 4)
            return "loading";
    } catch (e) {
        return "loading";
    }

    var result = PM.document.location.href;
    var patt = /[a-zA-Z][0-9]+\.[a-z]+\.[a-z]+\/game\.php/;
    if (!patt.test(result))
        return "notKh";
    return result.match(/screen=[a-z_]+/g)[0].split("=")[1];
}
function searchData(id) {
    var data = localStorage.getItem("Tech5AttackIds");
    console(data);
    if (data != null)
        data = data.split(";");
    else
        return "";
    for (var i = 0; i < data.length; i++) {
        if (data[i].split(":")[0] == id) {
            return data[i].split(":")[1];
        }
    }
    return "";
}
function isPageEnhanced() {
    if (PM.document.title.indexOf("<T5>") == 0) 
            return true;
        else
            return false;
}
function enhancePageAddRenamer() {
    /*span -> inputText + load*/
    var spanElements = PM.document.getElementById("content_value").selectNodes('//span[@class="quickedit-label"]');
    for (var i = 0; i < spanElements.length; i++) {
        /*var attackId=spanElements[i].parentNode.parentNode.getAttribute("data-id");*/
        var pElem = spanElements[i].parentNode;
        var currId = pElem.parentNode.parentNode.getAttribute("data-id");
        var attackName = searchData(currId);
        if (attackName == "")
            attackName = $.trim(spanElements[i].textContent);
        spanElements[i].parentNode.removeChild(spanElements[i]);

        var newInputElement = document.createElement("input");
        newInputElement.setAttribute("size", "35");
        newInputElement.setAttribute("type", "text");
        newInputElement.setAttribute("value", attackName);
        newInputElement.setAttribute("myAttribute", currId);
        pElem.parentNode.appendChild(newInputElement);
    }
}
function getSettedData() {
    console("GetSettedData");
    var getElements = PM.document.getElementById("content_value").selectNodes('//span[myattribute]');
    var data = localStorage.getItem("Tech5AttackIds");
    if (data == null)
        data = "";
    for (var i = 0; i < getElements.length; i++) {
        var myatt = getElements[i].getAttribute("myAttribute");
        var no = data.indexOf(";" + myAtt);
        if (no > -1) {
            var patt = new RegExp(";" + myAtt + ":", "g");
            data = data.replace(patt, ";" + myAtt + ":" + getElements[i].getAttribute("value"));
        } else {
            data += ";" + myAtt + ":" + getElements[i].getAttribute("value");
        }
    }
}
function enhancePage() {
    try {
        var date = new Date();
        document.title = date;
        if (!isPageEnhanced()) {
            switch (currentPageScreen()) {
                case "overview":
                    enhancePageAddRenamer();
                    break;
                default:
            }
            PM.document.title = "<T5>" + PM.document.title;
        } else {
            switch (currentPageScreen()) {
                case "overview":
                    getSettedData();
                    break;
                default:
            }
        }
    } catch (e) {
        console("Error: " + e);
    }
    setTimeout("enhancePage()", 600);
}

inic();
var PM = openPage();
document.getElementById("console").innerHTML += "OK<br>";
setTimeout("enhancePage()", 2000);
void(0);