javascript:
	try{
	patt=/\([0-9]+\)/g;
	var x=document.getElementsByTagName("td");
	for (i=1;i<x.length;i++){
		if(x[i].getAttribute("class")=="box-item") {
			if (patt.test(x[i].innerHTML)) {
				var bejovo=x[i].innerHTML.replace("(","");
				bejovo=bejovo.replace(")","");
				alert(bejovo);
			}
		}
	}
	} catch(err) {alert(err);}
void(0);