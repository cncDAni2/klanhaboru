javascript:
function setCookie(name, value, expire) { document.cookie = name + "=" + escape(value) + ((expire == null) ? "" : ("; expires=" + expire.toGMTString()));}
function getCookie(Name){ var search = Name + "="; if (document.cookie.length > 0) { offset = document.cookie.indexOf(search); if (offset != -1) { offset += search.length; end = document.cookie.indexOf(";", offset); if (end == -1) end = document.cookie.length; return unescape(document.cookie.substring(offset, end)); } }}

try{
if (document.location.href.indexOf("reservations")>=0){
	var X = document.getElementById("reservations").getElementsByTagName("table")[0];
	var str="";
	for (var i=2;i<X.rows.length;i++){
		s=X.rows[i].cells[1].innerHTML.match(/[0-9]+(\|)[0-9]+/g);
		str+=s[s.length-1]+";";
		s=X.rows[i].cells[4].getElementsByTagName("a");
		str+=s[s.length-1].innerHTML+",";
	}
	setCookie("cnc_lakat",str);
} else if (document.location.href.indexOf("info_player")>=0){
	var C=getCookie("cnc_lakat");
	if (C==null || C==undefined || C=="") {throw "nodata";}
	cc=C.split(",");
	X=document.getElementById("villages_list").rows;
	cell=X[0].insertCell(-1);
	cell.innerHTML='<img src="" alt=""/><b>Lakatok</b>';
	for (i=1;i<X.length;i++){
		cell=X[i].insertCell(-1);
		koord=X[i].cells[1].innerHTML;
		for (j=0;j<cc.length;j++){
			tulaj="";
			if (cc[j].split(";")[0]==koord) {
				tulaj=cc[j].split(";")[1];
				break;
			}
		} if (tulaj=="") tulaj="---";
		cell.innerHTML=tulaj;
	}
} else {
	alert("Futtatni a foglal�sokn�l kell vagy egy j�t�kos profilj�n");
}}catch(e){if (e=="nodata") alert("Nincs adat felv�ve"); else alert(e)}
void(0);