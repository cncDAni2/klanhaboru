javascript:
LIMIT=700000;
try{
var table=document.getElementById("royalty-upgrade-table").rows;
var s=""; var n="";
for (var i=1;i<table.length-1;i++){
	s=table[i].cells[2].textContent.replace(/\./g,"").match(/[0-9]+/g);
	ny=parseInt(s[0])+parseInt(s[1])+parseInt(s[2]);
	if (ny>LIMIT) table[i].cells[0].getElementsByTagName("input")[0].checked=true; else table[i].cells[0].getElementsByTagName("input")[0].checked=false;
}
}catch(e){alert(e);}
void(0);