javascript:
oldal = document.location.href;
var szam=prompt("H�nyszor akarod duplik�lni ezt az oldalt?");
var RefArray=new Array();
szam=parseInt(szam);

for (var i=0;i<szam;i++){
	neve="web" + i;
	aktualis=window.open(oldal,neve);
	RefArray[i]=aktualis;
	
}
void(0);