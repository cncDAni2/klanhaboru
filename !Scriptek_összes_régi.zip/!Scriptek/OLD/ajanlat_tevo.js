javascript:
var elad="iron"; 		/*Wood, stone, vagy iron (fa/agyag/vas)*/
var e_ajanlat=1000; /*Ennyit aj�nlassz*/
var kell="stone"; 		/*Wood, stone, vagy iron (fa/agyag/vas)*/
var k_ajanlat=1000; /*Ennyi�rt aj�nlod*/
var ido=25;			/*Ennyi �r�ra*/

try{
vas=parseInt(document.getElementById("iron").innerHTML);
agyag=parseInt(document.getElementById("stone").innerHTML);
fa=parseInt(document.getElementById("wood").innerHTML);
kereskedok=Math.round(parseInt(Data.Trader.amount)*1.0);
if ((kereskedok*1000+agyag)>fa) kereskedok=Math.ceil(((fa-agyag)/1000)+((kereskedok-((fa-agyag)/1000))/2));
var ennyiszer=kereskedok;



var X=document.forms[1];
X.sell.value=e_ajanlat;
document.getElementById("res_sell_"+elad).checked=true;
X.buy.value=k_ajanlat;
document.getElementById("res_buy_"+kell).checked=true;
X.max_time.value=ido;
X.multi.value=ennyiszer;X.submit();
}catch(e){alert(e);}

void(0);