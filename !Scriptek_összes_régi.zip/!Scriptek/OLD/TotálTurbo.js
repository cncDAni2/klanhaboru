javascript:
if (LEPES == undefined) {
		var d=document;	
		if(window.frames.length>0) d=window.main.document;
		url=d.URL;
		if(url.indexOf('screen=place')==-1) {
			alert('Gy�lekez�helyen pr�b�ld...');
			exit(0);
		}
		var LEPES=1;
}
if (LEPES==1) {
	b = new Array();
	b[0] = new Array(483,402); 
	b[1] = new Array(484,403);
	b[2] = new Array(485,403);
	b[3] = new Array(477,402);
	b[4] = new Array(478,401);
	b[5] = new Array(479,402);
	var KL=new Array(20,20); 
	var szam=KL.length;
	szam=parseInt(szam);
	oldal = document.location.href;
	tagok = oldal.split(/[0-9]+/g);
	temp = oldal.match(/[0-9]+/g);
	tagok[0]=tagok[0] + temp[0] + tagok[1];
	tagok[1]=temp[1];
	var ID = new Array();
	ID[0]=temp[1];
	ID[1]=9765;
	var j=0;
	var RefArray=new Array();
	for (var i=0;i<szam;i++){
		neve="web" + i;
		if (i=3) j++;
		var RealOldal=tagok[0] + ID[j] + tagok[1];
		aktualis=window.open(oldal,neve);
		RefArray[i]=aktualis;
	}
	LEPES=2;
} else if (LEPES==2) {
	for (i=0;i<szam;i++){
			RefArray[i].document.forms[0].x.value=b[i][0];
			RefArray[i].document.forms[0].y.value=b[i][1];
			RefArray[i].document.forms[0].light.value=KL[i];
			RefArray[i].document.forms[0].spy.value=0; 
			RefArray[i].document.forms[0].attack.click();
	}
	LEPES=3;
} else if (LEPES==3) {
	function elkuld(){
		if (i>szam) clearInterval(ZZ);
		RefArray[i].document.forms[0].submit.click();
		i++;
	}
	var i=0;
	LEPES=4;
	ZZ=setInterval("elkuld()",1000);
} else if (LEPES==4) {
	for (var i=0;i<szam;i++){
		RefArray[i].close();
	}
}
void(0);