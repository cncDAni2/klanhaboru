javascript:
function snipe(){
	RefArray[i].document.forms[0].submit.click();
	i++;
	setTimeout("snipe()",250); /*250 ms = 1/4mp. �rd �t, ha szeretn�d.*/
	return;
}
if (LEPES == undefined) {
	var d=document;
	if(window.frames.length>0) d=window.main.document;
	url=d.URL;

	patt=/(id=)[0-9]+/g;
	var ID=patt.exec(url);
	patt=/[0-9]+/g;
	var ID=patt.exec(ID);
	if (ID==null || ID=="") { 
		alert("Nem j� helyr�l ind�tod.\nKattints egy falura hogy bej�jj�n az inform�ci�s lap, �s ott pr�b�ld"); 
		exit(0); 
	}

	db=prompt("Mennyi er�s�t�st szeretn�l elk�ldeni a falura?","4");

	elotag=url.split("screen=");
	oldal = elotag[0] + "screen=place&target=" + ID;
	var RefArray=new Array();
	for (var i=0;i<db;i++){
		neve="web" + i;
		aktualis=window.open(oldal,neve);
		RefArray[i]=aktualis;
	}
	var LEPES=1;
	exit(0);
}

if (LEPES == 1){
	for (var i=0;i<db;i++) RefArray[i].document.forms[0].support.click();
	var LEPES = 2;
	exit(0);
}
if (LEPES == 2){
	var i=0;
	snipe();
	var LEPES = 3;
	exit(0);
}
if (LEPES == 3){
	for (var i=0;i<db;i++) RefArray[i].close();
	LEPES = undefined;
}
void(0);