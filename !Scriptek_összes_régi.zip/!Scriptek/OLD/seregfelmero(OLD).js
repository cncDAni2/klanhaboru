javascript:
var N=5; /*Lapok sz�ma*/
if (document.location.href.indexOf("screen=overview_villages")==-1) {alert("Ez a script az �ttekint�sben fut le csak.\n\nPr�miumosoknak el�sz�r �ttekint�s �talak�t� futtat�s�ra van sz�ks�g a Termel�i n�zetbe!"); exit(0);}
try{
	RefArray=new Array(); /*Window pointers*/
	WAIT=new Array(); /*Mennyiszer pr�b�ltuk sikertelen�l elemezni (lapID~dbsz�m)*/
	FELDOLG=new Array(); /*Miket dolgozunk fel �pp (lapID~FALUK t�mb elemei)*/
	FALUK=new Array(); /*Munkalista*/
	if (typeof(cURL=='undefined')) var csoport=false; else var csoport=true;
	init();
	var LAP=0; /*Aktu�lis lapmunka*/
	var BASE_URL=document.location.href.split("game.php")[0]+"game.php";
	if (document.location.href.indexOf("t=")>0) BASE_URL+="?"+document.location.href.match(/t=[0-9]+/g)[0]+"&"; else BASE_URL+="?";
	eloszto();
}catch(e){alert("Ind�t�si hiba:\n"+e);}

function init(){try{
	try{  /*PF-Area*/
	var PFA=document.getElementById("production_table"); 
	if (PFA.rows[0].cells.length>6) {
		for (i=0;i<PFA.rows.length;i++){ 
			PFA.rows[i].deleteCell(9); 
			PFA.rows[i].deleteCell(8); 
			PFA.rows[i].deleteCell(7); 
			PFA.rows[i].deleteCell(5); 
			PFA.rows[i].deleteCell(0); 
	}}}catch(e){alert("PF -> Nem-PF konverzi�s hiba:\n"+e);} 


	document.getElementById("header_info").innerHTML='<p id="sereg"></p>';

	var X=document.getElementById("production_table").rows;
	hossz=X[0].cells[0].offsetWidth;
	hosszT=X[0].cells[4].offsetWidth;
	for (var i=0;i<X.length;i++){
		X[i].cells[0].width=hossz;
		X[i].cells[4].width="100px";
		if (document.getElementById("tav")){
			X[i].deleteCell(4);
			X[i].deleteCell(3);
			X[i].deleteCell(2);
			var fix=1;
		} else {
			X[i].deleteCell(3);
			X[i].deleteCell(2);
			X[i].deleteCell(1);
			var fix=0;
		}
		for (var j=0;j<2;j++){
			if (j==0) var str="Itthoni"; else var str="�sszes";
			newcell=X[i].insertCell((j*10)+1+fix);
			if (i==0) newcell.innerHTML='<img src="http://hu17.klanhaboru.hu/graphic/unit/unit_spear.png" title="'+str+' l�ndzs�sok. Klikk a sz�r�shez." onclick=Egyseg_szuro(this)>';
			newcell=X[i].insertCell((j*10)+2+fix);
			if (i==0) newcell.innerHTML='<img src="http://hu17.klanhaboru.hu/graphic/unit/unit_sword.png" title="'+str+' kardosok. Klikk a sz�r�shez." onclick=Egyseg_szuro(this)>';
			newcell=X[i].insertCell((j*10)+3+fix);
			if (i==0) newcell.innerHTML='<img src="http://hu17.klanhaboru.hu/graphic/unit/unit_axe.png" title="'+str+' b�rdosok. Klikk a sz�r�shez." onclick=Egyseg_szuro(this)>';
			newcell=X[i].insertCell((j*10)+4+fix);
			if (i==0) newcell.innerHTML='<img src="http://hu17.klanhaboru.hu/graphic/unit/unit_archer.png" title="'+str+' �j�szok. Klikk a sz�r�shez." onclick=Egyseg_szuro(this)>';
			newcell=X[i].insertCell((j*10)+5+fix);
			if (i==0) newcell.innerHTML='<img src="http://hu17.klanhaboru.hu/graphic/unit/unit_spy.png" title="'+str+' k�mek. Klikk a sz�r�shez." onclick=Egyseg_szuro(this)>';
			newcell=X[i].insertCell((j*10)+6+fix);
			if (i==0) newcell.innerHTML='<img src="http://hu17.klanhaboru.hu/graphic/unit/unit_light.png" title="'+str+' k�nny�lovasok. Klikk a sz�r�shez." onclick=Egyseg_szuro(this)>';
			newcell=X[i].insertCell((j*10)+7+fix);
			if (i==0) newcell.innerHTML='<img src="http://hu17.klanhaboru.hu/graphic/unit/unit_marcher.png" title="'+str+' lovas�j�szok. Klikk a sz�r�shez." onclick=Egyseg_szuro(this)>';
			newcell=X[i].insertCell((j*10)+8+fix);
			if (i==0) newcell.innerHTML='<img src="http://hu17.klanhaboru.hu/graphic/unit/unit_heavy.png" title="'+str+' neh�zlovasok. Klikk a sz�r�shez." onclick=Egyseg_szuro(this)>';
			newcell=X[i].insertCell((j*10)+9+fix);
			if (i==0) newcell.innerHTML='<img src="http://hu17.klanhaboru.hu/graphic/unit/unit_ram.png" title="'+str+' kosok. Klikk a sz�r�shez." onclick=Egyseg_szuro(this)>';
			newcell=X[i].insertCell((j*10)+10+fix);
			newcell.setAttribute("style","border-right:  2px solid black;");
			if (i==0) newcell.innerHTML='<img src="http://hu17.klanhaboru.hu/graphic/unit/unit_catapult.png" title="'+str+' katapultok. Klikk a sz�r�shez." onclick=Egyseg_szuro(this)>';
		}
		newcell=X[i].insertCell(X[i].cells.length-1);
		newcell.style.backgroundColor="#49F";
		if (i==0) newcell.innerHTML='<img src="http://hu17.klanhaboru.hu/graphic/buildings/barracks.png" title="K�pz�si id� percben. Klikk a sz�r�shez." onclick=Egyseg_szuro(this)>';
	}
}catch(e){alert(e);}}

function recalc(){try{
	var Z=document.getElementById("sereg");
	if (Z.innerHTML==""){
		for (var i=0;i<RefArray.length;i++){
			RefArray[i].window.close();
		}
		Z.innerHTML='<a href="javascript:recalc()">Friss�t�s a jelenleg kiv�laszott csoportra</a><br><b>�sszesen</b> (';
		var X=document.getElementById("production_table").rows;
		Z.innerHTML+=X.length-1+" falu)<br>Itthon: ";
		
		var sereg=new Array(0,0,0,0,0,0,0,0,0,0);
		var sereg2=new Array(0,0,0,0,0,0,0,0,0,0);
		for (var i=1;i<X.length;i++){
			for (var j=0;j<10;j++){
				sereg[j]+=parseInt(X[i].cells[j+1].innerHTML);
			}
			for (var j=0;j<10;j++){
				sereg2[j]+=parseInt(X[i].cells[j+11].innerHTML);
			}
		}
		Z.innerHTML+=sereg+"<br>�ssz: "+sereg2+"<br>1 faluja jut� sereg (nl=6,...): ";
		var power=sereg[0]+sereg[1]+sereg[2]+sereg[3]+2*sereg[4]+4*sereg[5]+5*sereg[6]+6*sereg[7]+5*sereg[8]+8*sereg[9];
		Z.innerHTML+=Math.round(parseInt(power)/X.length)+"<br>...k�m/kata n�lk�l: ";
		var power=sereg[0]+sereg[1]+sereg[2]+sereg[3]+4*sereg[5]+5*sereg[6]+6*sereg[7]+5*sereg[8];
		Z.innerHTML+=Math.round(parseInt(power)/X.length)+"<br>";
		var newNode=document.createElement("div");
		newNode.setAttribute("align","center");
		var x2=document.getElementById("content_value");
		newNode.innerHTML='<br>Seregsz�r�s: <a href="javascript: Auto_csop(\'all\');">Mind</a>|<a href="javascript: Auto_csop(\'tamad\');">T�mad�k</a>|<a href="javascript: Auto_csop(\'vedo\');">V�d�k</a>|<a href="javascript: Auto_csop(\'kem\');">2000+ k�m</a>|<a href="javascript: Auto_csop(\'kata\');">1000+ katapult</a>|<a href="javascript: Auto_csop(\'vegyes\');">Vegyes</a>|<a href="javascript: Auto_csop(\'itthon\');">Itthon l�v�k</a>|<a href="javascript: Auto_csop(\'fok\');">T�bb, mint ?? egys�g</a>';
		x2.insertBefore(newNode,x2.childNodes[1]);
		
	} else {
		a=prompt("Ezen csoport neve?","�j");
		if (a==null) return;
		Z.innerHTML+="<br><b>"+a+"</b> (";
		var falu=0;
		var X=document.getElementById("production_table").rows;
		var sereg=new Array(0,0,0,0,0,0,0,0,0,0);
		var sereg2=new Array(0,0,0,0,0,0,0,0,0,0);
		for (var i=1;i<X.length;i++){
			if (X[i].style.display=="none") continue;
			falu++;
			for (var j=0;j<10;j++){
				sereg[j]+=parseInt(X[i].cells[j+1].innerHTML);
			}
			for (var j=0;j<10;j++){
				sereg2[j]+=parseInt(X[i].cells[j+11].innerHTML);
			}
		}
		Z.innerHTML+=falu+" falu)<br>Itthon: "+sereg+"<br>�ssz: "+sereg2+"<br>1 faluja jut� sereg (nl=6,...): ";
		var power=sereg[0]+sereg[1]+sereg[2]+sereg[3]+2*sereg[4]+4*sereg[5]+5*sereg[6]+6*sereg[7]+5*sereg[8]+8*sereg[9];
		Z.innerHTML+=Math.round(parseInt(power)/falu)+"<br>...k�m/kata n�lk�l: ";
		var power=sereg[0]+sereg[1]+sereg[2]+sereg[3]+4*sereg[5]+5*sereg[6]+6*sereg[7]+5*sereg[8];
		Z.innerHTML+=Math.round(parseInt(power)/falu)+"<br>";
	}
}catch(e){alert(e);}}
 
function Egyseg_szuro(ez){try{
	if (ez.title.split(".")[0].indexOf("K�pz�si")==-1) var kerdes=prompt(ez.title.split(".")[0]+" alapj�n val� sz�r�s.\n\nAdja meg minimum mennyi egys�g legyen ebb�l a fajt�b�l a falukban?"); else
		var kerdes=prompt(ez.title.split(".")[0]+" val� sz�r�s.\n\nAdja meg minimum h�ny perc k�pz�si id� legyen a kiv�lasztand� csoportba?");
	if (kerdes==null || kerdes=="") return;
	kerdes=kerdes.replace(/[^0-9]/g,"");
	if (kerdes=="") {alert("Sz�mot kell megadni"); return;}
	kerdes=parseInt(kerdes,10);
	
	var X=document.getElementById("production_table").rows;
	var sor=ez.parentNode.cellIndex; 
	var itelet=false;
	for (var i=1;i<X.length;i++){
		var egyseg=parseInt(X[i].cells[sor].innerHTML,10);
		if (egyseg<kerdes){
			X[i].setAttribute("style","display: none");
		} else {
			X[i].setAttribute("style","display: line");
		}
	}
}catch(e){alert("Hiba keletkezett:\n"+e);}}
 
function Auto_csop(mit){try{
	var X=document.getElementById("production_table").rows;
	var itelet=false;
	if (mit=="fok") {
		var fok=prompt("Sz�r�s itthon l�v� egys�gek sz�ma szerint (tanyahely szerint, pl. nl=6).\n\nAdja meg, h�ny egys�gn�l t�bb lakos� falukat szeretne kilist�ztatni.");
		fok=parseInt(fok);
	}
	for (var i=1;i<X.length;i++){
		var sereg=new Array(0,0,0,0,0,0,0,0,0,0); var osszI=0;
		var sereg2=new Array(0,0,0,0,0,0,0,0,0,0); var osszO=0;
		for (var j=0;j<10;j++){
			sereg[j]+=parseInt(X[i].cells[j+1].innerHTML);
			osszI+=sereg[j];
		}
		for (var j=0;j<10;j++){
			sereg2[j]+=parseInt(X[i].cells[j+11].innerHTML);
			osszO+=sereg2[j];
		}
		var tamado=sereg2[3]+sereg2[5]+sereg2[6]+sereg2[8];
		var vedo=sereg2[0]+sereg2[1]+sereg2[7];
		itelet=false;
		switch (mit) {
			case "tamad": if (tamado>10*vedo) itelet=true; break;
			case "vedo": if (vedo>10*tamado)  itelet=true; break;
			case "kem":  if(sereg2[4]>2000) itelet=true; break;
			case "kata": if(sereg2[9]>1000) itelet=true; break;
			case "vegyes": if (tamado<10*vedo && vedo<10*tamado) itelet=true; break;
			case "itthon": if (osszI>osszO*0.9) itelet=true; break;
			case "fok": var power=sereg[0]+sereg[1]+sereg[2]+sereg[3]+2*sereg[4]+4*sereg[5]+5*sereg[6]+6*sereg[7]+5*sereg[8]+8*sereg[9]; if (power>=fok) itelet=true; break;
			case "all": itelet=true;
		}
		if (!itelet){
			X[i].setAttribute("style","display: none");
		} else {
			X[i].setAttribute("style","display: line");
		}
	}
	return;
}catch(e){alert("Hiba :(\n"+e);}}

function szamol(P_IND){try{ /*Seregsz�mol�s az adott lapon*/
	var X=document.getElementById("production_table").rows;
	var sereg=new Array(0,0,0,0,0,0,0,0,0,0);
	var sereg2=new Array(0,0,0,0,0,0,0,0,0,0);
	/*alert(HashTable[P_IND]+". sorban k�sz a seregsz�m�t�s.");*/
	var Z=RefArray[P_IND].document.getElementById("train_form").getElementsByTagName("table")[0].rows;
	for (var i=1;i<Z.length-1;i++){
		var egyseg=Z[i].cells[0].getElementsByTagName("img")[0].src.match(/[a-z]+\.png/g)[0].replace(".png","");
		switch (egyseg){
			case "spear": sereg[0]=Z[i].cells[2].innerText.split("/")[0]; sereg2[0]=Z[i].cells[2].innerText.split("/")[1]; break;
			case "sword": sereg[1]=Z[i].cells[2].innerText.split("/")[0]; sereg2[1]=Z[i].cells[2].innerText.split("/")[1]; break;
			case "axe": sereg[2]=Z[i].cells[2].innerText.split("/")[0]; sereg2[2]=Z[i].cells[2].innerText.split("/")[1]; break;
			case "archer": sereg[3]=Z[i].cells[2].innerText.split("/")[0]; sereg2[3]=Z[i].cells[2].innerText.split("/")[1]; break;
			case "spy": sereg[4]=Z[i].cells[2].innerText.split("/")[0]; sereg2[4]=Z[i].cells[2].innerText.split("/")[1]; break;
			case "light": sereg[5]=Z[i].cells[2].innerText.split("/")[0]; sereg2[5]=Z[i].cells[2].innerText.split("/")[1]; break;
			case "marcher": sereg[6]=Z[i].cells[2].innerText.split("/")[0]; sereg2[6]=Z[i].cells[2].innerText.split("/")[1]; break;
			case "heavy": sereg[7]=Z[i].cells[2].innerText.split("/")[0]; sereg2[7]=Z[i].cells[2].innerText.split("/")[1]; break;
			case "ram": sereg[8]=Z[i].cells[2].innerText.split("/")[0]; sereg2[8]=Z[i].cells[2].innerText.split("/")[1]; break;
			case "catapult":	 sereg[9]=Z[i].cells[2].innerText.split("/")[0]; sereg2[9]=Z[i].cells[2].innerText.split("/")[1]; break;
			default: alert(egyseg + " - nincs ilyen");
		}
	}
	/*K�pz�si id� sz�m�t�sa*/
		var maxtime=0; var temptime=0;
		try{
			var IDO_b=RefArray[P_IND].document.getElementById("trainqueue_wrap_barracks").getElementsByTagName("table")[0].rows;
			if (IDO_b.length==2) var hossz=2; else hossz=IDO_b.length-1;
			for (var i=1;i<hossz;i++){
				maxtime+=parseInt(IDO_b[i].cells[1].innerText.split(":")[0],10)*60+parseInt(IDO_b[i].cells[1].innerText.split(":")[1],10);
			}
		} catch(e) {}
		try{
			IDO_b=RefArray[P_IND].document.getElementById("trainqueue_wrap_stable").getElementsByTagName("table")[0].rows;
			if (IDO_b.length==2) var hossz=2; else hossz=IDO_b.length-1;
			for (var i=1;i<hossz;i++){
				temptime+=parseInt(IDO_b[i].cells[1].innerText.split(":")[0],10)*60+parseInt(IDO_b[i].cells[1].innerText.split(":")[1],10);
			}
			if (maxtime<temptime) maxtime=temptime;
			temptime=0;
		} catch(e) {}
		try{
			IDO_b=RefArray[P_IND].document.getElementById("trainqueue_wrap_garage").getElementsByTagName("table")[0].rows;
			if (IDO_b.length==2) var hossz=2; else hossz=IDO_b.length-1;
			for (var i=1;i<hossz;i++){
				temptime+=parseInt(IDO_b[i].cells[1].innerText.split(":")[0],10)*60+parseInt(IDO_b[i].cells[1].innerText.split(":")[1],10);
			}
			if (maxtime<temptime) maxtime=temptime;
		} catch(e) {}
	
	
	/*ID -> sor konvert�l�s*/
	var check=false;
	for (var i=1;i<X.length;i++){
		if (X[i].cells[0].getElementsByTagName("a")[0].href.match(/village=[0-9]+/g)[0].replace("village=","")==HashTable[P_IND]){
			for (var j=0;j<10;j++){
				X[i].cells[j+1].innerHTML=sereg[j];
				X[i].cells[j+11].innerHTML=sereg2[j];
			}
			X[i].cells[X[i].cells.length-2].innerHTML=maxtime;
			check=true;
			break;
		}
	}
	if (!check) {HashTable[P_IND]=""; throw "Nem tal�lom a vizsg�lt falu azonos�t�j�t ("+HashTable[P_IND]+") az eredeti oldalon";}
	HashTable[P_IND]="";
}catch(e){alert(e);}}

function eloszto(){try{
/*
 * Meg k�ne n�zni, hogy ha az oldal ID-je a t�bl�ba cells[1]==sz�m, akkor az szem�t!
 */
	var X=document.getElementById("production_table").rows;
	var index=-1;
	while (true){
		/*Keress�k a k�vetkez� helyet, ami vizsg�lni lehetne. index=sor; ID=falu ID-je*/
		for (var j=1;j<X.length;j++){
			var ID=X[j].cells[0].getElementsByTagName("a")[0].href.match(/village=[0-9]+/g)[0].replace("village=","");
			if (X[j].cells[1].innerHTML==""){
				index=j; break;
			} else if (X[j].cells[1].innerHTML=="..."){
				if (HashTable.indexOf(ID)==-1) {index=j; break;}
			}
		}
		if (index>0) {
		/*if (HashTable[IND]=="") alert(IND+"�RES BASSZAMEG");*/
		if ((RefArray[IND]==undefined) || (RefArray[IND].closed) || (RefArray[IND].location.href.indexOf("train")==-1) || (HashTable[IND]=="")) {
			/*alert(IND+": �j munka felv�tele - "+index+". sor");*/
			RefArray[IND]=window.open(X[index].cells[0].getElementsByTagName("a")[0].href.replace("overview","train"),"seregmero"+IND);
			X[index].cells[1].innerHTML="...";
			HashTable[IND]=ID;
			break;
		}} else { /*Hash t�bla s�r�l�svizsg�lat: j� ID van benne, de nincs ilyen lap! */
			if (RefArray[IND]==undefined) {if (IND>4) break; else {IND++;continue;}}
			if (HashTable[IND]!="") {if (HashError[IND]==undefined) HashError[IND]=0; else HashError[IND]++;}
			if (HashError[IND]>20) {HashTable[IND]=""; RefArray[IND].close(); HashError[IND]=0;}
		}
		if (HashTable[IND]=="") {if (IND>4) break; else {IND++;continue;}}
		if (RefArray[IND].document.readyState!="complete"){
			if (IND>4) break; else {IND++;continue;}
		} else { /*Simulate*/
			try{
				if (RefArray[IND].document.getElementsByTagName("input")[0].value==undefined) {
					teszt=RefArray[IND].document.getElementById("train_form").getElementsByTagName("table")[0].rows.innerHTML;
					if (teszt==undefined ||teszt==null || teszt=="undefined") throw "error";
				/*alert(IND+"ERRROR"); */
				if (IND>4) break; else {IND++;continue;}
			}}catch(e){ if (IND>4) break; else {IND++;continue;}}
		}
		/*Munkaegyeztet�s a hash t�bl�val*/
		if (RefArray[IND].document.location.href.match(/village=[0-9]+/g)[0].replace("village=","")!=HashTable[IND]){if (IND>4) break; else {IND++;continue;}}
		/*IND READY!*/
		szamol(IND);
		continue;
	}
	if (IND>4) IND=0; else IND++;
}catch(e){alert(e);}
	if (index>0) setTimeout("eloszto()",100); else {
		var end=true;
		for (var i=0;i<HashTable.length;i++){
			if (HashTable[i]!="") {end=false; setTimeout("eloszto()",100); return;}
		}
		if (end) recalc();
	}
	return;
}

void(0);