javascript:
PONTOS=90; /*Ennyivel hamarább indítja a támadást.*/
function elkuld(){
	d.forms[0].submit.click();
	return;
}

function createWorker(main){
    var blob = new Blob(
        ["(" + main.toString() + ")(self)"],
        {type: "text/javascript"}
    );
    return new Worker(window.URL.createObjectURL(blob));
}
	
function checktimeshift(){
	var f_ora=document.getElementById("serverDate").innerHTML+" "+document.getElementById("serverTime").innerHTML;
	var f_datum=f_ora.match(/[0-9]+/g);
	var serverido = new Date(f_datum[2],f_datum[1]-1,f_datum[0],f_datum[3],f_datum[4],f_datum[5],0);
	var otthoniido= new Date();
	if (Math.abs(otthoniido-serverido)>5000) {
			return "Vigyázat!\nA szerver ideje, és az Ön operációs rendszerének ideje erősen nem egyforma. A támadás küldése viszont az Ön rendszerének idejéhez lesz mérve.\nAz időeltolódás: "+((otthoniido-serverido)/1000) +
			"mp, azaz "+(((otthoniido-serverido)/1000)/60).toFixed(2)+" perc!\n\n";
	}
	return "";
}

function writeoutDate(d) {
	return d.getFullYear() + "." + leadNull((d.getMonth()+1)) + "." + leadNull(d.getDate()) + " " +
		leadNull(d.getHours()) + ":" + leadNull(d.getMinutes()) + ":" + leadNull(d.getSeconds()) + ":" + leadNull(d.getMilliseconds(), true);
	
	function leadNull(num, triple) {
		if (triple && num<100) return "00" + num;
		if (num<10) return "0" + num;
		return num;
	}
}

var d=document;
if (window.frames.length>0 && typeof window.main !== 'undefined') d=window.main.document;
if (d.URL.indexOf('try=confirm')==-1) {
	alert('Gyülekezőhelyen, támadás/erősítés leokézása előtt próbáld...');
	exit(0);
}

var jelenido=d.getElementById("serverTime").innerHTML;
var jd=d.getElementById("serverDate").innerHTML;
var jelenido=new Date(
	parseInt(jd.split("/")[2], 10),
	parseInt(jd.split("/")[1], 10)-1,
	parseInt(jd.split("/")[0], 10),
	parseInt(jelenido.split(":")[0], 10),
	parseInt(jelenido.split(":")[1], 10),
	parseInt(jelenido.split(":")[2], 10));
var alertStr = "";

try{
	alertStr = checktimeshift();
}catch(e){alert('Hiba történt, a script kilép...\n\n' + e); exit(0);}

var datum=writeoutDate(jelenido);
tipusa = d.getElementById("troop_confirm_go").value;

var BeIdo=prompt(alertStr + tipusa + "\n Adja meg az indítás idejét:\n(Formátum: Év Hónap Nap Óra Perc mp [ms] - az elválasztás nem számít, a ms opcionális)", datum);
if (BeIdo==null) exit(0);

var datum=BeIdo.match(/[0-9]+/g);
for (i=0;i < datum.length;i++){
	datum[i] = parseInt(datum[i], 10); 
}
if (datum.length<7) datum[6]=0;
if (datum[0] < 2017 || datum[0] > 2030 || datum[1]>12 || datum[2]>31 || datum[3]>23 || datum[4]>59 || datum[5]>59 || datum[6]>999) {alert ("Érvénytelen időpontmegadás"); exit(0);}

var dateforOutput = new Date(datum[0],datum[1]-1,datum[2],datum[3],datum[4],datum[5],datum[6]);
var ERKEZES = new Date(datum[0],datum[1]-1,datum[2],datum[3],datum[4],datum[5],datum[6]);

kieg=document.createElement("p");
kieg.innerHTML="<img src=\"http://cncdani2.000webhostapp.com/!Files/images/ido_dead.png\" height=\"20px\">Felülbírálás:<br>cnc időzítő beállítva erre:<br><b>" + writeoutDate(dateforOutput) + "</b><br><p style='display:inline' id='pontos'>Pontosítás: "+PONTOS+"ms (<font style='font-size:80%; color: red; text-decoration: none;'>Nem módosítható</font>)</p>"; 
document.getElementById("date_arrival").innerHTML="";
document.getElementById("date_arrival").appendChild(kieg);

/*SZIDO meghatározása, azaz mennyi ms múlva kell OK-ézni*/
ERKEZES.setMilliseconds(ERKEZES.getMilliseconds() + PONTOS);
var CURRTIME=new Date();
CURRTIME.setMilliseconds(CURRTIME.getMilliseconds()+PONTOS);
SZIDO=ERKEZES - CURRTIME;

if (typeof(Worker) == "undefined") {
	setTimeout(function(){
		elkuld();
	}, SZIDO);
} else {
	var worker = createWorker(function(self){
		self.addEventListener("message", function(e) {
			setTimeout(function(){
				postMessage('');
			}, e.data);
		}, false);
	});

	worker.onmessage = function(e) {
		elkuld();
	};
	worker.postMessage(SZIDO);
}

