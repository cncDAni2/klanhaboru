javascript: /*Exp/imp: BE;faluID;faluID;KI;...;�RME;... - vizsg�latkor meg "ha =BE, akkor ez a be, addig am�g "KI" nem lesz.*/
var BODY = document.getElementsByTagName("body")[0];
try { /*PF-Area*/
    var PFA = document.getElementById("production_table");
    if (PFA.rows[0].cells.length > 5) PF = true;
    else PF = false;
    if (PF) {
        for (i = 0; i < PFA.rows.length; i++) {
            PFA.rows[i].deleteCell(9);
            PFA.rows[i].deleteCell(8);
            PFA.rows[i].deleteCell(7);
            PFA.rows[i].deleteCell(5);
            PFA.rows[i].deleteCell(0);
        }
    }
} catch (e) {
    alert(e);
}
var oz = document.getElementById("production_table").getElementsByTagName("a");
for (var o = 0; o < oz.length; o++) {
    try {
        if (oz[o].href.indexOf("javascript") == -1) oz[o].setAttribute("target", "_BLANK");
    } catch (e) {}
}
BODY.innerHTML = '<p align="center"><audio id="audio1" controls="controls" autoplay="autoplay"><source id="wavhang" src="" type="audio/wav"></audio><br><img src="http://cncdani2.000webhostapp.com/!Files/pic/szem4/excavator.gif" height="221px"></p> <h1 align="center">KOTR�G�P</h1><h4 align="center"><i>...�s �rmever�</i></h3><br><p style="padding-left:25px">Minimum nyers/falu: <img alt="Fa" title="Fa" src="http://hu17.tribalwars.net/graphic/holz.png"> <input type="text" id="fa_" size="5" value="50000"><img alt="Agyag" title="Agyag" src="http://hu17.tribalwars.net/graphic/lehm.png?6c9bd"> <input type="text" id="agyag_" size="5" value="50000"> <img alt="Vas" title="Vas" src="http://hu17.tribalwars.net/graphic/eisen.png?0e9e5"> <input type="text" id="vas_" size="5" value="50000"> &nbsp;&nbsp;&nbsp;Felt�lt�si m�d? <input type="checkbox" onclick=set_balance()> <a onclick="javascript: alert(\'Az opci� bepip�l�sa ut�n a BE oszlopba megjel�lt falukat a script tov�bbra is felt�lti nyersanyaggal, de �gyel arra, hogy ne l�phesse t�l a rakt�r kapacit�s�t. Megfelel� pip�l�ssal egy j� balance hozhat� l�tre.\')">Mi ez?</a> &nbsp;&nbsp;&nbsp; Felt�lt�s a rakt�r kapacit�s�nak <input type="text" size="2" id="maxup" value="80">%-�ig. Max sz�ll�t�si t�vols�g: <input type="text" value="30" size="2" id="maxtav"> mez�&nbsp;&nbsp;&nbsp;&nbsp;</p>\  <p id="newrowarea"><b>�j k�ls� falu megad�sa:</b> Koordin�ta <input type="text" size="7"> Kezdeti nyers <img alt="Fa" title="Fa" src="http://hu17.tribalwars.net/graphic/holz.png"> <input type="text" size="5" value="0"><img alt="Agyag" title="Agyag" src="http://hu17.tribalwars.net/graphic/lehm.png?6c9bd"> <input type="text" size="5" value="0"> <img alt="Vas" title="Vas" src="http://hu17.tribalwars.net/graphic/eisen.png?0e9e5"> <input type="text" size="5" value="0"> <input type="button" onclick=addNewRow() value="Felvisz"> <input type="button" onclick=addMoreRow() value="T�meges felvitel"></p>\  <p id="uzi"><b>�zenetek:</b></p>' + document.getElementById("contentContainer").innerHTML;
BODY.innerHTML += '<a href="http://cncdani2.000webhostapp.com" target="_BLANK">c&cDAni2 webhost</a><p id="db"></p>';

function db(str) {
    var cdate = new Date();
    document.getElementById("db").innerHTML += "<br>" + cdate.getHours() + ":" + cdate.getMinutes() + ":" + cdate.getSeconds() + " - " + ALLAPOT + " - " + A.document.readyState + ": " + str;
    return;
}
document.getElementsByTagName("head")[0].innerHTML += '<style type="text/css">body{  	background: white;  }</style>';
document.title = "A KOTR�G�P";
var tabla = document.getElementById("production_table");
for (i = 0; i < tabla.rows.length; i++) {
    cell = tabla.rows[i].insertCell(0);
    cell.setAttribute("width", "115px");
    if (i == 0) {
        cell.innerHTML = '<b>�RME</b> <img onclick=pipa(\'auto\',2); title="Azon faluk bepip�l�sa, melyek tanyaszintje max, �s betelt." src="' + pic("auto") + '"><img onclick=pipa(\'all\',2); title="�sszes falu bepip�l�sa." src="' + pic("all") + '"><img onclick=pipa(\'none\',2); title="Kiszedi a pip�kat." src="' + pic("none") + '"><img onclick=pipa(\'clone\',2); title="Azok falukat pip�lja be, amik a BE oszlopn�l m�r be vannak." src="' + pic("clone") + '">';
        cell.style.backgroundColor = "#FF0";
    } else cell.innerHTML = '<input type="checkbox">';
    cell = tabla.rows[i].insertCell(0);
    cell.setAttribute("width", "70px");
    if (i == 0) {
        cell.innerHTML = '<b>KI</b> <img onclick=pipa(\'auto\',1); title="Azon faluk bepip�l�sa, melyek tanyaszintje max, �s betelt." src="' + pic("auto") + '"><img onclick=pipa(\'all\',1); title="�sszes falu bepip�l�sa." src="' + pic("all") + '"><img onclick=pipa(\'none\',1); title="Kiszedi a pip�kat." src="' + pic("none") + '">';
        cell.style.backgroundColor = "#AAF";
    } else cell.innerHTML = '<input type="checkbox">';
    cell = tabla.rows[i].insertCell(0);
    if (i == 0) {
        cell.innerHTML = '<b>BE</b> <img onclick=pipa(\'auto\',0); title="Azon faluk bepip�l�sa, melyek tanyaszintje max, �s betelt." src="' + pic("auto") + '"><img onclick=pipa(\'all\',0); title="�sszes falu bepip�l�sa." src="' + pic("all") + '"><img onclick=pipa(\'none\',0); title="Kiszedi a pip�kat." src="' + pic("none") + '"><img onclick=pipa(\'clone\',0); title="Azok falukat pip�lja be, amik az �RME oszlopn�l m�r be vannak." src="' + pic("clone") + '">';
        cell.style.backgroundColor = "#AAF";
    } else cell.innerHTML = '<input type="checkbox">';
    cell = tabla.rows[i].insertCell(0);
    cell.setAttribute("width", "250px");
    if (i == 0) {
        cell.innerHTML = "<b>Online</b>";
        cell.style.backgroundColor = "#AAF";
    } else cell.innerHTML = 'Ismeretlen';
}
function addNewRow() {
    try {
        var Fshort = document.getElementById("newrowarea").getElementsByTagName("input");
        var koord = Fshort[0].value;
        Fshort[0].value = "";
        if (koord.search(/[0-9]+(\|)[0-9]+/) == -1) throw "Nincs megadva koordin�ta";
        Fshort[1].value = Fshort[1].value.replace(/[^0-9]/g, "");
        Fshort[2].value = Fshort[2].value.replace(/[^0-9]/g, "");
        Fshort[3].value = Fshort[3].value.replace(/[^0-9]/g, "");
        addNewRow2(koord, Fshort[1].value + "," + Fshort[2].value + "," + Fshort[3].value);
    } catch (e) {
        alert("Hiba felvitelkor:\n" + e);
    }
}
function addNewRow2(koord, ertek) {
    var newTable = document.getElementById("production_table");
    var newRow = newTable.insertRow(-1);
    var cell = newRow.insertCell(0);
    cell.innerHTML = 'Ismeretlen';
    var cell = newRow.insertCell(1);
    cell.innerHTML = '<input type="checkbox">';
    var cell = newRow.insertCell(2);
    cell.innerHTML = '<input type="checkbox" disabled>';
    var cell = newRow.insertCell(3);
    cell.innerHTML = '<input type="checkbox" disabled>';
    var cell = newRow.insertCell(4);
    cell.innerHTML = koord;
    var cell = newRow.insertCell(5);
    cell.innerHTML = '0';
    var cell = newRow.insertCell(6);
    cell.innerHTML = ertek;
    var cell = newRow.insertCell(7);
    cell.innerHTML = '400000';
    var cell = newRow.insertCell(8);
    cell.innerHTML = '100/100';
    return;
}
function addMoreRow() {
    try {
        var Fshort = document.getElementById("newrowarea").getElementsByTagName("input");
        var koord = Fshort[0].value;
        Fshort[0].value = "";
        if (koord.search(/[0-9]+(\|)[0-9]+/) == -1) throw "Nincs megadva koordin�ta";
        Fshort[1].value = Fshort[1].value.replace(/[^0-9]/g, "");
        Fshort[2].value = Fshort[2].value.replace(/[^0-9]/g, "");
        Fshort[3].value = Fshort[3].value.replace(/[^0-9]/g, "");
        var koordik = koord.match(/[0-9]+(\|)[0-9]+/g);
        for (var i = 0; i < koordik.length; i++) {
            addNewRow2(koordik[i], Fshort[1].value + "," + Fshort[2].value + "," + Fshort[3].value);
        }
    } catch (e) {
        alert(e)
    }
}
function wopen(webpage) {
    A = window.open(webpage, "kotrogep");
    return;
}
function set_balance() { /*BE Auto: <20k n�p; KI Auto: szok�sos_full; �RME Diff: szok�sos_full, de nem KI*/
    BALANCE = !BALANCE;
    if (BALANCE) {
        tabla.rows[0].cells[0].innerHTML = "<b>Online/Updated</b>";
        tabla.rows[0].cells[1].innerHTML = '<b>BE</b> <img onclick=pipa(\'auto\',0); title="Azon faluk bepip�l�sa, melyek n�pess�gsz�ma 21500 alatti." src="' + pic("auto") + '"><img onclick=pipa(\'all\',0); title="�sszes falu bepip�l�sa." src="' + pic("all") + '"><img onclick=pipa(\'none\',0); title="Kiszedi a pip�kat." src="' + pic("none") + '">';
        tabla.rows[0].cells[1].setAttribute("width", "73px");
        tabla.rows[0].cells[3].setAttribute("width", "83px");
        document.getElementsByTagName("img")[0].setAttribute("src", "http://cncdani2.000webhostapp.com/!Files/pic/szem4/excavator2.gif");
    } else {
        tabla.rows[0].cells[0].innerHTML = "<b>Online</b>";
        tabla.rows[0].cells[1].innerHTML = '<b>BE</b> <img onclick=pipa("auto",0); title="Azon faluk bepip�l�sa, melyek tanyaszintje max, �s betelt." src="' + pic("auto") + '"><img onclick=pipa("all",0);	title="�sszes falu bepip�l�sa." src="' + pic("all") + '"><img onclick=pipa("none\',0); title="Kiszedi a pip�kat." src="' + pic("none") + '"><img onclick=pipa(\'clone\',0); title="Azok falukat pip�lja be, amik az �RME oszlopn�l m�r be vannak." src="' + pic("clone") + '">';
        tabla.rows[0].cells[1].setAttribute("width", "84px");
        tabla.rows[0].cells[3].setAttribute("width", "115px");
        document.getElementsByTagName("img")[0].setAttribute("src", "http://cncdani2.000webhostapp.com/!Files/pic/szem4/excavator.gif");
    }
    return;
}
function pic(tipus) { /*all, auto, clone, none*/
    return "http://cncdani2.000webhostapp.com/!Files/images/Script/kotro_" + tipus + ".png";
}
function pipa(tipus, oszlop) {
    try { /**/
        oszlop++;
        for (i = 1; i < tabla.rows.length; i++) {
            if (tabla.rows[i].style.display == "none") continue;
            if (tipus == "all") tabla.rows[i].cells[oszlop].getElementsByTagName("input")[0].checked = true;
            if (tipus == "none") tabla.rows[i].cells[oszlop].getElementsByTagName("input")[0].checked = false;
            tanya = tabla.rows[i].cells[8].innerHTML.match(/[0-9]+/g);
            if (tipus == "auto") {
                if (BALANCE && oszlop == 1) {
                    if (parseInt(tanya[0]) < 21000) {
                        tabla.rows[i].cells[oszlop].getElementsByTagName("input")[0].checked = true;
                    }
                } else {
                    if (parseInt(tanya[0]) > 23500) {
                        if (parseInt(tanya[1]) - parseInt(tanya[0]) <= 500) {
                            if (oszlop == 1 && tabla.rows[i].cells[2].getElementsByTagName("input")[0].checked == true) continue;
                            if (oszlop == 2 && tabla.rows[i].cells[1].getElementsByTagName("input")[0].checked == true) continue;
                            tabla.rows[i].cells[oszlop].getElementsByTagName("input")[0].checked = true;
                        }
                    }
                }
            }
            if (tipus == "clone") {
                if (oszlop == 1) {
                    if (tabla.rows[i].cells[3].getElementsByTagName("input")[0].checked == true) tabla.rows[i].cells[1].getElementsByTagName("input")[0].checked = true;
                }
                if (oszlop == 3) {
                    if (tabla.rows[i].cells[1].getElementsByTagName("input")[0].checked == true) tabla.rows[i].cells[3].getElementsByTagName("input")[0].checked = true;
                }
            }
        }
        return;
    } catch (e) {
        alert("Hiba pip�l�skor: \n" + e);
    }
}
function botriado(bool) { /*Egy link jelenik meg, mely ezt a fg-t TRUE-val h�vja meg, ekkor rekurzi� helyett a f�program �jraind�t�sa sz�ks�ges: A windowOpen;munka() h�v�s k�sleltet�ssel.*/
    if (!bool) {
        document.getElementsByTagName("h1")[0].innerHTML = '<a href="javascript:botriado(true);">---&gt; BOT V�DELEM AKT�V &lt;---</a>';
        document.getElementById("wavhang").src = "http://cncdani2.000webhostapp.com/!Files/SZEM3/Sounds/Bot.wav";
        document.getElementById("audio1").load();
        document.getElementById("audio1").play();
        if (document.getElementById("audio1").volume < 0.2) document.getElementById("audio1").volume = 0.9;
        alma = setTimeout("botriado(false)", 10000);
    } else {
        clearTimeout(alma);
        document.getElementsByTagName("h1")[0].innerHTML = 'A KOTR�G�P';
        ALLAPOT = 0;
        PM1 = 0;
        PM2 = 0;
        PM3 = 0;
        PM4 = false;
        A = window.open(document.location.href, "kotrogep");
        document.getElementById("audio1").pause();
        setTimeout("eloszto();", 2000);
    }
}
function nfrissit(sorsz, ures) {
    try {
        if (ures) extraido = new Array(0, 10, 0);
        else extraido = A.document.getElementById("content_value").getElementsByTagName("table")[0].rows[5].cells[1].innerHTML.match(/[0-9]+/g);
        if (extraido[1] != 0) {
            extraido[1] = (extraido[1] + "").replace(/^0*/g, "");
        }
        if (extraido[2] != 0) extraido[2] = (extraido[2] + "").replace(/^0*/g, "");
        var newdate = new Date();
        newdate.setHours(newdate.getHours() + (parseInt(extraido[0]) * 2));
        newdate.setMinutes(parseInt(newdate.getMinutes()) + (parseInt(extraido[1]) * 2) + 1);
        newdate.setSeconds(parseInt(newdate.getSeconds()) + (parseInt(extraido[2]) * 2));
        tabla.rows[sorsz].cells[0].innerHTML = newdate;
        if (!ures) A.document.getElementById("content_value").getElementsByTagName("input")[0].click();
    } catch (e) {
        db("nFriss�t hiba: " + e);
        ALLAPOT = 0;
    }
    ALLAPOT = 0;
    return;
}
function illeszt(X, Y) { /*Adott a weboldal, ahova be kell illeszteni. Adott hogy MIT. Feladat: mennyit, melyik FORM-ra �s OK*/
    if (SIMULATION > 10) {
        db("illeszt() - Szimul�ci� �ltali hibameg�llap�t�s - " + SIMULATION);
        SIMULATION = 0;
        ALLAPOT = 0;
        return;
    }
    try {
        var simulate = A.document.getElementById("content_value").getElementsByTagName("table")[1].rows[0].cells[1].getElementsByTagName("table")[0].innerHTML;
    } catch (e) {
        SIMULATION++;
        return;
    }
    SIMULATION = 0;
    try { /*Be�rt minimum nyers �rv�nyess�g�nek ellem�rz�se*/
        JAV = document.getElementById("fa_");
        JAV.value = parseInt(JAV.value.replace(/[^0-9]/g, ""), 10);
        if (JAV.value == "") JAV.value = "0";
        JAV = document.getElementById("agyag_");
        JAV.value = parseInt(JAV.value.replace(/[^0-9]/g, ""), 10);
        if (JAV.value == "") JAV.value = "0";
        JAV = document.getElementById("vas_");
        JAV.value = parseInt(JAV.value.replace(/[^0-9]/g, ""), 10);
        if (JAV.value == "") JAV.value = "0";
        JAV = document.getElementById("maxtav");
        JAV.value = parseInt(JAV.value.replace(/[^0-9]/g, ""), 10);
        if (JAV.value == "") JAV.value = "30";
        kereskedok = A.document.getElementById("content_value").getElementsByTagName("table")[1].rows[0].cells[1].getElementsByTagName("table")[0].rows[0].cells[0];
        kereskedok = parseInt(kereskedok.innerHTML.match(/[0-9]+/g)[0]) * 1000;
        if (kereskedok < 3000) {
            ALLAPOT = 3;
            PM4 = true;
            return;
        }
        Fa = parseInt(A.document.getElementById("wood").innerHTML);
        Agyag = parseInt(A.document.getElementById("stone").innerHTML);
        Vas = parseInt(A.document.getElementById("iron").innerHTML);
        Fa = Fa - parseInt(document.getElementById("fa_").value);
        Agyag = Agyag - parseInt(document.getElementById("agyag_").value);
        Vas = Vas - parseInt(document.getElementById("vas_").value);
        if (Fa < 0) Fa = 0;
        if (Agyag < 0) Agyag = 0;
        if (Vas < 0) Vas = 0;
        if ((Fa + Agyag + Vas) < 3000) {
            ALLAPOT = 3;
            PM4 = true;
            return;
        }
        oszto = 3;
        AVG = Math.round(kereskedok / 3);
        Vari = new Array(false, false, false);
        Be = new Array(AVG, AVG, AVG);
        var maradek = 0;
        do {
            if (maradek > 0) {
                for (i = 0; i < 3; i++) {
                    if (Vari[i] == false) Be[i] += Math.round(maradek / oszto);
                }
                maradek = 0;
            }
            if (Be[0] > Fa) {
                Vari[0] = true;
                maradek += Be[0] - Fa;
                Be[0] = Fa;
                oszto--;
            }
            if (Be[1] > Agyag) {
                Vari[1] = true;
                maradek += Be[1] - Agyag;
                Be[1] = Agyag;
                oszto--;
            }
            if (Be[2] > Vas) {
                Vari[2] = true;
                maradek += Be[2] - Vas;
                Be[2] = Vas;
                oszto--;
            }
        } while (maradek != 0);
        for (y = 0; y < Be.length; y++) {
            if (Be[y] == 0) Be[y] = 1;
        }
        A.document.forms["market"].wood.value = Be[0] - 1;
        A.document.forms["market"].stone.value = Be[1] - 1;
        A.document.forms["market"].iron.value = Be[2] - 1;
        A.document.forms["market"].x.value = X;
        A.document.forms["market"].y.value = Y;
        A.document.getElementById("delivery_target").getElementsByTagName("table")[0].rows[0].cells[1].getElementsByTagName("input")[0].click();
        ALLAPOT = 3;
        PM4 = false;
    } catch (e) {
        db("Illeszt�si hiba " + e);
        ALLAPOT = 0;
    }
}
function kuld(koord, TID) {
    try { /*Megkeresem a minE(rteket) �s minK(oordin�t�j�t) a BE (cells[1]) checked sorb�l koord t�vols�gokat a koord-hez k�pest.*/
        var minE = 999;
        var minK = "0";
        Tkoord = koord.match(/[0-9]+/g);
        for (i = 1; i < tabla.rows.length; i++) {
            if (tabla.rows[i].cells[1].getElementsByTagName("input")[0].checked == true) {
                AkoordS = tabla.rows[i].cells[4].innerText.match(/[0-9]+(\|)[0-9]+/g);
                Akoord = AkoordS[AkoordS.length - 1].match(/[0-9]+/g);
                tavolsag = Math.abs(Math.sqrt(Math.pow(Tkoord[0] - Akoord[0], 2) + Math.pow(Tkoord[1] - Akoord[1], 2)));
                if (tavolsag < minE) {
                    minE = tavolsag;
                    minK = Akoord;
                }
            }
        }
        if (minK == "0") return; /*Megnyitom a PM-be kapott ID-j� falut, majd megh�vom a beilleszt� elj�r�st a minK[0] �s [1] PM-el egy kis k�sleltet�ssel*/
        URL = document.location.href;
        URL = URL.split("village=")[0];
        URL += "village=" + TID + "&screen=market&mode=send";
        A = window.open(URL, "kotrogep");
        PM1 = minK[0];
        PM2 = minK[1];
        ALLAPOT = 2;
    } catch (e) {
        ALLAPOT = 0;
    }
    return;
}
function munka() {
    try {
        var CURRTIME = new Date();
        for (i = 1; i < tabla.rows.length; i++) {
            if (tabla.rows[i].cells[2].getElementsByTagName("input")[0].checked == true) { /*tabla.rows[i].cells[1].getElementsByTagName("input")[0].checked=false;*/
                ID = tabla.rows[i].cells[4].getElementsByTagName("span")[0].getAttribute("data-id").match(/[0-9]+/g)[0];
                koordS = tabla.rows[i].cells[4].innerText.match(/[0-9]+(\|)[0-9]+/g);
                koord = koordS[koordS.length - 1];
                if (tabla.rows[i].cells[0].innerHTML == "Ismeretlen") {
                    ALLAPOT = 1;
                    PM1 = koord;
                    PM2 = ID;
                    PM3 = i;
                    return;
                }
                online = new Date(tabla.rows[i].cells[0].innerHTML);
                if (online - CURRTIME < 0) {
                    ALLAPOT = 1;
                    PM1 = koord;
                    PM2 = ID;
                    PM3 = i;
                    return;
                }
            }
        }
        if (ALLAPOT == 0) ERME = true;
    } catch (e) {
        db("munka() - " + e);
        ALLAPOT = 0;
    }
    return;
}
function open_attek() {
    try {
        if (A.document.location.href != document.location.href) A.window.open(document.location.href, "kotrogep");
        ALLAPOT = 1;
        return;
    } catch (e) {
        db("�ttekint�s megnyit�sa - " + e);
    }
}
function open_academy() {
    try {
        PFA = A.document.getElementById("production_table");
        if (PFA.rows[0].cells.length > 5) {
            for (i = 0; i < PFA.rows.length; i++) {
                PFA.rows[i].deleteCell(9);
                PFA.rows[i].deleteCell(8);
                PFA.rows[i].deleteCell(7);
                PFA.rows[i].deleteCell(5);
                PFA.rows[i].deleteCell(0);
            }
        }
        ERME = false;
        ALLAPOT = 0;
        var table = A.document.getElementById("production_table");
        for (i = 1; i < tabla.rows.length; i++) {
            if (tabla.rows[i].cells[3].getElementsByTagName("input")[0].checked == true) {
                faluID = tabla.rows[i].cells[4].getElementsByTagName("span")[0].getAttribute("data-id").replace("label_", "");
                for (var j = 1; j < table.rows.length; j++) {
                    if (table.rows[j].cells[0].getElementsByTagName("span")[0].getAttribute("data-id").replace("label_", "") == faluID) {
                        M = table.rows[j].cells[2].childNodes;
                        fa = parseInt(M[0].innerHTML.replace(/[^0-9]+/g, ""));
                        agyag = parseInt(M[2].innerHTML.replace(/[^0-9]+/g, ""));
                        vas = parseInt(M[4].innerHTML.replace(/[^0-9]+/g, "")); /*db("�rme ver�s�nek vizsg�lata itt: "+faluID+" - "+table.rows[j].cells[0].innerText+". Nyersszint: "+fa+", "+agyag+", "+vas);*/
                        if ((fa > 28000) && (agyag > 30000) && (vas > 25000)) { /*db("Rendben van, itt verni kell");*/
                            ALLAPOT = 2;
                            ERME = true;
                            PM1 = i;
                            A.window.open(table.rows[j].cells[0].getElementsByTagName("a")[0].getAttribute("href").replace("screen=overview", "screen=snob"), "kotrogep");
                        }
                    }
                }
            }
        }
        return;
    } catch (e) {
        db("Akademy - " + e);
        A = window.open(document.location.href, "kotrogep");
    }
}
function erme_veres() {
    if (SIMULATION > 10) {
        db("erme_veres() - Szimul�ci� �ltal felder�tett hiba.");
        SIMULATION = 0;
        ALLAPOT = 0;
        return;
    }
    try {
        var simulate = A.document.getElementById("content_value").innerHTML;
    } catch (e) {
        SIMULATION++;
        return;
    }
    SIMULATION = 0;
    var VV = document.getElementById("production_table").rows[PM1].cells[3];
    if (A.document.readyState != "complete") {
        return;
    }
    try {
        ALLAPOT = 0;
        var vane = false;
        var a = A.document.getElementById("content_value").getElementsByTagName("table");
        if (A.document.getElementById("content_value").innerHTML.length > 3000) {
            vane = true;
            if (parseInt(A.document.getElementById("stone").textContent) > 30000 && parseInt(A.document.getElementById("wood").textContent) > 28000 && parseInt(A.document.getElementById("iron").textContent) > 25000) {
                if (A.$('input:submit').length>0) {
					A.$("input:submit")[0].click();
				}
				 else {/*a[a.length - 1].getElementsByTagName("a")[0].click();*/
					var b=A.$("a.btn"); b[b.length-1].click();
				 }
                if (VV.innerText != "")(elem = VV.getElementsByTagName("b")[0]).parentNode.removeChild(elem);
            } else {
                ALLAPOT = 0;
                return;
            }
            ALLAPOT = 2;
        }
        if (!vane) {
            if (VV.innerText == "") {
                newB = document.createElement("b");
                newB.innerHTML = "1";
                VV.appendChild(newB);
            } else VV.getElementsByTagName("b")[0].innerHTML = parseInt(VV.getElementsByTagName("b")[0].innerHTML) + 1;
            if (VV.innerText == "4") {
                VV.getElementsByTagName("input")[0].checked = false;
                (elem = VV.getElementsByTagName("b")[0]).parentNode.removeChild(elem);
                pmkoord = document.getElementById("production_table").rows[PM1].cells[4].innerHTML;
                document.getElementById("uzi").innerHTML += "<br>Egyik �rmever�sre jel�lt faluban (" + pmkoord + ") nem lehet �rm�t verni akad�mia hi�nya miatt, ez�rt a tov�bbiakban nem n�zem.";
                document.getElementById("wavhang").src = "http://cncdani2.000webhostapp.com/!Files/SZEM3/Sounds/SokNyers.wav";
                document.getElementById("audio1").load();
                document.getElementById("audio1").play();
            }
        } else {
            if (VV.innerText != "")(elem = VV.getElementsByTagName("b")[0]).parentNode.removeChild(elem);
        }
    } catch (e) {
        ALLAPOT = 0;
        db("�rmever�s - " + e);
    }
}
function balance_munka() {
    try {
        var CURRTIME = new Date();
        var vanebe = false;
        for (i = 1; i < tabla.rows.length; i++) { /*PM4=true ---> PM1=sor;megnyitja a piacot*/
            if (tabla.rows[i].cells[1].getElementsByTagName("input")[0].checked == true) {
                tabla.rows[i].cells[2].getElementsByTagName("input")[0].checked = false;
                vanebe = true;
                if (tabla.rows[i].cells[2].getElementsByTagName("input")[0].disabled) {
                    tabla.rows[i].cells[0].innerHTML = CURRTIME;
                    continue;
                }
                ID = tabla.rows[i].cells[4].getElementsByTagName("span")[0].getAttribute("data-id").match(/[0-9]+/g)[0];
                koordS = tabla.rows[i].cells[4].innerText.match(/[0-9]+(\|)[0-9]+/g);
                koord = koordS[koordS.length - 1];
                URL = document.location.href;
                URL = URL.split("village=")[0];
                URL += "village=" + ID + "&screen=market&mode=send";
                if (tabla.rows[i].cells[0].innerHTML == "Ismeretlen") {
                    ALLAPOT = 1;
                    PM1 = i;
                    PM4 = true;
                    wopen(URL);
                    return;
                }
                online = new Date(tabla.rows[i].cells[0].innerHTML);
                if (online - CURRTIME < 0) {
                    ALLAPOT = 1;
                    PM1 = i;
                    PM4 = true;
                    wopen(URL);
                    return;
                }
            }
        }
        if (!vanebe) {
            if (ALLAPOT == 0) ERME = true;
            return;
        }
        for (i = 1; i < tabla.rows.length; i++) { /*PM4=false esete ---> PM1=sor;PM2=koord;megnyitja a KI piac�t*/
            if (tabla.rows[i].cells[2].getElementsByTagName("input")[0].checked == true) {
                tabla.rows[i].cells[1].getElementsByTagName("input")[0].checked = false;
                ID = tabla.rows[i].cells[4].getElementsByTagName("span")[0].getAttribute("data-id").match(/[0-9]+/g)[0];
                koordS = tabla.rows[i].cells[4].innerText.match(/[0-9]+(\|)[0-9]+/g);
                koord = koordS[koordS.length - 1];
                URL = document.location.href;
                URL = URL.split("village=")[0];
                URL += "village=" + ID + "&screen=market&mode=send";
                if (tabla.rows[i].cells[0].innerHTML == "Ismeretlen") {
                    ALLAPOT = 1;
                    PM1 = i;
                    PM2 = koord;
                    PM4 = false;
                    wopen(URL);
                    return;
                }
                online = new Date(tabla.rows[i].cells[0].innerHTML);
                if (online - CURRTIME < 0) {
                    ALLAPOT = 1;
                    PM1 = i;
                    PM2 = koord;
                    PM4 = false;
                    wopen(URL);
                    return;
                }
            }
        }
        if (ALLAPOT == 0) ERME = true;
    } catch (e) {
        db("balance_munka() - " + e);
    }
}
function balance_adatszedo() {
    try {
        if (PM4) { /*BE friss�t�se*/
            dok = A.document.getElementById("inner-border").getElementsByTagName("table");
            dok = dok[dok.length - 1].rows;
            var vnyers = new Array(0, 0, 0);
            try{
				for (var i = 1; i < dok.length; i++) {
					var nyers = dok[i].cells[1].textContent.replace(/\./g, "");
					nyers = $.trim(nyers);
					nyers = nyers.replace(/  /g, " ");
					nyers = nyers.split(" ");
					var tipus = new Array(false, false, false);
					var t = 0;
					if (dok[i].cells[1].innerHTML.indexOf("wood") > 0) {
						tipus[0] = true;
						vnyers[0] += parseInt(nyers[t]);
						t++;
					}
					if (dok[i].cells[1].innerHTML.indexOf("stone") > 0) {
						tipus[1] = true;
						vnyers[1] += parseInt(nyers[t]);
						t++;
					}
					if (dok[i].cells[1].innerHTML.indexOf("iron") > 0) {
						tipus[2] = true;
						vnyers[2] += parseInt(nyers[t]);
						t++;
					} /*alert("Fa: "+vnyers[0]+"\nAgyag: "+vnyers[1]+"\nVas: "+vnyers[2]);*/
				}
			}catch(e){vnyers = [0,0,0];} /*Ha nincs keresked�mozg�s*/
            vnyers[0] += parseInt(A.document.getElementById("wood").textContent);
            vnyers[1] += parseInt(A.document.getElementById("stone").textContent);
            vnyers[2] += parseInt(A.document.getElementById("iron").textContent);
            document.getElementById("production_table").rows[PM1].cells[6].innerHTML = vnyers;
            var online = new Date();
            online.setMinutes(online.getMinutes() + 150); /*BALANCE: Felder�t�s ut�n ennyi perccel n�zi �jra.*/
            document.getElementById("production_table").rows[PM1].cells[0].innerHTML = online;
            ALLAPOT = 0;
        } else { /*2-es �llapotra l�phet. PM3=online++ ideje (0, ha keresni kell) PM1=KI-�rintett sor; (�r�kl�tt) PM2=BE-�rintett sor, PM4=k�ld�tt nyers*/
            PM3 = 0;
            PM4 = new Array(0, 0, 0); /*Be�rt minimum nyers �rv�nyess�g�nek ellem�rz�se*/
            JAV = document.getElementById("fa_");
            JAV.value = parseInt(JAV.value.replace(/[^0-9]/g, ""), 10);
            if (JAV.value == "") JAV.value = "0";
            JAV = document.getElementById("agyag_");
            JAV.value = parseInt(JAV.value.replace(/[^0-9]/g, ""), 10);
            if (JAV.value == "") JAV.value = "0";
            JAV = document.getElementById("vas_");
            JAV.value = parseInt(JAV.value.replace(/[^0-9]/g, ""), 10);
            if (JAV.value == "") JAV.value = "0";
            JAV = document.getElementById("maxtav");
            JAV.value = parseInt(JAV.value.replace(/[^0-9]/g, ""), 10);
            if (JAV.value == "") JAV.value = "30";
            kereskedok = A.document.getElementById("content_value").getElementsByTagName("table")[1].rows[0].cells[1].getElementsByTagName("table")[0].rows[0].cells[0];
            kereskedok = parseInt(kereskedok.innerHTML.match(/[0-9]+/g)[0]) * 1000;
            if (kereskedok < 8000) {
                ALLAPOT = 2;
                PM3 = 30;
                PM2 = 0;
                return;
            }
            Fa = parseInt(A.document.getElementById("wood").innerHTML);
            Agyag = parseInt(A.document.getElementById("stone").innerHTML);
            Vas = parseInt(A.document.getElementById("iron").innerHTML);
            Fa = Fa - parseInt(document.getElementById("fa_").value);
            Agyag = Agyag - parseInt(document.getElementById("agyag_").value);
            Vas = Vas - parseInt(document.getElementById("vas_").value);
            if (Fa < 0) Fa = 0;
            if (Agyag < 0) Agyag = 0;
            if (Vas < 0) Vas = 0;
            if ((Fa + Agyag + Vas) < 8000) {
                ALLAPOT = 2;
                PM3 = 45;
                PM2 = 0;
                return;
            }
            var elerheto = new Array(Fa, Agyag, Vas);
            for (var i = 0; i < 3; i++) elerheto[i] = parseInt(elerheto[i]); /*Rendezend� k�t t�mb felt�lt�se: koordi �s t�vols�g*/
            var Rkordik = new Array();
            var Rtavok = new Array();
            var Rsorok = new Array();
            for (var i = 1; i < tabla.rows.length; i++) {
                if (tabla.rows[i].cells[1].getElementsByTagName("input")[0].checked == true) {
                    koordS = tabla.rows[i].cells[4].innerText.match(/[0-9]+(\|)[0-9]+/g);
                    koord = koordS[koordS.length - 1];
                    Rkordik.push(koord);
                    Rsorok.push(i);
                    Akoord = koord.split("|");
                    Tkoord = PM2.split("|");
                    var tav = Math.abs(Math.sqrt(Math.pow(Tkoord[0] - Akoord[0], 2) + Math.pow(Tkoord[1] - Akoord[1], 2)));
                    Rtavok.push(tav);
                }
            } /*Rendez�s, �s k�zben sz�ks�gess�g-vizsg�lat*/
            /*db("--------------------------------");  		db("<b>"+PM2+"</b> Keresked�k: "+kereskedok+"; nyersanyag: "+elerheto);*/
            for (var C = 0; C < Rkordik.length; C++) {
                var min = C;
                for (var B = C; B < Rkordik.length; B++) { /*Legr�videbb megtal�l�sa -> ha j�, k�ld; am�gy k�vetkez� a sorba.*/
                    if (Rtavok[min] > Rtavok[B]) min = B;
                }
                if (Rtavok[min] > parseInt(document.getElementById("maxtav").value)) break;
                seged = Rtavok[C];
                Rtavok[C] = Rtavok[min];
                Rtavok[min] = seged;
                seged = Rkordik[C];
                Rkordik[C] = Rkordik[min];
                Rkordik[min] = seged;
                seged = Rsorok[C];
                Rsorok[C] = Rsorok[min];
                Rsorok[min] = seged; /*HOVA: Rkordik[C]. Vizsg�lat: Kell e neki?*/
                /*db("Vizsg�l: "+Rkordik[C]);*/
                var szukseges = document.getElementById("production_table").rows[Rsorok[C]].cells[6].innerHTML.split(",");
                for (var i = 0; i < 3; i++) szukseges[i] = parseInt(szukseges[i]);
                try {
                    var maxup = parseInt(document.getElementById("maxup").value.match(/[0-9]+/g)[0]);
                    document.getElementById("maxup").value = maxup;
                } catch (e) {
                    document.getElementById("maxup").value = "80";
                    var maxup = 80;
                }
                maxup = maxup / 100;
                var raktar = parseInt(document.getElementById("production_table").rows[Rsorok[C]].cells[7].innerHTML);
                for (var i = 0; i < 3; i++) {
                    szukseges[i] = Math.round(raktar * maxup) - szukseges[i];
                    if (szukseges[i] < 0) szukseges[i] = 0;
                }
                var szum = Math.round(szukseges[0] + szukseges[1] + szukseges[2]);
                if ((szum < 5000) || (szum < Math.round(kereskedok * 0.25))) { /*db("-> Els� buk�s, mert a sz�ks�g "+szukseges);*/
                    continue;
                } /*szukseges: ennyi nyers k�ne, de tudok e k�ldeni, �s mennyit?*/
                var segedT = new Array(true, true, true);
                var csere = 0;
                var maradek = 0;
                var maradek2 = 3;
                var kuldendo = new Array(Math.round(kereskedok / 3) - 1, Math.round(kereskedok / 3) - 1, Math.round(kereskedok / 3) - 1);
                for (var m = 0; m < 3; m++) {
                    maradek = 0;
                    for (var i = 0; i < 3; i++) {
                        if ((segedT[i]) && ((szukseges[i] < kuldendo[i]) || (elerheto[i] < kuldendo[i]))) {
                            segedT[i] = false;
                            maradek2--;
                            if (szukseges[i] < elerheto[i]) csere = szukseges[i];
                            else csere = elerheto[i];
                            maradek += kuldendo[i] - csere;
                            kuldendo[i] = csere;
                        }
                    }
                    if (maradek2 == 0) break;
                    for (var i = 0; i < 3; i++) {
                        if (segedT[i]) kuldendo[i] += Math.floor(maradek / maradek2);
                    }
                }
                var szum = kuldendo[0] + kuldendo[1] + kuldendo[2];
                if ((szum < 5000) || (szum < Math.round(kereskedok * 0.25))) { /*db("-> M�sodik buk�s, mert a k�ldend� az "+kuldendo);*/
                    continue;
                }
                A.document.forms["market"].wood.value = kuldendo[0];
                A.document.forms["market"].stone.value = kuldendo[1];
                A.document.forms["market"].iron.value = kuldendo[2];
                A.document.forms["market"].x.value = Rkordik[C].split("|")[0];
                A.document.forms["market"].y.value = Rkordik[C].split("|")[1];
				A.document.getElementById("delivery_target").getElementsByTagName("table")[0].rows[0].cells[1].getElementsByTagName("input")[0].click();
                /*A.document.forms["market"].getElementsByTagName("table")[0].rows[0].cells[1].getElementsByTagName("input")[2].click(); /*VAGY: 6. input*/
                PM2 = Rsorok[C];
                PM4 = kuldendo;
                ALLAPOT = 2;
                return;
            } /*db("Erre a falura nincs tov�bbi sz�ks�g");*/
            /*Online: +30perc, �s csak azt�n l�p ki (nincs hova k�ldenie)*/
            PM3 = 30;
            PM2 = 0;
            ALLAPOT = 2;
            return;
        }
        return;
    } catch (e) {
        db("balance_adatszedo() - " + e);
        ALLAPOT = 0;
    }
}
function balance_frissit() {
    try { /*PM1=KI �rintett sora, PM2=BE �rintett sora, PM3=idoplusz, PM4=nyers mennyis�g*/
        if (A.document.getElementById("error")) {
            document.getElementById("uzi").innerHTML += "<br><b>(!)</b>Hiba�zenet j�tt fel nyersk�ld�skor - " + PM2;
            PM3 = 30;
        }
        if (!A.document.getElementById("content_value")) {
            if (PROBA > 2) {
                ALLAPOT = 0;
                return;
            }
            PROBA++;
            return;
        }
        PROBA = 0;
        if (PM3 > 0) extraido = new Array(0, PM3, 0);
        else extraido = A.document.getElementById("content_value").getElementsByTagName("table")[0].rows[5].cells[1].innerHTML.match(/[0-9]+/g);
        if (extraido[1] != 0) {
            extraido[1] = (extraido[1] + "").replace(/^0*/g, "");
        }
        if (extraido[2] != 0) extraido[2] = (extraido[2] + "").replace(/^0*/g, "");
        var newdate = new Date();
        newdate.setHours(newdate.getHours() + (parseInt(extraido[0]) * 2));
        newdate.setMinutes(parseInt(newdate.getMinutes()) + (parseInt(extraido[1]) * 2) + 1);
        newdate.setSeconds(parseInt(newdate.getSeconds()) + (parseInt(extraido[2]) * 2));
        tabla.rows[PM1].cells[0].innerHTML = newdate;
        if (PM2 == 0) {
            ALLAPOT = 0;
            return;
        }
        var addnyers = tabla.rows[PM2].cells[6].innerHTML.split(",");
        for (var i = 0; i < 3; i++) {
            addnyers[i] = parseInt(addnyers[i]);
            addnyers[i] += PM4[i];
        }
        tabla.rows[PM2].cells[6].innerHTML = addnyers;
        if (PM3 == 0) A.document.getElementById("content_value").getElementsByTagName("input")[0].click();
    } catch (e) {
        db("Friss�t hiba: " + e);
        ALLAPOT = 0;
    }
    ALLAPOT = 0;
    return;
}
function eloszto() { /*Az eloszt� figyeli a bot v�delmet �s a lap bet�lt�d�s�t is. Ha minden rendben, megh�vja az akti�lis int�zkez� fg.-t a param�terekkel.*/
    try {
        AUTOUPDATE++;
        if (AUTOUPDATE > 1000) {
            AUTOUPDATE = 0;
            A = window.open(document.location.href, "kotrogep");
            throw "Update";
        }
        if (A.closed) {
            A = window.open(document.location.href, "kotrogep");
            ALLAPOT = 0;
            setTimeout("eloszto()", 500);
            return;
        }
        if (A.document.readyState != "complete") {
            setTimeout("eloszto()", 500);
            return;
        }
        if (A.document.getElementById('bot_check') || A.document.title == "Bot v�delem") {
            var date = new Date();
            document.getElementById("uzi").innerHTML += "<br>BOT RIAD�! " + date;
            botriado(false);
            return;
        }
        tabla = document.getElementById("production_table");
        if (!ERME) {
            if (BALANCE) {
                switch (ALLAPOT) {
                case 0:
                    balance_munka();
                    break; /*PM4 -> TRUE: a BE oszlop vizsg�lata sor�n friss�t�si sz�ks�glet l�pett fel; FALSE: KI-be meg�rkeztek a keresked�k; PM1->Melyik az �rintett sor*/
                case 1:
                    balance_adatszedo(PM1, PM4);
                    break; /* TRUE: friss�ti a falu nyersanyagszintj�t a piaci oldalr�l;online: +2 �ra;ALLAPOT=0; FALSE: K�ldend� hely&mennyis�g sz�m�t�sa, friss�t�se faluoldalt, illeszt�se, OK�z;PM2=true ha nem lehet k�ldeni, false ha lehet.*/
                case 2:
                    balance_frissit(PM1, PM2);
                    break; /*PM1. sor Online adat�nak friss�t�se. PM2=true eset�n 20p-et adni r�, ellenben vizsg�lni*/
                default:
                    ALLAPOT = 0;
                }
            } else {
                switch (ALLAPOT) {
                case 0:
                    munka();
                    break; /*megn�zi van e aktu�lis munka, azaz KI-hez online keresked�k vannak e?*/
                case 1:
                    kuld(PM1, PM2);
                    break; /*BE: KI koord,id-je. megkeresi az els� Online KI-hez a legk�zelebbi BE falut, �s megnyitja a KI piac�t*/
                case 2:
                    illeszt(PM1, PM2);
                    break; /*BE: BE koord.-ja (x,y). Kisz�molja mennyi nyersanyagot tud elk�ldeni, amit be�r a piacra �s k�ld.*/
                case 3:
                    nfrissit(PM3, PM4);
                    break; /*be: KI sora a dok.-ban. A dokumentum Online sor�t friss�ti */
                default:
                    ALLAPOT = 0;
                }
            }
        } else {
            switch (ALLAPOT) {
            case 0:
                open_attek();
                break; /*�ttekint�s megnyit�sa*/
            case 1:
                open_academy();
                break; /*Vizsg�lat, hol lehet �rm�t verni a pip�lt falukn�l �s megnyitja annak akad�mi�j�t*/
            case 2:
                erme_veres();
                break; /*�rm�t ver, ha van r� link (am�g el nem fogy a nyersanyag) --> ALLAPOT=0;ERME=false;*/
            default:
                ALLAPOT = 0;
                ERME = false;
            }
        }
    } catch (e) {
        try {
            db("eloszto -- " + e);
            A = window.open(document.location.href, "kotrogep");
        } catch (e) {}
    }
    rand = (Math.floor(Math.random() * 250) + 500);
    setTimeout("eloszto()", rand);
    return;
}
var ALLAPOT = 0;
var PM1 = 0;
var PM2 = 0;
var PM3 = 0;
var PM4 = false;
var ERME = false;
var AUTOUPDATE = 0;
var BALANCE = false;
var PROBA = 0;
var SIMULATION = 0;
var A = window.open(document.location.href, "kotrogep");
eloszto();
$("#production_table tr:not(:first-child) td:first-child").dblclick(function () {
    this.innerHTML = "Ismeretlen";
});
void(0);