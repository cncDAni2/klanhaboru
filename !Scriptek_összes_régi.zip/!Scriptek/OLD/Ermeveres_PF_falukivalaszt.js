javascript:
var table=document.getElementById("coin_overview_table").rows;
var lista=prompt("Melyek azok a faluk?");
lista=lista.match(/[0-9]+(\|)[0-9]+/g);
var aktfalu; var kelle;
try{
for (var i=2;i<table.length-1;i++){
	aktfalu=table[i].cells[0].textContent.match(/[0-9]+(\|)[0-9]+/g); aktfalu=aktfalu[aktfalu.length-1];
	kelle=false;
	for (var j=0;j<lista.length;j++){
		if (lista[j]==aktfalu) {kelle=true; break;}
	}
	if (!kelle){
		try{table[i].cells[3].getElementsByTagName("select")[0].value=0;}catch(E){}
	}
}}catch(e){alert(e)}
void(0);