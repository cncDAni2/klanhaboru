javascript:
try{
	function ugras(sorsz){
		try{
			var U=0; var sor=document.getElementById(sorsz+"_falu"+U).innerHTML;
			var talal=false; patt=/O/g;
			while(document.getElementById(sorsz+"_falu"+U) && !talal){
				var sor=document.getElementById(sorsz+"_falu"+U).innerHTML;
				if (patt.test(sor)) {
					talal=true;
					sor=sor.replace("O",""); document.getElementById(sorsz+"_falu"+U).innerHTML=sor;
					if (document.getElementById(sorsz+"_falu"+(U+1))) U++; 
						else {
							U=0;
							document.getElementById("naplo").innerHTML+="<tr><td>"+Date()+"</td><td>Auto-farm (<b>"+sorsz+".</b>): K�rbe�rt, �s el�lr�l kezdi munk�j�t</td></tr>"; 
							window.location="http://cncdani2.freeiz.com/teszthang.wav";}
					sor=document.getElementById(sorsz+"_falu"+(U)).innerHTML;
					sor=sor.replace(/<td><\/td>/g,"<td>O</td>");document.getElementById(sorsz+"_falu"+(U)).innerHTML=sor;
				}else U++;
			} if (!talal) throw "Nem tal�ltam meg, mit fosztasz jelenleg.";
		} catch(err) {alert("Hiba l�pett fel:\n"+err);}
		void(0);
	}
	var talal=false; T=1;
	while (!talal && T<11){
		if (document.getElementById(T).innerHTML=="") talal=true; else T++;
	}if (!talal) throw "Nincs t�bb szabad hely!";
	
	var KL=new Array(100,200);
	var b=new Array();
	b[0] = new Array(399,601); 
	b[1] = new Array(399,601);
	var faluazonT=document.location.href.match(/village=[0-9]+/g);
	faluazon=faluazonT[0].replace("village=","");
	
	document.getElementById(T).innerHTML="Faluazonosito: "+faluazon;
	document.getElementById(T).innerHTML+='<table cellpadding="2px" class="vis"><tbody id="'+T+'_T"><tr id="'+T+'_falu0"><td>O</td><td>'+b[0][0]+'|'+b[0][1]+'</td><td>'+KL[0]+'</td><td>Nincs</td><td>Nincs</td></tr></tbody></table>';
	for (i=1;i<KL.length;i++){
		document.getElementById(T+"_T").innerHTML+='<tr id="'+T+'_falu'+i+'"><td></td><td>'+b[i][0]+'|'+b[i][1]+'</td><td>'+KL[i]+'</td><td>Nincs</td><td>Nincs</td></tr>';
	}
	document.getElementById(T).innerHTML+='<a href="javascript: ugras('+T+');">Ugr�s a k�vetkez� farmra</a><br><b>Auto-farm '+T+'.</b>';
	document.getElementById('kieg').innerHTML+='<tr><td>Farmol� Script '+T+'</td><td><a href=\'javascript: stop("Farm'+T+'");\'>Le�ll�t�s</a></td></tr>';
	document.getElementById("naplo").innerHTML+="<tr><td>"+Date()+"</td><td><b>�j kieg�sz�t�</b> �rz�kelve: Auto-farm ("+T+".)</td></tr>";
} catch(err) { alert("Hiba megnyit�skor:\n"+err); void(0); }

function open_window(ID){ 
	try{
		
		var urll=WEBPAGE;
		urll+="&screen=place";
		if (SITTER!="") urll+=SITTER;
		var faluazonT=document.getElementById(ID).innerHTML.match(/Faluazonosito: [0-9]+/g);
		faluazon=faluazonT[0].replace("Faluazonosito: ","");
		urll=urll.replace(/(village=)[0-9]+/g,("village="+faluazon));
		aktualis=window.open(urll,ID);
		return aktualis;
	} catch(e) {document.getElementById("naplo").innerHTML+='<tr><td>'+Date()+'</td><td>Farmolo('+ID+') - <b>Hiba</b> lapmegnyit�skor. <a href="javascript:alert(\'Hiba l�pett fel a munkalap megnyit�sakor.\\nIsmeretlen probl�ma.\\nA script folytat�dik tov�bb...\');">R�szletez�s</a></td></tr>';}
}
function fill_place(ID,lapref,egyseg,kem){
	try{
		var talal=false; patt=/O/g; var FP=0;
			while(document.getElementById(ID+"_falu"+FP) && !talal){
				var sor=document.getElementById(ID+"_falu"+FP).innerHTML;
				if (patt.test(sor)) {
					talal=true;
					elemek=sor.split("</td><td>");
					var falu=elemek[1].split("|");
					var KL=elemek[2];
				}else FP++;
			} if (!talal) throw "Nem tal�ltam meg, mit fosztasz jelenleg.";
		lapref.document.forms["units"].x.value=falu[0];
		lapref.document.forms["units"].y.value=falu[1];
		lapref.document.getElementById("unit_input_"+egyseg).setAttribute("value", KL);
		lapref.document.forms["units"].spy.value=kem;
		lapref.document.forms["units"].attack.click();
	} catch(e) { document.getElementById("naplo").innerHTML+="<tr><td>"+Date()+"</td><td>Farmolo("+ID+') - <b>Hiba</b> kit�lt�skor. <a href="javascript:alert(\'Hiba t�rt�nt az adatok be�r�sakor a gy�lekez�helyen.\\nOkozhatta a lap hirtelen bez�r�sa, tartalomcser�je (pl. be�rt egy t�mad�s), vagy be nem t�lt�d�se a megadott ideig.\\nA script folytat�dik tov�bb...\');">R�szletez�s</a></td></tr>';}
}
function check_result(ID,lapref){
	try{		
		var teszt=lapref.document.getElementById("content_value").innerHTML;
		var patt=/Gy�lekez�hely/g;
		if (!(patt.test(teszt))) {
			ugras(ID);
			lapref.document.forms[0].submit.click();
		} else if (lapref.document.getElementById("error")) {
			hiba=lapref.document.getElementById("error").innerHTML;
			patt1=/A t�mad� seregnek/g; patt2=/csak akkor t�madhat�/g;
			X=lapref.document.getElementById("inputx").value;
			Y=lapref.document.getElementById("inputy").value;
			if (patt1.test(hiba)) { window.location="http://cncdani2.freeiz.com/hang/Falukihagy.wav"; document.getElementById("naplo").innerHTML+="<tr><td>"+Date()+"</td><td>Farmolo("+ID+") - Nem �red el a fake limitet a "+X+"|"+Y+" falu megt�mad�sakor! Falu kihagyva...</td></tr>"; ugras(ID);}
			if (patt1.test(hiba)) { window.location="http://cncdani2.freeiz.com/hang/Falukihagy.wav"; document.getElementById("naplo").innerHTML+="<tr><td>"+Date()+"</td><td>Farmolo("+ID+") - Nem t�madhatod t�bb� ezt a falut a 20:1 ar�ny t�ll�p�se miatt: "+X+"|"+Y+"! Falu kihagyva...</td></tr>"; ugras(ID);}
		}
	} catch (e) {document.getElementById("naplo").innerHTML+="<tr><td>"+Date()+"</td><td>Farmolo("+ID+') - <b>Hiba</b> ellen�rz�skor. <a href="javascript:alert(\'Hiba l�pett fel a gy�l. hely reakci�j�nak ellen�rz�sekor, miut�n kit�lt�ttem azt.\\nOkozhatta a lap hirtelen bez�r�sa, vagy be nem t�lt�d�se a megadott ideig.\\nA script folytat�dik tov�bb...\');">R�szletez�s</a></td></tr>';}
}
try{
switch (T){
	case 1: function munka1(){ if (window["lap1"]==undefined || !isbot(lap1)) {var ido = (Math.floor(Math.random()*61)+30)*300; lap1=open_window(1); setTimeout("fill_place(1,lap1,'sword',1)",2000); setTimeout("check_result(1,lap1)",4000);} i1=setTimeout("munka1()",ido);} munka1(); break;
	case 2: function munka2(){ if (window["lap2"]==undefined || !isbot(lap2)) {var ido = (Math.floor(Math.random()*61)+30)*300; lap2=open_window(2); setTimeout("fill_place(2,lap2,'sword',1)",2000); setTimeout("check_result(2,lap2)",4000);} i2=setTimeout("munka2()",ido);} munka2(); break;
	case 3: function munka3(){ if (window["lap3"]==undefined || !isbot(lap3)) {var ido = (Math.floor(Math.random()*61)+30)*300; lap3=open_window(3); setTimeout("fill_place(3,lap3,'sword',1)",2000); setTimeout("check_result(3,lap3)",4000);} i3=setTimeout("munka3()",ido);} munka3(); break;
	case 4: function munka4(){ if (window["lap4"]==undefined || !isbot(lap4)) {var ido = (Math.floor(Math.random()*61)+30)*300; lap4=open_window(4); setTimeout("fill_place(4,lap4,'sword',1)",2000); setTimeout("check_result(4,lap4)",4000);} i4=setTimeout("munka4()",ido);} munka4(); break;
	case 5: function munka5(){ if (window["lap5"]==undefined || !isbot(lap5)) {var ido = (Math.floor(Math.random()*61)+30)*300; lap5=open_window(5); setTimeout("fill_place(5,lap5,'sword',1)",2000); setTimeout("check_result(5,lap5)",4000);} i5=setTimeout("munka5()",ido);} munka5(); break;
	case 6: function munka6(){ if (window["lap6"]==undefined || !isbot(lap6)) {var ido = (Math.floor(Math.random()*61)+30)*300; lap6=open_window(6); setTimeout("fill_place(6,lap6,'sword',1)",2000); setTimeout("check_result(6,lap6)",4000);} i6=setTimeout("munka6()",ido);} munka6(); break;
	case 7: function munka7(){ if (window["lap7"]==undefined || !isbot(lap7)) {var ido = (Math.floor(Math.random()*61)+30)*300; lap7=open_window(7); setTimeout("fill_place(7,lap7,'sword',1)",2000); setTimeout("check_result(7,lap7)",4000);} i7=setTimeout("munka7()",ido);} munka7(); break;
	case 8: function munka8(){ if (window["lap8"]==undefined || !isbot(lap8)) {var ido = (Math.floor(Math.random()*61)+30)*300; lap8=open_window(8); setTimeout("fill_place(8,lap8,'sword',1)",2000); setTimeout("check_result(8,lap8)",4000);} i8=setTimeout("munka8()",ido);} munka8(); break;
	case 9: function munka9(){ if (window["lap9"]==undefined || !isbot(lap9)) {var ido = (Math.floor(Math.random()*61)+30)*300; lap9=open_window(9); setTimeout("fill_place(9,lap9,'sword',1)",2000); setTimeout("check_result(9,lap9)",4000);} i9=setTimeout("munka9()",ido);} munka9(); break;
	case 10: function munka10(){ if (window["lap10"]==undefined || !isbot(lap10)) {var ido = (Math.floor(Math.random()*61)+30)*300; lap10=open_window(10); setTimeout("fill_place(10,lap10,'sword',1)",2000); setTimeout("check_result(10,lap10)",4000);} i10=setTimeout("munka10()",ido);} munka10(); break;
	default: throw "Nem tal�lok helyet a cell�k k�zt.";
}}catch(err) { document.getElementById("naplo").innerHTML+="<tr><td>"+Date()+"</td><td>V�gzetes hiba l�pett fel ind�t�skor: "+err+"</td></tr>";}
void(0);