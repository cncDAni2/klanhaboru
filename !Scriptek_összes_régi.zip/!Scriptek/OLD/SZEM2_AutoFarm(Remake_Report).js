javascript:
	function ugras(sorsz){
		try{
			var talal=false; var sor=0; 
			while (!talal && document.getElementById(sorsz+"_T").rows[sor]){
			if (document.getElementById(sorsz+"_T").rows[sor].cells[0].innerHTML=="O") talal=true; else sor++;
			}
			document.getElementById(sorsz+"_T").rows[sor].cells[0].innerHTML="";
			 if (document.getElementById(sorsz+"_T").rows[(sor+1)]!=undefined)
				 document.getElementById(sorsz+"_T").rows[(sor+1)].cells[0].innerHTML="O";
			else {document.getElementById(sorsz+"_T").rows[0].cells[0].innerHTML="O";
				naplo("Farmolo Script "+sorsz+": K�rbe�rt, �s el�lr�l kezdi a munk�j�t.");
			}
		} catch(err) {}
		void(0);
	}
	var talal=false; T=1;
	while (!talal && T<11){
		if (document.getElementById(T).innerHTML=="") talal=true; else T++;
	}if (!talal) throw "Nincs t�bb szabad hely!";
try{
	var b=new Array();
	b[0] = new Array(398,606); 
	b[1] = new Array(399,606);
	b[2] = new Array(398,607);
	var KL=new Array(100,200,300);
	var faluazonT=document.location.href.match(/village=[0-9]+/g);
	faluazon=faluazonT[0].replace("village=","");	
	document.getElementById(T).innerHTML="Faluazonosito: "+faluazon;
	document.getElementById(T).innerHTML+='<table cellpadding="2px" class="vis"><tbody id="'+T+'_T"><tr><td>O</td><td>'+b[0][0]+'|'+b[0][1]+'</td><td>'+KL[0]+'</td><td>Nincs</td><td>Nincs</td></tr></tbody></table>';
	for (i=1;i<KL.length;i++){
		document.getElementById(T+"_T").innerHTML+='<tr><td></td><td>'+b[i][0]+'|'+b[i][1]+'</td><td>'+KL[i]+'</td><td>Nincs</td><td>Nincs</td></tr>';
	}
	document.getElementById(T).innerHTML+='<a href="javascript: ugras('+T+');">Ugr�s a k�vetkez� farmra</a><br><b>Auto-farm '+T+'.</b>';
	document.getElementById('kieg').innerHTML+='<tr><td>Farmol� Script '+T+'</td><td><a href=\'javascript: stop("Farm'+T+'");\'>Le�ll�t�s</a></td></tr>';
	document.getElementById("naplo").innerHTML+="<tr><td>"+Date()+"</td><td>"+kep("kieg")+"<b>�j kieg�sz�t�</b> �rz�kelve: Farmol� Script "+T+"</td></tr>";
} catch(err) { alert("Hiba megnyit�skor:\n"+err); void(0); exit(); }

function open_window(ID){ 
	try{		
		var urll=WEBPAGE;
		urll+="&screen=place";
		if (SITTER!="") urll+=SITTER;
		var faluazonT=document.getElementById(ID).innerHTML.match(/Faluazonosito: [0-9]+/g);
		faluazon=faluazonT[0].replace("Faluazonosito: ","");
		urll=urll.replace(/(village=)[0-9]+/g,("village="+faluazon));
		aktualis=window.open(urll,ID);
		return aktualis;
	} catch(e) { naplo("Farmolo "+ID+": Hiba lapmegnyit�skor!");}
}
function fill_place(ID,lapref,egyseg,kem){
	try{
		var talal=false; var i=0;
		while (!talal && document.getElementById(ID+"_T").rows[i]){
			x=document.getElementById(ID+"_T").rows[i];
			naplo(x.cells[0].innerHTML);
			if (x.cells[0].innerHTML=="O") {talal=true;} else i++;
		} if (!talal) {naplo(talal); throw "nemtalal"; }
		if (x.cells[3].innerHTML=="R") ugras(ID); else{
			lapref.document.forms["units"].x.value=x.cells[1].innerHTML.split("|")[0];
			lapref.document.forms["units"].y.value=x.cells[1].innerHTML.split("|")[1];
			KL=x.cells[2].innerHTML; KL=parseInt(KL); Enyers=x.cells[4].innerHTML;
			if (Enyers!="Nincs") { Enyers=parseInt(Enyers); switch (egyseg){
				case 'spear':	var KL_extra=Math.floor(Enyers/25); break;
				case 'sword':	var KL_extra=Math.floor(Enyers/15); break;
				case 'axe':		var KL_extra=Math.floor(Enyers/10); break;
				case 'archer':	var KL_extra=Math.floor(Enyers/10); break;
				case 'light':	var KL_extra=Math.floor(Enyers/80); break;
				case 'marcher':	var KL_extra=Math.floor(Enyers/50); break;
				case 'heavy':	var KL_extra=Math.floor(Enyers/50); break;
				default:	var KL_extra=0;}} else KL_extra=0;
			KL+=KL_extra;
			lapref.document.getElementById("unit_input_"+egyseg).value=KL;
			lapref.document.forms["units"].spy.value=kem;
			lapref.document.forms["units"].attack.click();
		}
		return i;
	} catch(e) {
		if (e=="nemtalal") {
			naplo(kep('warn')+"Farmolo Script "+ID+": Nem tal�ltam meg, mit fosztasz jelenleg. i="+i+". Sok hiba eset�n ind�tsa �jra.");
		} else naplo(e);
	}
}
function check_result(ID,lapref){
	try{
		var talal=false; var i=0;
		while (!talal && document.getElementById(ID+"_T").rows[i]){
			x=document.getElementById(ID+"_T").rows[i];
			if (x.cells[0].innerHTML=="O") talal=true; else i++;
		}
		var teszt=lapref.document.getElementById("content_value").innerHTML;
		var patt=/Gy�lekez�hely/g;
		if (!(patt.test(teszt))) {
			x.cells[4].innerHTML="Nincs";
			ugras(ID);
			lapref.document.forms[0].submit.click();
		} else if (lapref.document.getElementById("error")) {
			hiba=lapref.document.getElementById("error").innerHTML;
			patt1=/A t�mad� seregnek/g; patt2=/csak akkor t�madhat�/g;
			X=lapref.document.getElementById("inputx").value;
			Y=lapref.document.getElementById("inputy").value;
			if (patt1.test(hiba)) { window.location="http://cncdani2.freeiz.com/hang/Falukihagy.wav"; document.getElementById("naplo").innerHTML+="<tr><td>"+Date()+"</td><td>Farmolo("+ID+") - Nem �red el a fake limitet a "+X+"|"+Y+" falu megt�mad�sakor! Falu kihagyva...</td></tr>"; ugras(ID);}
			if (patt1.test(hiba)) { window.location="http://cncdani2.freeiz.com/hang/Falukihagy.wav"; document.getElementById("naplo").innerHTML+="<tr><td>"+Date()+"</td><td>Farmolo("+ID+") - Nem t�madhatod t�bb� ezt a falut a 20:1 ar�ny t�ll�p�se miatt: "+X+"|"+Y+"! Falu kihagyva...</td></tr>"; ugras(ID);}
		}
	} catch (e) {document.getElementById("naplo").innerHTML+="<tr><td>"+Date()+"</td><td>Farmolo("+ID+') - <b>Hiba</b> ellen�rz�skor. <a href="javascript:alert(\'Hiba l�pett fel a gy�l. hely reakci�j�nak ellen�rz�sekor, miut�n kit�lt�ttem azt.\\nOkozhatta a lap hirtelen bez�r�sa, vagy be nem t�lt�d�se a megadott ideig.\\nA script folytat�dik tov�bb...\');">R�szletez�s</a></td></tr>';}
}
try{
switch (T){
	case 1: function munka1(){ if (window["lap1"]==undefined || !isbot(lap1)) {var ido1 = (Math.floor(Math.random()*21)+10)*300; lap1=open_window(1); setTimeout("fill_place(1,lap1,'snob',5)",2000); setTimeout("check_result(1,lap1)",4000);} i1=setTimeout("munka1()",ido1);} munka1(); break;
	case 2: function munka2(){ if (window["lap2"]==undefined || !isbot(lap2)) {var ido2 = (Math.floor(Math.random()*21)+10)*300; lap2=open_window(2); setTimeout("fill_place(2,lap2,'knight',100)",2000); setTimeout("check_result(2,lap2)",4000);} i2=setTimeout("munka2()",ido2);} munka2(); break;
	case 3: function munka3(){ if (window["lap3"]==undefined || !isbot(lap3)) {var ido3 = (Math.floor(Math.random()*61)+30)*300; lap3=open_window(3); setTimeout("fill_place(3,lap3,'sword',1)",2000); setTimeout("check_result(3,lap3)",4000);} i3=setTimeout("munka3()",ido3);} munka3(); break;
	case 4: function munka4(){ if (window["lap4"]==undefined || !isbot(lap4)) {var ido4 = (Math.floor(Math.random()*61)+30)*300; lap4=open_window(4); setTimeout("fill_place(4,lap4,'sword',1)",2000); setTimeout("check_result(4,lap4)",4000);} i4=setTimeout("munka4()",ido4);} munka4(); break;
	case 5: function munka5(){ if (window["lap5"]==undefined || !isbot(lap5)) {var ido5 = (Math.floor(Math.random()*61)+30)*300; lap5=open_window(5); setTimeout("fill_place(5,lap5,'sword',1)",2000); setTimeout("check_result(5,lap5)",4000);} i5=setTimeout("munka5()",ido5);} munka5(); break;
	case 6: function munka6(){ if (window["lap6"]==undefined || !isbot(lap6)) {var ido6 = (Math.floor(Math.random()*61)+30)*300; lap6=open_window(6); setTimeout("fill_place(6,lap6,'sword',1)",2000); setTimeout("check_result(6,lap6)",4000);} i6=setTimeout("munka6()",ido6);} munka6(); break;
	case 7: function munka7(){ if (window["lap7"]==undefined || !isbot(lap7)) {var ido7 = (Math.floor(Math.random()*61)+30)*300; lap7=open_window(7); setTimeout("fill_place(7,lap7,'sword',1)",2000); setTimeout("check_result(7,lap7)",4000);} i7=setTimeout("munka7()",ido7);} munka7(); break;
	case 8: function munka8(){ if (window["lap8"]==undefined || !isbot(lap8)) {var ido8 = (Math.floor(Math.random()*61)+30)*300; lap8=open_window(8); setTimeout("fill_place(8,lap8,'sword',1)",2000); setTimeout("check_result(8,lap8)",4000);} i8=setTimeout("munka8()",ido8);} munka8(); break;
	case 9: function munka9(){ if (window["lap9"]==undefined || !isbot(lap9)) {var ido9 = (Math.floor(Math.random()*61)+30)*300; lap9=open_window(9); setTimeout("fill_place(9,lap9,'sword',1)",2000); setTimeout("check_result(9,lap9)",4000);} i9=setTimeout("munka9()",ido9);} munka9(); break;
	case 10: function munka10(){ if (window["lap10"]==undefined || !isbot(lap10)) {var ido10 = (Math.floor(Math.random()*61)+30)*300; lap10=open_window(10); setTimeout("fill_place(10,lap10,'sword',1)",2000); setTimeout("check_result(10,lap10)",4000);} i10=setTimeout10("munka10()",ido);} munka10(); break;
	default: throw "Nem tal�lok helyet a cell�k k�zt.";
}}catch(err) { document.getElementById("naplo").innerHTML+="<tr><td>"+Date()+"</td><td>V�gzetes hiba l�pett fel ind�t�skor: "+err+"</td></tr>"; void(0); exit();}
void(0);