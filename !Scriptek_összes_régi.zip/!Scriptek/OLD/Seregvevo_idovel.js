javascript:
var FENNTART=0; /*Ennyi tanyahelyet hagy meg*/
var MAXIDO=100; /*Maximum ennyi �r�ra teszi be a k�pz�st*/
var MAX_NYERS=new Array(0,0,0); /*Ennyi nyersanyagot hagy meg a faluban: fa,agyag,vas*/

/*Ennyi sereget vesz:*/
var LANDZSA=20000;
var KARDOS =0;
var BARDOS =0;
var IJASZ  =0;

var KEM=50;
var KL =0;
var IL =0;
var NL =1100;

var KOS =0;
var KATA=10;

/*Script k�vetkezik, nem m�dos�that�*/
try{
	MAXIDO*=3600;
	Ksereg=new Array(LANDZSA,KARDOS,BARDOS,IJASZ,KEM,KL,IL,NL,KOS,KATA); /*A c�l sereg*/
	sereg=new Array(0,0,0,0,0,0,0,0,0,0); /*Ennyi a max kik�pzend� sereg*/
	Vsereg=new Array(0,0,0,0,0,0,0,0,0,0); /*Ennyi egys�get tesz�nk be*/
	units=new Array("spear","sword","axe","archer","spy","light","marcher","heavy","ram","catapult");
	unitsL=new Array("","","","","","","","","",""); /*Translated units words*/
	nyers=new Array(parseInt(document.getElementById("wood").innerHTML)-MAX_NYERS[0],parseInt(document.getElementById("stone").innerHTML)-MAX_NYERS[1],parseInt(document.getElementById("iron").innerHTML)-MAX_NYERS[2]);
	tanya=parseInt(document.getElementById("pop_current").innerHTML);
	tanyamax=parseInt(document.getElementById("pop_max").innerHTML);
	tanyaszuk=new Array(1,1,1,1,2,4,5,6,5,8);
	X=document.getElementById("train_form").getElementsByTagName("table")[0].rows;
	Kidok=new Array(0,0,0,0,0,0,0,0,0,0);
	for (i=1;i<X.length-1;i++){
		for (j=0;j<units.length;j++) { if (X[i].cells[0].getElementsByTagName("img")[0].src.indexOf("/"+units[j])>0) {whatisit=units[j]; unitsL[j]=$.trim(X[i].cells[0].textContent); break;}}
		idok=X[i].cells[1].textContent.match(/[0-9]+/g);
		for (k=0;k<idok.length;k++){ if (idok[k]!="0") idok[k]=idok[k].replace(/^0/g,"");}
		masodp=parseInt(idok[idok.length-3])*3600+parseInt(idok[idok.length-2])*60+parseInt(idok[idok.length-1]);
		Kidok[j]=masodp;
		/*sereg=c�l-(Jelenleg megl�v� sereg + k�pz�s alatt �ll�)*/
		sereg[j]=Ksereg[j];
		jelenlegi=parseInt(X[i].cells[2].textContent.match(/[0-9]+/g)[1]);
		sereg[j]-=jelenlegi;
	}
	
	
	var foido=new Array(0,0,0); /*K�pz�si id�k mp-be*/
	if (document.getElementById("trainqueue_wrap_barracks")){
	XX=document.getElementById("trainqueue_wrap_barracks").getElementsByTagName("table")[0].rows;
	if (XX.length==2) cik=2; else cik=XX.length-1;
		for (i=1;i<cik;i++){
			for (k=0;k<=3;k++){if (XX[i].cells[0].textContent.indexOf(unitsL[k])>0) {sereg[k]-=parseInt(XX[i].cells[0].textContent.match(/[0-9]+/g));}}
			idok=XX[i].cells[1].textContent.match(/[0-9]+/g);
			for (k=0;k<3;k++){if (idok[k]!="0") idok[k]=idok[k].replace(/^0/g,"");}
			foido[0]+=parseInt(idok[0])*3600+parseInt(idok[1])*60+parseInt(idok[2]);
		}
	}
	if (XX=document.getElementById("trainqueue_wrap_stable")){
	XX=document.getElementById("trainqueue_wrap_stable").getElementsByTagName("table")[0].rows;
	if (XX.length==2) cik=2; else cik=XX.length-1;
		for (i=1;i<cik;i++){
			for (k=4;k<=7;k++){if (XX[i].cells[0].textContent.indexOf(unitsL[k])>0) {sereg[k]-=parseInt(XX[i].cells[0].textContent.match(/[0-9]+/g));}}
			idok=XX[i].cells[1].textContent.match(/[0-9]+/g);
			for (k=0;k<3;k++){if (idok[k]!="0") idok[k]=idok[k].replace(/^0/g,"");}
			foido[1]+=parseInt(idok[0])*3600+parseInt(idok[1])*60+parseInt(idok[2]);
		}
	} 
	if (XX=document.getElementById("trainqueue_wrap_garage")){
	XX=document.getElementById("trainqueue_wrap_garage").getElementsByTagName("table")[0].rows;
	if (XX.length==2) cik=2; else cik=XX.length-1;
		for (i=1;i<cik;i++){
			for (k=8;k<=9;k++){if (XX[i].cells[0].textContent.indexOf(unitsL[k])>0) {sereg[k]-=parseInt(XX[i].cells[0].textContent.match(/[0-9]+/g));}}
			idok=XX[i].cells[1].textContent.match(/[0-9]+/g);
			for (k=0;k<3;k++){if (idok[k]!="0") idok[k]=idok[k].replace(/^0/g,"");}
			foido[2]+=parseInt(idok[0])*3600+parseInt(idok[1])*60+parseInt(idok[2]);
		}
	}
	
	var eredmeny=""; /*Mi miatt �llunk meg*/
	while(true){
		VEGE=true;
		/*1.) foido �ll�t�sa -1re ahol m�r nincs t�bb k�peznival�*/
		if (sereg[0]<=0 && sereg[1]<=0 && sereg[2]<=0 && sereg[3]<=0) foido[0]=-1; else {VEGE=false; min=0;}
		if (sereg[4]<=0 && sereg[5]<=0 && sereg[6]<=0 && sereg[7]<=0) foido[1]=-1; else {VEGE=false; min=1;}
		if (sereg[8]<=0 && sereg[9]<=0) foido[2]=-1; else {VEGE=false;min=2;}
		if (VEGE) {eredmeny="A be�ll�tott sereg 100%-a le van gy�rtva"; break;}
		
		/*2.) foido minim hely�nek keres�se, ahol >0 �rt�k van*/
		VEGE=true; var endoftime=new Array(false,false,false);
		for (i=0;i<foido.length;i++){
			if (foido[i]>MAXIDO) {endoftime[i]=true; foido[i]==-1;}
			if (foido[i]!=-1 && foido[i]<foido[min]) min=i;
		}
		if (endoftime[0]==true) { sereg[0]=0;sereg[1]=0;sereg[2]=0;sereg[3]=0;}
		if (endoftime[1]==true) { sereg[4]=0;sereg[5]=0;sereg[6]=0;sereg[7]=0;}
		if (endoftime[2]==true) { sereg[8]=0;sereg[9]=0;}
		VEGE=true;
		for (i=0;i<3;i++){if (endoftime[i]==true || foido[i]==-1) VEGE=true; else {VEGE=false; break;}}
		if (VEGE) {eredmeny="Maxim�lis kik�pz�si id� el�rve"; break;}
		
		/*3.) Intervallum k�sz�t�se min alapj�n*/
		if (min==0) { also=0; felso=3;
		} else if (min==1){ also=4; felso=7;
		} else if (min==2){ also=8; felso=9;
		}
		
		/*4.) V�s�roland� egys�g pontos�t�sa, >>rnd<< meghat.: rnd also �s fels� k�z�tt; ha a sereg[rnd]>0 akkor megvan*/
		ezt=""; vegtelen=0;
		while (ezt==""){
			rnd=Math.floor((Math.random()*(felso-also+0.99))+also);
			if (sereg[rnd]>0) ezt=units[rnd];
		}
		
		/*5.) Ellen�rz�s hogy be lehet e tenni a sorba az egys�get (tanya, nyers megl�te)*/
		if (tanya+tanyaszuk[rnd]>tanyamax-FENNTART) {eredmeny="M�r nincs tov�bbi hely a tany�ban: "+tanya+"+"+tanyaszuk[rnd]; break;} else tanya+=tanyaszuk[rnd];
			/*5+1.) Nyers sz�ks�glet meg�llap�t�sa*/
			nyersszuk=new Array(0,0,0);
			for (i=1;i<X.length-1;i++){
				if (X[i].cells[0].innerHTML.indexOf(units[rnd])>0) {
					nyersszuk=new Array(parseInt($.trim(X[i].cells[1].textContent.match(/[0-9]+/g)[0])),
										parseInt($.trim(X[i].cells[1].textContent.match(/[0-9]+/g)[1])),
										parseInt($.trim(X[i].cells[1].textContent.match(/[0-9]+/g)[2]))); 
					break;
				}
			} if (nyersszuk[0]==0) throw "Nyers nem tal�lhat�";
			for (i=0;i<3;i++) {
				nyers[i]-=nyersszuk[i];
				if (nyers[i]<0) VEGE=true;
			}
			if (VEGE) {eredmeny="Elfogyott a nyersanyag. Sz�ks�ges: "+nyersszuk+", van: "+nyers; break;}
			
			
		/*6.) Betesz a sorba*/
		Vsereg[rnd]++; sereg[rnd]--;  foido[min]+=Kidok[rnd];
		/*alert("Betev�s "+also+"-"+felso+":\n"+units[rnd]+"\n Id�: "+Kidok[rnd]+"\n\nId�k:"+foido);*/
	}
	document.getElementById("train_form").innerHTML+="<br><b>Eredm�ny:</b><br>"+eredmeny;
	
	/*Kik�pz�sbe beilleszteni a v�geredm�nyt*/
	/*alert(Vsereg+"\n"+Vsereg[6]);*/
	for (i=0;i<Vsereg.length;i++){
		if (Vsereg[i]>0) document.getElementById(units[i]+"_0").value=Vsereg[i];
	}
	Z=document.getElementsByTagName("input");
	for (i=0;i<Z.length;i++) if (Z[i].getAttribute("type")=="submit") {Z[i].click(); break;}
		
}catch(e){alert(e);}
void(0);