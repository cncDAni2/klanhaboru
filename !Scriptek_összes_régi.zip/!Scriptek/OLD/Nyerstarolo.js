javascript: 
var kor2; 
if (kor2!=true){
	var z=0;
	var patt=/[0-9]+(\|)[0-9]+/g;
	for(k=0;k<document.links.length;k++){
		if (document.links[k].innerHTML.search(patt)>0) {URL=document.links[k].href; URL=URL.replace("&screen=overview","&screen=snob"); window.open(URL,z);z++;}
}
kor2=true;} else {
for (i=0;i<z;i++){
	if (parseInt(window[i].document.getElementById("pop_current_label"))>23000){
		
	}
}
}

void(0);