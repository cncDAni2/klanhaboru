javascript:
if (document.location.href.indexOf("mode=sim")==-1) {alert("Szimul�torba kell futtatni"); exit(0);}
if (document.getElementById("simulator_units_table").rows[1].cells.length==3) tech=2; else tech=3;

X=document.getElementById("content_value").getElementsByTagName("table")[1].rows[0].cells[1].getElementsByTagName("table")[0];
var Egyseg=new Array();
var Veszteseg=new Array();
for (i=2;i<X.rows[4].cells.length;i++){
	Egyseg[i-2]=parseInt(X.rows[4].cells[i].innerHTML);
	Veszteseg[i-2]=parseInt(X.rows[5].cells[i-1].innerHTML);
}
for (i=0;i<Egyseg.length;i++){
document.getElementById("simulator_units_table").rows[2+i].cells[tech].getElementsByTagName("input")[0].value=Egyseg[i]-Veszteseg[i];
}
gepek=document.getElementById("content_value").getElementsByTagName("table")[1].rows[0].cells[1].getElementsByTagName("table")[1].getElementsByTagName("b");
if (gepek[0].parentNode.innerHTML.indexOf("fal")==-1) document.forms["simulator"].def_building.value=gepek[1].innerHTML; 
	else document.forms["simulator"].def_wall.value=gepek[1].innerHTML;
	if (gepek.length>2) document.forms["simulator"].def_building.value=gepek[3].innerHTML;
void(0);