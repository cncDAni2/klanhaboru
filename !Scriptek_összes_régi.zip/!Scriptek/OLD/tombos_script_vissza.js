javascript:
function setCookie(name, value, expire) {
	document.cookie = name + "=" + escape(value)
	+ ((expire == null) ? "" : ("; expires=" + expire.toGMTString()));
}

function getCookie(Name){
	var search = Name + "=";
	if (document.cookie.length > 0) {
		offset = document.cookie.indexOf(search);
		if (offset != -1) {
			offset += search.length;
			end = document.cookie.indexOf(";", offset);
			if (end == -1) end = document.cookie.length;
			return unescape(document.cookie.substring(offset, end));
		}
	}
}
	VISITED = 0;
	VISITED = getCookie('visited');
	LEPES = getCookie('lepes');
	if (VISITED==null || VISITED=="") {
		alert('Jelenleg nincs script futtat�sa folyamatban');
	} else {
			if (LEPES==null || LEPES=="") {
				if (VISITED==0) alert("A script a legelej�n van, nem tudsz tov�bb el�re l�pni!"); 
					else {
					VISITED--;
					alert("Farmol� scriptet �rz�keltem. \n 1 l�p�st visszal�ptem");
					}
			} else {
				if (LEPES>1 && VISITED==0)	alert("Katapult scriptet �rz�keltem. \n Visszal�p�s NEM siker�lt: Ez az 1. t�mad�s erre az �p�lett�pusra");
				else {
					VISITED--;				
					alert("Katapult scriptet �rz�keltem. \n Visszal�p�s sikeres.");
				}
			}
			expDate = new Date();
			expDate.setTime(expDate.getTime() + (60*1000));
			setCookie('visited', VISITED, expDate);
	}
	alert(LEPES);
	alert(VISITED);
	void(0);