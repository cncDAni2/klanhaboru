javascript:
	function tamadf(lap){
		try{
		if (!isbot(lap) && !lap.closed){
		patt=/\([0-9]+\)/g;
		eddigi=getCookie("tamadf"); eddigi=parseInt(eddigi); var bejovo=0;
		var x=lap.document.getElementsByTagName("td");
		for (i=1;i<x.length;i++){
			if(x[i].getAttribute("class")=="box-item") {
				if (patt.test(x[i].innerHTML)) {
					var bejovo=x[i].innerHTML.replace("(","");
					bejovo=bejovo.replace(")","");
					if (eddigi<bejovo){
						setTimeout('window.location="http://cncdani2.freeiz.com/hang/Narrator_attack.wav";',200);
						setTimeout('window.location="http://cncdani2.freeiz.com/hang/riado.wav"',1500);
						document.getElementById("naplo").innerHTML+="<tr><td>"+Date()+'</td><td>T�mad�sfigyel�: <b>+'+(bejovo-eddigi)+' bej�v� t�mad�s!</b></td></tr>';
					}
				}
			}
		}
		if (eddigi>0 && bejovo==0) {setCookie("tamadf",0); document.getElementById("naplo").innerHTML+="<tr><td>"+Date()+'</td><td>T�mad�sfigyel�: <b>Nincs</b> t�bb bej�v� t�mad�s!</b></td></tr>';}
		setCookie("tamadf",bejovo);
		}} catch(err) {}
	}
	function open_incoming(){
		Flap=lapkeres();
		if (Flap==0){
			FFlap=window.open(document.location.href,"tamadF");
		} else {FFlap=window["lap"+Flap];}
		return FFlap;
	}
	function incomingF(){
		var ido = (Math.floor(Math.random()*61)+90)*100;
		lap_=open_incoming();
		setTimeout("tamadf(lap_)",1000*4);
		itamadf=setTimeout("incomingF()",ido);
	}
	setCookie("tamadf","0");
	document.getElementById('kieg').innerHTML+='<tr><td>T�mad�sfigyel�</td><td><a href=\'javascript: stop("tamadf");\'>Le�ll�t�s</a></td></tr>';
	document.getElementById("naplo").innerHTML+="<tr><td>"+Date()+"</td><td><b>�j kieg�sz�t�</b> �rz�kelve: T�mad�sfigyel�</td></tr>";
	incomingF();
void(0);