javascript:
var X=document.getElementById("production_table").rows;
var temp="";
var str="";
for (var i=1;i<X.length;i++){
	if (X[i].style.display!="none"){
		temp=X[i].cells[0].innerText.match(/[0-9]+(\|)[0-9]+/g);
		str+="[coord]"+temp[temp.length-1]+"[/coord]\n";
	}
}
alert(str);
void(0);