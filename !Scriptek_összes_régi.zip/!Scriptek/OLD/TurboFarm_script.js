javascript:
b = new Array();
b[0] = new Array(465,404); 
b[1] = new Array(462,404);
var KL=new Array(20,20); 

if (szam == undefined){
	var szam=KL.length;
	oldal = document.location.href;
	var RefArray=new Array();
	szam=parseInt(szam);

	for (var i=0;i<szam;i++){
		neve="web" + i;
		aktualis=window.open(oldal,neve);
		RefArray[i]=aktualis;
	}
} else {
		for (i=0;i<szam;i++){
			RefArray[i].document.forms[0].x.value=b[i][0];
			RefArray[i].document.forms[0].y.value=b[i][1];
			RefArray[i].document.forms[0].light.value=KL[i];
			RefArray[i].document.forms[0].spy.value=0; 
			RefArray[i].document.forms[0].support.click();
		} 
	
}
void(0);