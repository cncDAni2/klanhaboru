javascript:
var a=$("input:submit"); alert(a.length);
/*var b=$("select[name='factor']");
b[0].value=1;*/
/*a[0].click();*/
void 0;