javascript:
function setCookie(name, value, expire) {
	document.cookie = name + "=" + escape(value)
	+ ((expire == null) ? "" : ("; expires=" + expire.toGMTString()));
}

function getCookie(Name){
	var search = Name + "=";
	if (document.cookie.length > 0) {
		offset = document.cookie.indexOf(search);
		if (offset != -1) {
			offset += search.length;
			end = document.cookie.indexOf(";", offset);
			if (end == -1) end = document.cookie.length;
			return unescape(document.cookie.substring(offset, end));
		}
	}
}

function playSound(hang){
var play="http://cncdani2.freeiz.com/hang/"+hang+".wav";
document.getElementById("wavhang").src=play;
document.getElementById("audio1").load();
}

function kep(ez){
	if (ez=="szem") return '<img src="http://cncdani2.freeiz.com/SZEM.png" alt="" title="Megfigyel�s">';
	if (ez=="warn") return '<img src="http://cncdani2.freeiz.com/WARN.png" alt="" title="Kritikus hiba">';
	if (ez=="kieg") return '<img src="http://cncdani2.freeiz.com/KIEG.png" alt="" title="Kieg�sz�t�">';
	if (ez=="hang") return '<img src="http://cncdani2.freeiz.com/HANG.png" alt="" title="Hanggal jelzett esem�ny">';
	return "";}
function naplo(szoveg){
	document.getElementById("naplo").innerHTML+='<tr><td>'+Date()+'</td><td>'+szoveg+'</td></tr>';}

function isbot(reff){
try{
	if (reff!="undefined" && !reff.closed){
		eszlel=getCookie("warn");
		if (reff.document.getElementById('bot_check') || reff.document.title=="Bot v�delem"){
			var d=new Date(); var perc=d.getMinutes();
			if (eszlel==null || eszlel=="")	document.getElementById("naplo").innerHTML+="<tr><td>"+Date()+"</td><td>BOT-V�DELEM AKT�V!!!</td></tr>";
			if (eszlel!=perc) window.location="http://cncdani2.freeiz.com/hang/BOT_VEDELEM.wav";
			expDate = new Date();
			expDate.setTime(expDate.getTime() + (1000)*60*30);
			setCookie("warn",perc,expDate);
			return true;
		}
	}
	return false;
} catch(e) {return false;}
}

function lapkeres(){
	var talal=false; var l=1;
	while (!talal && l<11){
		if (document.getElementById(l).innerHTML!="") talal=true; else l++;
	}
	if (!talal) return 0; else return l;
}

function sztorles(nev,kod){
		torolK=document.getElementById("kieg").innerHTML;
		str1='<tr><td>'+nev+'<\/td><td><a href=\'javascript: stop("'+kod+'");\'>Le�ll�t�s</a></td></tr>';
		torolK=torolK.replace(str1,"");
		document.getElementById("kieg").innerHTML=torolK;
		document.getElementById("naplo").innerHTML+="<tr><td>"+Date()+"</td><td>"+nev+" script <b>le�ll�tva</b>.</td></tr>";
}

function stop(azon){
	try{
	patt=/Farm/g; 
	if (patt.test(azon)){
		fID=azon.replace("Farm","");fID=parseInt(fID);
		switch (fID) {case 1: clearTimeout(i1); break; case 2: clearTimeout(i2); break; case 3: clearTimeout(i3);
		break; case 4: clearTimeout(i4); break; case 5: clearTimeout(i5); break; case 6: clearTimeout(i6); break; case 7: clearTimeout(i7); 
		break; case 8: clearTimeout(i8); break; case 9: clearTimeout(i9); break; case 10: clearTimeout(i10); default: throw "nincs ilyen kieg�sz�t�"; }
		torolK=document.getElementById("kieg").innerHTML;
		str1='<tr><td>Farmol� Script '+fID+'<\/td><td><a href=\'javascript: stop("'+azon+'");\'>Le�ll�t�s</a></td></tr>';
		torolK=torolK.replace(str1,"");
		document.getElementById("kieg").innerHTML=torolK;
		document.getElementById(fID).innerHTML="";
		document.getElementById("naplo").innerHTML+="<tr><td>"+Date()+"</td><td>Farmol� Script "+fID+": <b>le�ll�tva</b>.</td></tr>";
		void(0);
	}
	if (azon=="forum"){
		clearTimeout(iforum);
		egyedi = undefined;
		sztorles("F�rum ID �r�","forum");
	}
	if (azon=="raktarf"){
		clearTimeout(iraktarf);
		sztorles("Rakt�rfigyel�","raktarf");
	}
	if (azon=="tamadf"){
		clearTimeout(itamadf);
		sztorles("T�mad�sfigyel�","tamadf");
	}
	if (azon=="VIJE"){
		clearTimeout(iVIJE);
		sztorles("VI Jelent�s Elemz�","VIJE");
	}
	void(0);
	}catch(e){alert("Hiba a "+azon+"script le�ll�t�sakor:\n"+e); void(0);}
}
try{
	patt=/game.php\?village=[0-9]+/g;
	if (!patt.test(document.location.href)) {alert("SZEM-et a kl�nh�bor�ba bejelentkezett fi�kb�l kell ind�tani.\n�gy v�lem, ez nem az.\n Ha m�gis, �rtes�tsd a script k�sz�t�j�t a hib�r�l."); exit(0);}
	patt=/&t=[0-9]+/g; if (patt.test(document.location.href)) {SITTER_s=document.location.href.match(patt); var SITTER=SITTER_s[0];} else SITTER="";
	WEBPAGE=document.location.href.substr(0,(document.location.href+"&").indexOf("&"));
	document.title = "SZEM2.0 info-k�zpont";
	document.getElementById("ds_body").innerHTML='<audio id="audio1" controls="controls" autoplay="autoplay" style="display:none"><source id="wavhang" src="" type="audio/wav"></audio>
<p align="center"><img src="http://cncdani2.freeiz.com/pic/Focim/Scriptgen_SZEM2.png"></p>
<br>
<br>
<p align="center">Itt jelenleg a SZEM keretscript fut. Befejez�shez z�rd be ezt a lapot.<br>
	<br>
</p>
<h1 align="center">Kieg�sz�t� kezel�</h1>
<table align="center" class="vis"><tbody id="kieg"><tr><th>Kieg�sz�t� neve</th><th>Le�ll�t�s</th></tr></tbody></table>

<h1 align="center">Napl�</h1>
<table cellpadding="3px" align="center" class="vis">
	<tbody id="naplo"><tr><th>D�tum</th><th>Esem�ny</th></tr>
	<tr><td>'+Date()+'</td><td>SZEM elindult, �s v�rja a kieg�sz�t�ket.</td></tr></tbody>
</table>

<h1 align="center"><i>Farmkezel� lista</i></h1>
<table align="center"><thead><tr><td colspan="5" align="center"><font size="1"><i>Itt list�z�dnak a kieg�sz�t�k�nt elind�tott auto-farm scriptek. List�z�sa oszlopok szerint a k�vetkez�: <br>
Melyiket t�madja �pp?|Mely faluk tartoznak hozz�?|R�k�ldend� egys�gsz�m|Jelent�s utols� t�pusa (G=z�ld, Y=S�rga, R=piros vagy k�k)|Jelent�sben �szlelt nyers<br>
Itt tudsz tov�bb� kiugrani egy farmot, �gy l�pve a sorban k�vetkez�re.<br>
A lap bez�r�sa minden adatot elvesz! Egyszerre maximum 10 auto-farm kieg�sz�thet� futtat�s�ra biztos�t lehet�s�get.</i></font></td></tr></thead>
<tr>
	<td ID="1"></td>
	<td ID="2"></td>
	<td ID="3"></td>
	<td ID="4"></td>
	<td ID="5"></td>
</tr><tr>
	<td ID="6"></td>
	<td ID="7"></td>
	<td ID="8"></td>
	<td ID="9"></td>
	<td ID="10"></td>
</tr></table>';
if (SITTER!="") document.getElementById("naplo").innerHTML+="<tr><td></td><td>Helyettes�tett fi�k �szlelve.</td></tr>";
playSound("Narrator_welcome");
} catch(err) {alert("Helyrehozhatatlan hiba t�rt�nt SZEM bet�lt�d�sekor :( \n Nyisd meg �J lapon az �sszes jelent�s lapot, majd pr�b�ld �jra.\n"+err);}

void(0);