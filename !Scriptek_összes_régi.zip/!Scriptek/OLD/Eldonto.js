//Barakk elemz�s.	
javascript:
	var d=document;	
	url=d.URL;
	patt=/[0-9]+/g;
	Temp=url.match(patt);
	ID=Temp[1];
	if(window.frames.length>0) d=window.main.document;
	var populacio=document.getElementById("pop_current_label");
	var populacio=populacio.innerHTML;
	var brktabla=document.getElementById("train_form");
	var brktablaInner = brktabla.innerHTML;
	egysegek=brktablaInner.match(/[0-9]+(\/)[0-9]+/g);
	hossz=egysegek.length;
	var ossz=0;
	for (j=0;j<hossz;j++){
	splitted=egysegek[j].split("/");
	egysegek[j]=splitted[1];
	egysegek[j]=parseInt(egysegek[j]);
	ossz=ossz+egysegek[j]; 
	}
	
	
	if (populacio>23900) tipus="Tel�tett"; else {
	if (ossz < 100) {
		if (populacio>8000) {
			tipus="UNKNOW";
		} else {
	if (ossz < 100) tipus="�RES";
	}} else {
	if (egysegek[2] / ossz  > 0.2) tipus="TAMADO"; else tipus="vedo";
	}}
	
	alert(tipus);	
	void(0);

//�ttekint�sbe tal�lhat� oldalak megnyit�sa �j ablakokba ablak+i c�mmel.

javascript:
	var d=document;	
	if(window.frames.length>0) d=window.main.document;
	url=d.URL;
	patt=/(hu)[0-9]+/g;
	Vilag=patt.exec(url);
	patt=/[0-9]+/g;
	Vilag=patt.exec(Vilag);
	if(url.indexOf('screen=overview')==-1) {
		alert('�ttekint�sbe pr�b�ld...');
		exit(0);
	}
		var tabla=document.getElementById("production_table");
		var tablaInner = tabla.innerHTML;
		szamok=tablaInner.match(/(<span id=\"label_)[0-9]+/g);
		hossz=szamok.length;
		patt=/[0-9]+/g;
		for (var i=0;i<hossz;i++){
			kivag=patt.exec(szamok[i]);
			szamok[i]=kivag;
			kivag=patt.exec(szamok[i]);
		}
		RefArray=new Array();
		for (i=0;i<hossz;i++){
			oldal="http://hu"+Vilag+".klanhaboru.hu/game.php?village="+szamok[i]+"&screen=barracks";
			RefArray[i]=window.open(oldal,"ablak"+i);
		}
	void (0);
	
	
//Egyes�tett
javascript:
function setCookie(name, value, expire) {
	document.cookie = name + "=" + escape(value)
	+ ((expire == null) ? "" : ("; expires=" + expire.toGMTString()));
}

function getCookie(Name){
	var search = Name + "=";
	if (document.cookie.length > 0) {
		offset = document.cookie.indexOf(search);
		if (offset != -1) {
			offset += search.length;
			end = document.cookie.indexOf(";", offset);
			if (end == -1) end = document.cookie.length;
			return unescape(document.cookie.substring(offset, end));
		}
	}
}
	var d=document;	
	if(window.frames.length>0) d=window.main.document;
	url=d.URL;
	patt=/(hu)[0-9]+/g;
	Vilag=patt.exec(url);
	patt=/[0-9]+/g;
	Vilag=patt.exec(Vilag);
	if(url.indexOf('screen=overview')==-1) {
		alert('�ttekint�sbe pr�b�ld...');
		exit(0);
	}	
	LEPES = getCookie('lepes');	
	if (LEPES==null || LEPES==""){
		d.getElementById("header_info").innerHTML="1. l�p�s lefutott.<br>Az �ttekint�sbe szerepl� faluk barakkjait nyitottam meg.<br>Futtasd a scriptet �jra a folytat�shoz...";
		var tabla=document.getElementById("production_table");
		var tablaInner = tabla.innerHTML;
		szamok=tablaInner.match(/(<span id=\"label_)[0-9]+/g);
		hossz=szamok.length;
		patt=/[0-9]+/g;
		for (var i=0;i<hossz;i++){
			kivag=patt.exec(szamok[i]);
			szamok[i]=kivag;
			kivag=patt.exec(szamok[i]);
		}
		var RefArray=new Array();
		for (i=0;i<hossz;i++){
			oldal="http://hu"+Vilag+".klanhaboru.hu/game.php?village="+szamok[i]+"&screen=barracks";
			RefArray[i]=window.open(oldal,"ablak"+i);
		}
		expDate = new Date();
		expDate.setTime(expDate.getTime() + 60*3600);
		setCookie('lepes',1,expDate);
	} else if (LEPES==1){
		for (i=0;i<hossz;i++){
			var populacio=RefArray[i].document.getElementById("pop_current_label");
			var populacio=populacio.innerHTML;
			var brktabla=RefArray[i].document.getElementById("train_form");
			var brktablaInner = brktabla.innerHTML;
			egysegek=brktablaInner.match(/[0-9]+(\/)[0-9]+/g);
			hossz2=egysegek.length;
			var ossz=0;
			for (j=0;j<hossz2;j++){
				splitted=egysegek[j].split("/");
				egysegek[j]=splitted[1];
				egysegek[j]=parseInt(egysegek[j]);
				ossz=ossz+egysegek[j]; 
			}
			
			if (populacio>23900) tipus="FULL"; else {
				if (ossz < 100) {
					if (populacio>8000) {
						tipus="UNKNOW";
					} else {
						tipus="EMPTY";
					}
				} else {
				if (egysegek[2] / ossz  > 0.2) tipus="ATTACKER"; else tipus="DEFENDER";
				}
			}
			expDate = new Date();
			expDate.setTime(expDate.getTime() + 60*3600);
			setCookie(i,tipus,expDate);
			setCookie("lepes",2,expDate);
		}
		var tamado=0; var vedo=0; var ures=0; var full=0; var ism=0;
		for (i=0;i<hossz;i++){
			miez=getCookie(i);
			switch (miez){
				case "FULL": full++; break;
				case "ATTACKER": tamado++; break;
				case "DEFENDER": vedo++; break;
				case "EMPTY": ures++; break;
				case "UNKNOW": ism++; break;
				default: alert("HIBA");
			}
		}
		szoveg="2. l�p�s lefutott.<br><b>�szlelt faluk: (" + hossz + ")</b><br>Tel�tett: "   + full	+ "<br>�res: " + ures + "<br>T�mad�: " + tamado + "<br>V�d�: " + vedo + "<br>Ismeretlen: " + ism + "<br>Futtasd a scriptet �jra a folytat�shoz...";
		d.getElementById("header_info").innerHTML=szoveg;
	} else if (LEPES==2) {
		for (i=0;i<hossz;i++){
			d.getElementById("header_info").innerHTML="3. l�p�s lefutott.<br>Az �ttekint�sbe szerepl� faluk piacait megnyitottam.<br>Futtasd a scriptet �jra a folytat�shoz...";
			oldal="http://hu"+Vilag+".klanhaboru.hu/game.php?village="+szamok[i]+"&screen=market";
			RefArray[i]=window.open(oldal,"ablak"+i);
		}
	}
	void(0);