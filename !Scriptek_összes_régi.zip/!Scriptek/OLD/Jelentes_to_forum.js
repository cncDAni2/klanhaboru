javascript:
function egyes(){
	var lks=document.forms[0].getElementsByTagName("a");
	var tomb=new Array(); var j=-1; var seged="";
	for (var i=0;i<lks.length;i++){
		if (lks[i].href.indexOf("public_report")>0) {
			try{j++;
			seged=lks[i].innerText.match(/[0-9]+(\|)[0-9]+/g);
			tomb[j]=seged[seged.length-1]+";"+lks[i].href.match(/\/[a-f0-9]+\?/g)[0].replace("/","").replace("?","");
			}catch(e){alert("Hibás szöveg, nincs benne koordi:\n"+lks[i].innerText); j--;}
		}
	}

	tomb2=new Array();/*Rendezett tömb: csak egyedi koordináták, jelentések kódja ,-vel elválasztva*/
	var hely=-1;
	for (var i=0;i<tomb.length;i++){
		hely=-1;
		for (var j=0;j<tomb2.length;j++){
			if (tomb2[j].split(";")[0]==tomb[i].split(";")[0]) {hely=j; break}
		}
		if (hely>-1){ /*van->sűrít*/
			tomb2[hely]=tomb2[hely]+";"+tomb[i].split(";")[1];
		} else { /*nincs->új*/
			tomb2.push(tomb[i]);
		}
	}
}
try{
if (typeof RefArray=='undefined') {
	egyes();
	var RefArray=new Array();
	var link=document.location.href.split("view_thread&")[0]+"=view_forum&"+document.location.href.match(/(forum_id=)[0-9]+/g)[0]+"&mode=new_thread&screen=forum";
	alert(tomb2.length);
	for (var i=0;i<tomb2.length;i++){
		RefArray[i]=window.open(link);
	}
} else {
	for (var i=0;i<RefArray.length;i++){
		RefArray[i].document.forms["new_thread"].subject.value=tomb2[i].split(";")[0];
		var str="";
		for (var j=1;j<tomb2[i].split(";").length;j++){
			str+="[report]"+tomb2[i].split(";")[j]+"[/report]\n";
		}
		RefArray[i].document.forms["new_thread"].message.value=str;
		RefArray[i].document.forms["new_thread"].send.click();
	}
}
}catch(e){alert(e);}

void(0);