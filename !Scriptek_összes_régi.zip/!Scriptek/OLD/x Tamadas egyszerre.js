javascript:
if (LEPES == undefined) {
	var d=document;
	if(window.frames.length>0) d=window.main.document;
	url=d.URL;

	patt=/(id=)[0-9]+/g;
	var ID=patt.exec(url);
	patt=/[0-9]+/g;
	var ID=patt.exec(ID);
	if (ID==null || ID=="") { 
		alert("Nem j� helyr�l ind�tod.\nKattints egy falura hogy bej�jj�n az inform�ci�s lap, �s ott pr�b�ld"); 
		exit(0); 
	}

	db=prompt("H�ny t�mad�st szeretn�l elk�ldeni a falura?","4");

	elotag=url.split("screen=");
	oldal = elotag[0] + "screen=place&target=" + ID;
	var RefArray=new Array();
	for (var i=0;i<db;i++){
		neve="web" + i;
		aktualis=window.open(oldal,neve);
		RefArray[i]=aktualis;
	}
	var LEPES=1;
	exit(0);
}

if (LEPES == 1){
	for (var i=0;i<db;i++) RefArray[i].document.forms[0].attack.click();
	var LEPES = 2;
	exit(0);
}
if (LEPES == 2){
	for (var i=0;i<db;i++) RefArray[i].document.forms[0].submit.click();
	var LEPES = 3;
	exit(0);
}
if (LEPES == 3){
	for (var i=0;i<db;i++) RefArray[i].close();
	LEPES = undefined;
}
void(0);