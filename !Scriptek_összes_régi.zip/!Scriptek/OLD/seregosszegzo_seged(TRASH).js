javascript:
function setCookie(name, value, expire) {
	document.cookie = name + "=" + escape(value)
	+ ((expire == null) ? "" : ("; expires=" + expire.toGMTString()));
}

function getCookie(Name){
	var search = Name + "=";
	if (document.cookie.length > 0) {
		offset = document.cookie.indexOf(search);
		if (offset != -1) {
			offset += search.length;
			end = document.cookie.indexOf(";", offset);
			if (end == -1) end = document.cookie.length;
			return unescape(document.cookie.substring(offset, end));
		}
	}
}

function ADD(egyseg,szam){
	hely=egysegek.indexOf(egyseg);
	if (hely==-1) {hely=egysegek.length; egysegek[hely]=egyseg; egysegek[hely+1]=szam;} else egysegek[hely+1]=parseInt(egysegek[hely+1])+szam;
}

function KIIR(){
	kiirandoT=getCookie("sereg").split(";");
	kiirando="";
	for (i=0;i<kiirandoT.length;i+=2){
		tab="";
		if (kiirandoT[i].length<7) tab="\t";
		kiirando+=kiirandoT[i]+":\t"+tab+kiirandoT[i+1]+"\n";
	}
	alert(kiirando);
}

	if (document.location.href.indexOf("screen=train")==-1) {alert("A kik�pz�sbe kellene futtatni a scriptet"); exit(0);}
try{
	X=document.getElementById("train_form").getElementsByTagName("table")[0];
	/*deCode*/ Sereg=getCookie("sereg"); if (Sereg==undefined) {Sereg=""; var egysegek=new Array();} else var egysegek=Sereg.split(";");
	
	for (i=1;i<X.rows.length-1;i++){
		Egyseg=$.trim(X.rows[i].cells[0].innerText);
		DBSzam=parseInt(X.rows[i].cells[6].innerText.match(/[0-9]+/g)[1]);
		ADD(Egyseg,DBSzam);
	}
	/*Coding*/
	str="";
	for (i=0;i<egysegek.length;i++){
		str+=egysegek[i];
		if (i!=egysegek.length-1) str+=";";
	}
	expDate = new Date();
	expDate.setTime(expDate.getTime() + (60*1000));
	setCookie("sereg",str,expDate);
	X.rows[0].cells[0].innerHTML='<a href="javascript: KIIR()">MENNYI A SEREG?</a>';
}catch(e){alert(e);}
void(0);