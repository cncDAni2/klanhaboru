javascript:
function setCookie(name, value, expire) {
	document.cookie = name + "=" + escape(value)
	+ ((expire == null) ? "" : ("; expires=" + expire.toGMTString()));
}

function getCookie(Name){
	var search = Name + "=";
	if (document.cookie.length > 0) {
		offset = document.cookie.indexOf(search);
		if (offset != -1) {
			offset += search.length;
			end = document.cookie.indexOf(";", offset);
			if (end == -1) end = document.cookie.length;
			return unescape(document.cookie.substring(offset, end));
		}
	}
}
		VISITED = getCookie('visited');
		if (VISITED==null || VISITED=="") {
			alert("El�bb elemezned kell jelent�seket!");
			exit("");
		}
		VISITED++;	
		kiir = "Az eddig felvett faluit: (az adatok t�rl�dnek az OK lenyom�sa ut�n)\n";
		expDate = new Date();
		expDate.setTime(expDate.getTime() - (60*1000));
		for (i=0;i<VISITED;i++){
			LEPES = i;
			VALT = "falu" + LEPES;
			resz = getCookie(VALT);
			kiir = kiir + resz + "\n";
			setCookie(VALT, 0, expDate);
		}
		alert (kiir);		
		setCookie('visited', 0, expDate);
	void(0);