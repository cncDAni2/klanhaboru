javascript:
function setCookie(name, value, expire) {
	document.cookie = name + "=" + escape(value)
	+ ((expire == null) ? "" : ("; expires=" + expire.toGMTString()));
}

function getCookie(Name){
	var search = Name + "=";
	if (document.cookie.length > 0) {
		offset = document.cookie.indexOf(search);
		if (offset != -1) {
			offset += search.length;
			end = document.cookie.indexOf(";", offset);
			if (end == -1) end = document.cookie.length;
			return unescape(document.cookie.substring(offset, end));
		}
	}
}

	try{
	url=document.location.href; patt=/report/g;
	if(!patt.test(url)) {
		alert('Jelent�sekn�l pr�b�ld...');
		void(0);
	}
	
	VISITED = getCookie('visited');
	if (VISITED==null || VISITED=="") {
		VISITED=0;
	} else {
		VISITED++;
	}
	var x=document.getElementById("attack_spy").innerHTML;
	x=x.replace(/<span class="grey">.<\/span>/g,"");
	var nyers=x.match(/(>)[0-9]+( <)/g); var ossz=0;
	for (i=0;i<nyers.length;i++) {nyers[i]=nyers[i].replace(">","");nyers[i]=nyers[i].replace(" <",""); ossz+=parseInt(nyers[i]);}
	NYERSI = getCookie('Nyersossz');
	if (NYERSI==null || NYERSI=="") {
		NYERSI=ossz;
	} else {		
		NYERSI = parseInt(NYERSI);
		NYERSI=NYERSI+ossz;
	}
	var kordik=document.getElementById("labelText").innerHTML;
	KT=kordik.match(/[0-9][0-9][0-9]/g);
	hossz=KT.length;
	expDate = new Date();
	expDate.setTime(expDate.getTime() + (60*1000));
	setCookie('visited', VISITED, expDate);
	setCookie('Nyersossz', NYERSI, expDate);
	expDate.setTime(expDate.getTime() + (60*60*1000));
	csomag = ossz + "_" + KT[hossz-2] + "-" + KT[hossz-1];
	valt = "falu" + VISITED;
	setCookie(valt, csomag, expDate);
	lovak=NYERSI/80;
	KIIR = VISITED+1 + ". falu felvitele sikeres.<br>Nyersanyag a faluban: " + ossz + ".<br>Nyersanyag �sszesen: " + NYERSI + ".<br>Sz�ks�ges kl-ek sz�ma �sszesen: " + lovak;
	document.getElementById('labelText').innerHTML=KIIR;
	} catch(e) {alert("Hiba t�rt�nt felvitelkor\n"+e);}
	void(0);