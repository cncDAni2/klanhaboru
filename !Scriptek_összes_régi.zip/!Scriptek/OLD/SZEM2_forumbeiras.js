javascript:
function Fkitolt(){
	FRM.document.forms[0].message.value=azo; 
	FRM.document.forms[0].send.click();
	document.getElementById("naplo").innerHTML+="<tr><td>"+Date()+"</td><td>Forumcheck: F�rumba bejegyz�s megt�rt�nt</td></tr>";
}
function SZEM_forum(){
	if (egyedi) {alert("Nincs farmol� script!");/* Flap=window.open(urll,"forum");*/ void(0);}
	azo="";
	patt=/action=cancel/g;
	patt2=/(id=)[0-9]+/g;
 try{
	lap=lapkeres(); var egyedi=false;
	/*if (Flap==0) {egyedi=true;} else */var Flap=window["lap"+lap];
	for(k=0;k<Flap.document.links.length;k++){
		if (patt.test(Flap.document.links[k].href)) {
			azon=Flap.document.links[k].href.match(patt2);
			azon[0]=azon[0].replace("id=","");
			azo=azon[0];
		}
	}
	var now=new Date();
	ora = getCookie("forum");
	if ((azo!="") && (ora!=now.getHours())) {
		FRM=window.open("http://hu15.klanhaboru.hu/game.php?village=20548&screen=forum&screenmode=view_thread&thread_id=7814&answer=true&page=last","forum");
		setTimeout("Fkitolt()",8000);
		var ora=now.getHours();setCookie("forum",ora);
	}
 } catch(err) {document.getElementById("naplo").innerHTML+="<tr><td>"+Date()+"</td><td>F�rum ID �r�: <b>HIBA:</b>"+err.message+"</td></tr>";}
		iforum=setTimeout("SZEM_forum()",1000*60*5);
}
if (egyedi!=undefined) {alert("m�r fut egy ilyen"); exit(); }
document.getElementById('kieg').innerHTML+='<tr><td>F�rum ID �r�</td><td><a href=\'javascript: stop("forum");\'>Le�ll�t�s</a></td></tr>';
document.getElementById("naplo").innerHTML+="<tr><td>"+Date()+"</td><td><b>�j kieg�sz�t�</b> �rz�kelve: F�rum ID �r�</td></tr>";
lap=lapkeres(); var egyedi=false;;
var now=new Date(); ora = now.getHours()-1; setCookie("forum",ora);
SZEM_forum();
void(0);