javascript:
/*Felderítő váz!*/
javascript:
var N=5; /*Lapok száma*/
if (document.location.href.indexOf("screen=overview_villages")==-1) {alert("Ez a script az áttekintésben fut le csak.\n\nPrémiumosoknak először áttekintés átalakító futtatására van szükség a Termelői nézetbe!"); exit(0);}
try{
	RefArray=new Array(); /*Window pointers*/
	WAIT=new Array(); /*Mennyiszer próbáltuk sikertelenül elemezni (lapID~dbszám)*/
	FELDOLG=new Array(); /*Miket dolgozunk fel épp (lapID~FALUK tömb elemei)*/
	FALUK=new Array(); /*Munkalista*/
	BOT=false;
	init();
	var LAP=0; /*Aktuális lapmunka*/
	var BASE_URL=document.location.href.split("game.php")[0]+"game.php";
	if (document.location.href.indexOf("t=")>0) BASE_URL+="?"+document.location.href.match(/t=[0-9]+/g)[0]+"&"; else BASE_URL+="?";
	var egysegnevek=new Array();
eloszto();
}catch(e){alert("Indítási hiba:\n"+e);}

function init(){try{
	/*tömb nullázások, N-ig*/
	try{
	for (var i=0;i<N;i++){
		WAIT[i]=0; FELDOLG[i]=0;
	}
	document.title="Csapatmozgás Felderítő";
	
	/*PF-átalakítás*/
	var PFA=document.getElementById("production_table");
	
	var patt=new RegExp("[0-9]+(\|)[0-9]+","g");
	if (patt.test(PFA.rows[1].cells[0].textContent)) var f=0; else 
	if (patt.test(PFA.rows[1].cells[1].textContent)) var f=1; else
	return false;
	
	if (PFA.rows[0].cells.length>6) {
		for (i=0;i<PFA.rows.length;i++){
			PFA.rows[i].deleteCell(9);
			PFA.rows[i].deleteCell(8);
			PFA.rows[i].deleteCell(7);
			PFA.rows[i].deleteCell(5);
			PFA.rows[i].deleteCell(0);
	}}}catch(e){alert("PF -> Nem-PF konverziós hiba:\n"+e);}
	
	/*Faluk felvétele munkatömbbe*/
	for (var i=1;i<PFA.rows.length;i++){
		FALUK[i-1]=parseInt(PFA.rows[i].cells[f].getElementsByTagName("span")[0].getAttribute("id").match(/[0-9]+/g)[0]);
	}
	
	/*Weboldal szerkezeti kialakítása; lehetőség adása "BOT=false;" értékadásra!*/
	document.getElementById("header_info").innerHTML+='<tr><td colspan="4"><a href="javascript:BOT=false; void(0);">Klikk, ha bejött a bot védelem, de már beírtad a kódot</a><p id="DEBUG"></p></td></tr>';
	doItYouself();
}catch(e){alert(e);}}

function debug(str){
	return;
	document.getElementById("DEBUG").innerHTML+="<br>"+str;
	return;
}

function recalc(){try{
	/*Végeredménnyel való művelet*/
	
	/*Lapbezárás*/
	for (var i=0;i<RefArray.length;i++){
		try{RefArray[i].window.close();}catch(e){}
	}
	
	
	doItYouself();
}catch(e){alert("Hiba újraszámításkor:\n"+e);}}

function kovetkezo(){ /*Visszaadja melyik a következő faluazonosító amit nézni kell. -1 ha nincs már több feldolgozandó falu*/
	var nx=-1;
	for (var i=0;i<FALUK.length;i++){
		if (FALUK[i]!=0 && FELDOLG.indexOf(FALUK[i])==-1) {
			nx=i;
			break;
		}
	}
	/*feldolg-ba betenni faluk[i]-t*/
	return nx;
}
function Botvedelem(){
	/*Figyelmeztető, stb.*/
	alert("Bot védelem!");
	BOT=true;
	for (var i=0;i<RefArray.length;i++){
		try{RefArray[i].window.close();}catch(e){}
	}
	window.open(BASE_URL);
	return;
}

function szamol(P_IND){try{ /*Aktuális lapon való feladatvégzés. False: sikertelen;True: sikeres*/
/*Hibák/betöltődés*/
	if (!RefArray[P_IND].document.getElementById("serverTime")) {return false;}
	if ((WAIT[P_IND]==10)) {FELDOLG[P_IND]=0; return false;}
/*ID egyezés keresés*/
	if (RefArray[P_IND].game_data.village.id!=FELDOLG[P_IND]) { return false;}
/*Bot Védelem érzékelése*/
	if (RefArray[P_IND].document.getElementById('bot_check') || RefArray[P_IND].document.title=="Bot védelem") {
	 BOT=true;
	 Botvedelem();
	 return false;
	}
	
	doItYouself();
	
/*FALUK munkatömb módosítása: --> 0 = kész*/
	FALUK[FALUK.indexOf(RefArray[P_IND].game_data.village.id)]=0;
	return true;
}catch(e){}
return false;}



function eloszto(){try{ /*A Motor*/
	if (!BOT){
	var nexttime=200;
	var nextindex=kovetkezo();
	var end=false;
	if (nextindex==-1) { 
		var kilep=true; 
		for (var i=0;i<FELDOLG.length;i++) {if (FELDOLG[i]!=0 && FELDOLG[i]!="" && FELDOLG[i]!=undefined) {kilep=false; break;}}
		if (kilep) {recalc(); return;}
		if (FELDOLG[LAP]!=0 && FELDOLG[LAP]!="" && FELDOLG[LAP]!=undefined) end=true;
	}
	
/*Lapmegnyitás!*/
	if (end && (RefArray[LAP].closed || RefArray[LAP]==undefined)){
/*(!)*/	RefArray[LAP]=window.open(BASE_URL+"village="+FALUK[nextindex]+"&screen=place&mode=units","ero_"+LAP);
		FELDOLG[LAP]=FALUK[nextindex];
	} else 
/*(!)*/if (((RefArray[LAP]==undefined) || (RefArray[LAP].closed) || (RefArray[LAP].location.href.indexOf("screen=place&mode=units")==-1) || (WAIT[LAP]==0)) && (nextindex!=-1)) {
/*(!)*/	RefArray[LAP]=window.open(BASE_URL+"village="+FALUK[nextindex]+"&screen=place&mode=units","ero"+LAP);
		FELDOLG[LAP]=FALUK[nextindex];
	}
	/*debug(LAP+": Feldolg: "+FELDOLG+" - FALUK: "+FALUK);*/
	
	
	if (szamol(LAP,nextindex)) {
		FELDOLG[LAP]=0;
		nextindex=kovetkezo();
/*(!)*/	if (nextindex!=-1) {RefArray[LAP]=window.open(BASE_URL+"village="+FALUK[nextindex]+"&screen=place&mode=units","ero"+LAP); FELDOLG[LAP]=FALUK[nextindex];}
		WAIT[LAP]=0;
	} else {
		WAIT[LAP]++;
		if (WAIT[LAP]>10) {
			RefArray[LAP].window.close();
			WAIT[LAP]=0;
		}
	}} else var nexttime=5000;
}catch(e){alert(e);}
	LAP++; if (LAP>N) LAP=0;
	nexttime=Math.round(nexttime*((Math.random()*0.4)+0.75));
	setTimeout("eloszto()",nexttime);
	return;
}

void(0);