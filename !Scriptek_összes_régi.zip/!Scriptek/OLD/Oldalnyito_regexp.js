javascript:
function ZOPEN(linkk){
	window.open(linkk);
	return;
}
try{
lks=document.getElementsByTagName("a");
ezt=prompt("Milyen linkeket nyissak meg?\nRegExp kifejezést adjon meg!","[0-9]+\\|[0-9]+");
if (ezt==null) throw "exit";
regezt=new RegExp(ezt,"g");
for (i=0;i<lks.length;i++){
	if (regezt.test(lks[i].innerText)) a=setTimeout(ZOPEN(lks[i].href),2000);
}
}catch(e){}
void(0);