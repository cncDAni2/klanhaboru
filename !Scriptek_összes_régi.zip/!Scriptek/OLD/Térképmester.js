javascript: 
/*Import m�d: be/ki --> friss�teni mp-enk�nt a t�rk�pet, �jrarajzolni!
Jel�l� m�d: be/ki*/

var alapertelmezes = {
    bbkodos: 'igen',
    ujsor: 'igen'
};

function create() {
    var e = alapertelmezes.bbkodos == "igen" ? ' checked="checked"' : "";
    var t = alapertelmezes.ujsor == "igen" ? 'checked="checked"' : "";
    $(".minimap_container").after('<input type="checkbox" id="scriptused_bb"' + e + ' /><label for="scriptused_bb">BB k�ddal?</label><br /><input type="checkbox" id="scriptused_newline"' + t + ' /><label for="scriptused_newline">�j sorba?</label><br /><textarea id="koordik" cols="38" rows="20"></textarea><br /><button id="scriptused_button">K�sz vagyok!</button><button id="mapimport">Import!</button>')
}

function getBB() {
    return $("input#scriptused_bb").is(":checked")
}
function newLine() {
    return $("input#scriptused_newline").is(":checked")
}

function mapimport(){try{
	var imp=document.getElementById("koordik").value;
	imp=imp.match(/[0-9]+(\|)[0-9]+/g);
	for (var i=0;i<imp.length;i++){
		var s=TWMap.villages[parseInt(imp[i].split("|")[0])*1000+parseInt(imp[i].split("|")[1])];
		if (typeof s != "undefined") {
			$("img#map_village_" + s.id).fadeTo(0, .5);
		}
	}
}catch(e){alert(e);}}

function addCoord(e, t) {
    var n = $("textarea#koordik").val();
    var r = n + e + t;
    $("textarea#koordik").val(r)
}
function bind() {
    TWMap.map._handleClick = function (e) {
        var koord = this.coordByEvent(e);
        var X = t[0];
        var Y = t[1];
        var i = X * 1000 + Y;
        var s = TWMap.villages[i];
		
        if (typeof s != "undefined") {
			/*var str="";
			for (var i in s) {
				str+=i+": "+s[i]+"\n";
			}
			alert(str);
			
id: 359482
img: 13
name: Paige Goddess of War
points: 9.786
owner: 1286893
mood: 25
bonus: undefined
xy: 384746 */
            var o = "";
            var u = "\n";
            if (getBB()) {
                o = "[coord]" + koord.join("|") + "[/coord]";
            } else {
                o = koord.join("|");
            }
            if (newLine()) {
                u = "\n";
            } else {
                u = " ";
            }
            addCoord(o, u);
            $("img#map_village_" + s.id).fadeTo(0, .5);
        }
        return false
    };
    $("button#scriptused_button").on("click", function () {
        TWMap.map._handleClick = null;
    });
	$("button#mapimport").on("click", function () {
        mapimport();
    });
    $("textarea#koordik").on("focus", function () {
        $(this).select();
    })
}

var win = window.frames.length > 0 ? window.main : window;
if (win.game_data.screen == "map") {
    create();
    bind();
} else {
    alert("A script csak a t�rk�pen m�k�dik.\nUgr�s a t�rk�pre...");
    self.location = win.game_data.link_base_pure.replace(/screen\=\w*/i, "screen=map");
}
void(0);