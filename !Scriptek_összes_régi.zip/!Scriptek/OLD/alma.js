javascript:
if (typeof cURL=='undefined') var cURL=document.location.href; else exit(0);
if(cURL.indexOf('screen=overview_villages')==-1) exit(0);

function loadXMLDoc(dname) {
	if (window.XMLHttpRequest) xhttp=new XMLHttpRequest();
		else xhttp=new ActiveXObject("Microsoft.XMLHTTP");
	xhttp.open("GET",dname,false);
	xhttp.send();
	return xhttp.responseXML;
}
function setCookie(c_name,value){
localStorage.setItem(c_name,value);
return;
}
function getCookie(Name){try{
	return localStorage.getItem(Name);
}catch(e){return null;}
}

function pic(tipus){
    return "http://cncdani2.freeiz.com/pic/script_csoport/"+tipus+".png";
}
function picT(tipus){
	if (tipus=="att") 
		return "http://cdn2.tribalwars.net/graphic/command/attack.png"; 
	else
		return "http://cdn2.tribalwars.net/graphic/buildings/"+tipus+".png";
}

function ModOpenType(fa,erre){
try{
    a=T.getElementsByTagName("img");
    for (var i=0;i<a.length;i++){
	a[i].style.backgroundColor="transparent";
    }
    fa.style.backgroundColor="brown";
    OPENTYPE=erre;
	
	suti=getCookie("cnc_csoport");
	Fsuti=suti.split(";");
	Fsuti[0]=erre;
	str=Fsuti[0];
	for (var i=1;i<Fsuti.length;i++){str+=";"+Fsuti[i];}
	setCookie("cnc_csoport",str);
}catch(e){alert(e);}
return;
}

function manager(job){
    if (job=="del"){
        sure=confirm("Minden csoport törl\u0151dik, folytatja?");
        if (sure) localStorage.removeItem('cnc_csoport'); else return;
        location.reload();
    }
    if (job=="exp"){
        exp=getCookie('cnc_csoport');
        alert("Mentse el az alábbi sort, melyet kés\u0151bb megadhat importáláskor adatainak visszállításához:\n"+exp);
    }
    if (job=="imp"){
        input=prompt("Adja meg a korábban lementett adatot visszaállításhoz: ");
        if (input==null || input=="") return;
        setCookie('cnc_csoport',input,30);
        imp=input.match(/;[^;]+/g);G.innerHTML="";
        for (var j=0;j<imp.length;j++){
            imp[j]=imp[j].replace(/;/g,"");
            if (imp[j].search(/[^0-9]/g)>=0) G.innerHTML+='&nbsp;&nbsp;&nbsp; <a href=\'javascript: csoport("'+imp[j]+'");\'>'+imp[j]+'</a>';
        }
        kivalasztott="";
		frissit();
    }
    return;
}

function frissit(){
	try{
	suti=getCookie("cnc_csoport");
	Fsuti=suti.split(";");
	G.innerHTML="";
	document.getElementById("D_tanya").setAttribute("title",">"+Fsuti[1]+" fő. Kattints a módosításhoz.");
	document.getElementById("D_raktar").setAttribute("title",">"+Fsuti[2]+"% telítettség. Kattints a módosításhoz.");
	document.getElementById("D_pont").setAttribute("title",">"+Fsuti[3]+" pont. Kattints a módosításhoz.");
	for (var i=4;i<Fsuti.length;i++){
		if (Fsuti[i].indexOf(",")==-1) csopnev=Fsuti[i]; else csopnev=Fsuti[i].split(",")[0];
		if (csopnev==KIVALASZTOTT) kieg='style="background-color:#B0B0FF; padding:2px; border:1px solid black;"'; else kieg="";
		G.innerHTML+='<a '+kieg+' href=\'javascript: csoport("'+csopnev+'");\'>'+csopnev+"</a>&nbsp; &nbsp; &nbsp; &nbsp;";
	}
	}catch(e){alert(e);}
	return;
}

function addFalu(koord){
	if (KIVALASZTOTT=="") return;
	try{
		var suti=getCookie("cnc_csoport");
		sutiF=suti.split(";");
		var ures=false;
		for (var i=4;i<sutiF.length;i++){
			if (sutiF[i].indexOf(",")==-1) {
				if (sutiF[i]==KIVALASZTOTT) {ures=true; break;}
			} else {
				if (sutiF[i].split(",")[0]==KIVALASZTOTT) break;
			}
		}
		if (!ures){
			var sutiFF=sutiF[i].split(","); var talalat=false;
			for (var j=1;j<sutiFF.length;j++){ /*Duplikáció keresése*/
				if (sutiFF[j]==koord) { sutiF[i]=sutiF[i].replace(","+koord,""); talalat=true;}
			}
			if (!talalat) sutiF[i]+=","+koord;
		} else sutiF[i]+=","+koord;
		
		var str="";
		for (var i=0;i<sutiF.length-1;i++){
			str+=sutiF[i]+";";
		} str+=sutiF[i];
		setCookie("cnc_csoport",str);
	} catch(e){alert("Hiba faluhozzáadáskor\n"+e);}
    return;
}

function csoport(csnev){try{
	var table=document.getElementById("production_table");
	for (var i=1;i<table.rows.length;i++){CHECK=table.rows[i].cells[getOszlopNo("falunev")].getElementsByTagName("input")[0];	CHECK.setAttribute("style","display:none");} /*checkbox-ok eltüntetése*/
	
	if (ISHALMAZ=="") {KIVALASZTOTT=csnev; frissit();}
	var suti=getCookie("cnc_csoport");
	var Fsuti=suti.split(";");
	var aktnev=""; ures=false;
	for (var i=4;i<Fsuti.length;i++){
		if (Fsuti[i].indexOf(",")>-1) {ures=false; aktnev=Fsuti[i].split(",")[0];} else {ures=true; aktnev=Fsuti[i];}
		if (aktnev == csnev) break;
	}
	
	var a=document.getElementById("production_table").rows;
	if (ures) {
		for (var i=1;i<a.length;i++){
			CHECK2=a[i];
			if (CHECK2.style.display!="none") regi=true; else regi=false;
			uj=false;
			if (halmaz(regi,uj)) CHECK2.setAttribute("style","display:line"); else CHECK2.setAttribute("style","display:none");
		}
		return;
	}
	var oszl=getOszlopNo("falunev");
	var v=Fsuti[i].split(",");
	for (var i=1;i<a.length;i++){
		CHECK2=a[i];
		if (CHECK2.style.display!="none") regi=true; else regi=false;
		var koord=CHECK2.innerText.match(/[0-9]+(\|)[0-9]+/g);
		koord=koord[koord.length-1];
		uj=false;
		for (var j=1;j<v.length;j++) {
			if (koord==v[j]) {uj=true; break;}
		}
		if (halmaz(regi,uj)) CHECK2.setAttribute("style","display:line"); else CHECK2.setAttribute("style","display:none");
	}
	ISHALMAZ="";
	szamlal();
	return;
}catch(e){alert(e);}}

function szamlal(){
	var szamlal=document.getElementById("production_table").rows; var szamlalS=0;
	for (var i=1;i<szamlal.length;i++){
		if (szamlal[i].style.display!="none") szamlalS++;
	}
	szamlal[0].cells[getOszlopNo("falunev")].innerHTML=szamlal[0].cells[getOszlopNo("falunev")].innerHTML.replace(/\([0-9]+\)/g,"("+szamlalS+")");
}

function ujcsoport(){
	try{suti=getCookie("cnc_csoport");
	nev=prompt("Mi legyen az új csoport neve?");
		if (nev==null) return;
		if (nev.search(";")>=0) {alert("A ; karakter nem megengedett, pont (.)-ra alakul át.");nev=nev.replace(";",".");}
		if (nev.search(",")>=0) {alert("A , karakter nem megengedett, pont (.)-ra alakul át.");nev=nev.replace(",",".");}
		if (nev.search("\"")>=0) {alert("A \" karakter nem megengedett, törlődik.");nev=nev.replace("\"","");}
        if (nev.length<1) {alert("A csoport neve nem lehet üres");return;}
	/*Duplikáció?*/
	Fsuti=suti.split(";");
	for (var i=4;i<Fsuti.length;i++){ if (Fsuti[i].indexOf(",")>=0) if(Fsuti[i].split(",")[0]==nev) {alert("Ilyen nevű csoport már létezik"); return;}}
	
	setCookie("cnc_csoport",suti+";"+nev);
	frissit();
	}catch(e){alert(e);}
	return;
}

function Dcsoport(tipus){ try{
	var table=document.getElementById("production_table");
	for (var i=1;i<table.rows.length;i++){CHECK=table.rows[i].cells[getOszlopNo("falunev")].firstChild;	CHECK.setAttribute("style","display:none");} /*checkbox-ok eltüntetése*/
	KIVALASZTOTT="";
	if (tipus=="ossz"){
		var a=document.getElementById("production_table").rows;
		for (var i=1;i<table.rows.length;i++){
            CHECK2=a[i];
			if (CHECK2.style.display!="none") regi=true; else regi=false;
			uj=true;
			if (halmaz(regi,uj)) CHECK2.setAttribute("style","display:line"); else CHECK2.setAttribute("style","display:none");
		}
	}
	if (tipus=="tanya"){
		suti=getCookie("cnc_csoport");
		ertek=suti.split(";")[1]; ertek=parseInt(ertek);
		var a=document.getElementById("production_table").rows;
		for (var i=1;i<table.rows.length;i++){
			CHECK2=a[i];
			/*HALMAZ MEGVALÓSÍTÁS: megnézi hogy benne lenne e. Átküldi a régi és új értéket, majd visszatérési értéke az, hogy benne lenne e. Ha nincs ISMHALMAZ visszatér az újjal.*/
			if (CHECK2.style.display!="none") regi=true; else regi=false;
			oszl=getOszlopNo("tanya");
			if (CHECK2.cells[oszl].innerHTML.split("/")[0] >= ertek) uj=true; else uj=false;
			if (halmaz(regi,uj)) CHECK2.setAttribute("style","display:line"); else CHECK2.setAttribute("style","display:none");
		}
	}
	if (tipus=="raktar"){
		suti=getCookie("cnc_csoport");
		ertek=suti.split(";")[2]; ertek=parseInt(ertek);
		var a=document.getElementById("production_table").rows;
		for (var i=1;i<table.rows.length;i++){
			CHECK2=a[i];
			if (CHECK2.style.display!="none") regi=true; else regi=false;
			M=table.rows[i].cells[getOszlopNo("nyers")].childNodes;
			max=0;
			fa=parseInt(M[0].innerHTML.replace(/[^0-9]+/g,"")); if (fa>max) max=fa;
			agyag=parseInt(M[2].innerHTML.replace(/[^0-9]+/g,"")); if (agyag>max) max=agyag;
			vas=parseInt(M[4].innerHTML.replace(/[^0-9]+/g,"")); if (vas>max) max=vas;
			raktar=parseInt(table.rows[i].cells[getOszlopNo("raktar")].innerText);
			if ((max/raktar)*100 > ertek) uj=true; else uj=false;
			if (halmaz(regi,uj)) CHECK2.setAttribute("style","display:line"); else CHECK2.setAttribute("style","display:none");
		}
	}
	if (tipus=="pont"){
		suti=getCookie("cnc_csoport");
		ertek=suti.split(";")[3]; ertek=parseInt(ertek);
		var a=document.getElementById("production_table").rows;
		for (var i=1;i<table.rows.length;i++){
			CHECK2=a[i];
			if (CHECK2.style.display!="none") regi=true; else regi=false;
			if (parseInt(CHECK2.cells[getOszlopNo("pont")].innerText.replace(".","")) >= ertek) uj=true; else uj=false;
			if (halmaz(regi,uj)) CHECK2.setAttribute("style","display:line"); else CHECK2.setAttribute("style","display:none");
		}
	}
	if (tipus=="regexp"){
		var patt2p=prompt("Adja meg azt a reguláris kifejezést, amely szerint a faluneveket szűrni szeretné!\nA falu neve alatt a koordináta és a kontinens szám is értendő!");
		if (patt2p==null) return;
		var patt2=new RegExp(patt2p,"");
		var a=document.getElementById("production_table").rows;
		var oszl=getOszlopNo("falunev");
		for (var i=1;i<a.length;i++){
			CHECK2=a[i];
			nev = $.trim(CHECK2.cells[oszl].innerText);
			if (CHECK2.style.display!="none") regi=true; else regi=false;
			if (patt2.test(nev)) uj=true; else uj=false;
			if (halmaz(regi,uj)) CHECK2.setAttribute("style","display:line"); else CHECK2.setAttribute("style","display:none");
		}
	}
	if (tipus=="tamad"){
		var a=document.getElementById("production_table").rows;
		for (var i=1;i<table.rows.length;i++){
			CHECK2=a[i];
			oszl=getOszlopNo("falunev");
			if (CHECK2.style.display!="none") regi=true; else regi=false;
			var vizsga=CHECK2.cells[oszl].innerHTML;
			if (typeof(vizsga)!='undefined' && vizsga!=null){
				if (vizsga.indexOf("attack.png")>0) uj=true; else uj=false;
			} else uj=false;
			if (halmaz(regi,uj)) CHECK2.setAttribute("style","display:line"); else CHECK2.setAttribute("style","display:none");
		}
	}
	
	if (tipus=="headtail"){
		var fej=prompt("Mely falukat akarod a jelenlegi sorrendből megtartani?\nElső X falu megtartásához írj be egy számot.\nUtolsó X falu megadásához írj egy '-'-t, és aztán a számot! (pl. -20)");
		if (fej==null) return;
		if (fej[0]=="-") var lab=true; else var lab=false;
		fej=fej.replace(/[^0-9]/g,"");
		if (fej=="") return;
		fej=parseInt(fej);
		var szamlalo=0; var a=document.getElementById("production_table").rows;
		
		if (!lab){
			for (var i=1;i<a.length;i++){
				CHECK2=a[i];
				if (CHECK2.style.display!="none") {
					szamlalo++;
					if (szamlalo>fej) CHECK2.setAttribute("style","display:none");
				}
		}} else {
			for (var i=a.length-1;i>0;i--){
				CHECK2=a[i];
				if (CHECK2.style.display!="none") {
					szamlalo++;
					if (szamlalo>fej) CHECK2.setAttribute("style","display:none");
				}
		}}
	}
	ISHALMAZ="";
	frissit();
	szamlal();
	return;
}catch(e){alert(e);}}

function halmaz(regi,uj){
	if (ISHALMAZ=="") return uj;
	if (ISHALMAZ=="metszet"){
		if (!regi || !uj) return false; else return true;
	}
	if (ISHALMAZ=="unio"){
		if (regi || uj) return true; else return false;
	}
	if (ISHALMAZ=="kulonbseg"){
		if (!regi) return false;
		if (regi && uj) return false;
		return true;
	}
	return uj;
}

function sethalmaz(tipus){
	if (tipus!="negalt") {ISHALMAZ=tipus; return;}
	
	var table=document.getElementById("production_table");
	for (var i=1;i<table.rows.length;i++){CHECK=table.rows[i].cells[0].firstChild;	CHECK.setAttribute("style","display:none");} 
	KIVALASZTOTT="";
	for (var i=1;i<table.rows.length;i++){
	var CHECK2=table.rows[i];
		if (CHECK2.style.display!="none") CHECK2.setAttribute("style","display:none"); else CHECK2.setAttribute("style","display:line");
	}
	szamlal();
	return;
}

function szerkeszt(){ try{
	HALMAZ=""; if (KIVALASZTOTT=="") return;
	var table=document.getElementById("production_table");
	var oszl=getOszlopNo("falunev");
	for (var i=1;i<table.rows.length;i++){ /*Összes falu és checkbox megjelenítése*/
		CHECK=table.rows[i].cells[oszl].firstChild;	CHECK.setAttribute("style","display:line"); CHECK.checked=false;
		CHECK2=table.rows[i]; CHECK2.setAttribute("style","display:line");
	}
	
	suti=getCookie("cnc_csoport");
	sutiF=suti.split(";");
	for (var i=4;i<sutiF.length;i++){if (sutiF[i].indexOf(",")==-1) {if (sutiF[i]==KIVALASZTOTT) return;} else if (sutiF[i].split(",")[0]==KIVALASZTOTT) no=i;}
	for (var i=1;i<table.rows.length;i++){ /*Pipa rakása a megfelelő helyekre*/
		koord=table.rows[i].cells[oszl].innerText.match(/[0-9]+(\|)[0-9]+/g);
		koord=koord[koord.length-1];
		CHECK2=table.rows[i].cells[oszl].firstChild;
		if (sutiF[no].indexOf(koord)>0) CHECK2.checked=true;
	}
	}catch(e){alert(e);}
}

function atnevez(){try{
	if (KIVALASZTOTT=="") {alert("Csak általad létrehozott és kijelölt csoportot tudsz átnevezni"); return;}
	suti=getCookie("cnc_csoport");
	nev=prompt("Mi legyen az új csoport neve?",KIVALASZTOTT);
		if (nev==KIVALASZTOTT) return;
		if (nev==null) return;
		if (nev.search(";")>=0) {alert("A ; karakter nem megengedett, pont (.)-ra alakul át.");nev=nev.replace(";",".");}
		if (nev.search(",")>=0) {alert("A , karakter nem megengedett, pont (.)-ra alakul át.");nev=nev.replace(",",".");}
		if (nev.search("\"")>=0) {alert("A \" karakter nem megengedett, törlődik.");nev=nev.replace("\"","");}
        if (nev.length<1) {alert("A csoport neve nem lehet üres");return;}
	/*Duplikáció?*/
	Fsuti=suti.split(";");
	for (var i=4;i<Fsuti.length;i++){
		if (Fsuti[i].indexOf(",")>=0) {
			if (Fsuti[i].split(",")[0]==nev) {alert("Ilyen nevű csoport már létezik"); return;}
		} else {
			if (Fsuti[i]==nev) {alert("Ilyen nevű csoport már létezik"); return;}
		}
	}
	suti=suti.replace(";"+KIVALASZTOTT,";"+nev);
	setCookie("cnc_csoport",suti);
	}catch(e){alert(e);}
	frissit();
	return;
}

function torol(){ try{
	if (KIVALASZTOTT=="") return;
	if (!confirm("Biztosan törli ezt a csoportot?\n"+KIVALASZTOTT)) return;
	suti=getCookie("cnc_csoport");
	Fsuti=suti.split(";");
	
	str=Fsuti[0];
	for (var i=1;i<Fsuti.length;i++){ if (i>3) {
		if (Fsuti[i].indexOf(",")==-1) {
			if (Fsuti[i]!=KIVALASZTOTT) str+=";"+Fsuti[i];
		} else {
			if (Fsuti[i].split(",")[0]!=KIVALASZTOTT) str+=";"+Fsuti[i];
		}
	} else str+=";"+Fsuti[i];
	}
	setCookie("cnc_csoport",str);
	frissit();
	return;
}catch(e){alert(e);}
}

function mod(ezt){ /*Default csoportok értékeinek változtatása*/
	suti=getCookie("cnc_csoport");
	Fsuti=suti.split(";");
	if (ezt==1) {
		erre=prompt("Adja meg az új értéket.\nTanyahelyes érték (50-30000)\nJelentése: azon faluk, melyek lakossága ezen értékű, vagy feletti."); 
		if (erre==null) return;
		try{if (isNaN(erre)) throw "error"; erre=parseInt(erre); if (erre>30000||erre<50) throw "error";} catch(e){alert("Hibásan megadott érték"); return;}
	}
	if (ezt==2){
		erre=prompt("Adja meg az új értéket.\n%-os érték (1-100)\nJelentése: azon faluk, melyek raktár telítettsége ezen % érték feletti, a legtöbb nyersanyag alapján."); 
		if (erre==null) return;
		try{if (isNaN(erre)) throw "error"; erre=parseInt(erre); if (erre>100||erre<1) throw "error";} catch(e){alert("Hibásan megadott érték"); return;}
	}
	if (ezt==3){
		erre=prompt("Adja meg az új értéket.\nPontérték (50-13000)\nJelentése: azon faluk, melyek a megadott pont feletti értékkel rendelkeznek."); 
		if (erre==null) return;
		try{if (isNaN(erre)) throw "error"; erre=parseInt(erre); if (erre>13000||erre<50) throw "error";} catch(e){alert("Hibásan megadott érték"); return;}
	}
	
	Fsuti[ezt]=erre;
	str=Fsuti[0];
	for (var i=1;i<Fsuti.length;i++){str+=";"+Fsuti[i];}
	setCookie("cnc_csoport",str);
	
	frissit();
	return;
}

function getOszlopNo(ezt){ /*megkeresi hanyadik oszlopba van a keresett érték*/
	tabla=document.getElementById("production_table").rows[0];
	for (var i=0;i<tabla.cells.length;i++){
		if (tabla.cells[i].getAttribute("id")==ezt) return i;
	}
	return 0;
}

function megnyit(){ /*nem none display-ű falukat megnyitja, OPENTYPE változó alapján*/
try{
    var nyit="";var FALUK=document.getElementById("production_table");
	oszlopno=getOszlopNo("falunev");
    for (var q=1;q<FALUK.rows.length;q++){
        if (FALUK.rows[q].style.display!="none") {
            nyit=FALUK.rows[q].cells[getOszlopNo("falunev")].getElementsByTagName("a")[0].getAttribute("href");
            nyit=nyit.replace("overview",OPENTYPE);
            window.open(nyit);
        }
    }
}catch(e){alert("Open_ERROR:"+e);}
return;
}

function iskivalaszt(ez){
	suti=getCookie("cnc_csoport");
	if (suti.split(";")[0]==ez) return 'style="background-color:brown"'; else return '';
}

function mentes(){
	var a=document.getElementById("production_table").rows;
	var oszl=getOszlopNo("falunev");
	var suti=getCookie("cnc_csoport");
	
	nev=prompt("Mi legyen ennek a falucsoportnak a neve?");
		if (nev==null) return;
		if (nev.search(";")>=0) {alert("A ; karakter nem megengedett, pont (.)-ra alakul át.");nev=nev.replace(";",".");}
		if (nev.search(",")>=0) {alert("A , karakter nem megengedett, pont (.)-ra alakul át.");nev=nev.replace(",",".");}
		if (nev.search("\"")>=0) {alert("A \" karakter nem megengedett, törlődik.");nev=nev.replace("\"","");}
        if (nev.length<1) {alert("A csoport neve nem lehet üres");return;}
	/*Duplikáció?*/
	Fsuti=suti.split(";");
	for (var i=4;i<Fsuti.length;i++){ if (Fsuti[i].indexOf(",")>=0) if(Fsuti[i].split(",")[0]==nev) {alert("Ilyen nevű csoport már létezik"); return;}}
	
	var str=";"+nev;
	for (var i=1;i<a.length;i++){
		CHECK2=a[i];
		if (CHECK2.style.display!="none") { 
			var koord=CHECK2.cells[oszl].innerText.match(/[0-9]+(\|)[0-9]+/g);
			str+=","+koord[koord.length-1]; }
	}
	/*if (str.indexOf(",")==-1) {alert("Üres csoportot nem lehet lementeni"); return;}*/
	suti+=str;
	setCookie("cnc_csoport",suti);
	frissit();
	return;
}

function szinez(){ try{
	oszl=getOszlopNo("falunev");
	var a=document.getElementById("production_table").rows;
	var szinek=new Array("black","maroon","green","olive","navy","purple","teal","gray","silver","red","lime","yellow","blue","fuchsia","aqua","white");
	rnd=Math.floor((Math.random()*16));
	szin=szinek[rnd]; var ures=true;
	for (var i=1;i<a.length;i++){
		CHECK2=a[i];
		if (CHECK2.style.display!="none") {
			ures=false;
			CHECK2.cells[oszl].style.backgroundColor=szin;
		}
	}
	if (ures){
		for (var i=1;i<a.length;i++){
			CHECK2=a[i];
			CHECK2.cells[oszl].setAttribute("style", "background-color:none;border:none;");
		}
	}
}catch(e){alert(e);}}

function szinez1(ez){ try{
	var szinek=new Array("","purple","yellow","black");
	var szinindex=szinek.indexOf(ez.parentNode.style.backgroundColor);
	szinindex++; if (szinindex>3) szinindex=0;
	ez.parentNode.style.backgroundColor=szinek[szinindex];
	return;
}catch(e){alert(e);}}

function toredezett(){try{
	suti=getCookie("cnc_csoport");
	sutiORIGINAL=suti;
	oszl=getOszlopNo("falunev");
	var table=document.getElementById("production_table").rows;
	sutiF=suti.split(";");
	faluk=new Array();
	for (var j=4;j<sutiF.length;j++){
		if (sutiF[j].indexOf(",")>=0){
			addon=sutiF[j].split(",");
			for (var k=1;k<addon.length;k++){
				faluk=faluk.concat(addon[k]);
			}
		}
	}
	
	var falukITT=new Array();
	for (var i=1;i<table.length;i++){
		koord=table[i].cells[oszl].innerText.match(/[0-9]+(\|)[0-9]+/g);
		falukITT=falukITT.concat(koord[koord.length-1]);
	}
	
	var ok=false; var str="";
	for (i=0;i<faluk.length;i++){
		ok=false;
		for (j=0;j<falukITT.length;j++){
			if (faluk[i]==falukITT[j]) {ok=true; break;}
		}
		if (!ok) {suti=suti.replace(","+faluk[i],""); str+=faluk[i]+", ";}
	}
	
	if (str=="") alert("Nincsenek olyan faluk a lementett csoportleosztásba, amik nem léteznek nálad!"); else 
	alert ("Egy vagy több falut kitöröltem a csoportleosztásból, mivel ilyenek nem léteznek:\n"+str+"\n\n Ha biztonsági mentést szeretne végezni a törlés előtt, mentse el az alábbi szöveget, melyet importáláskor később megadhat:\n"+sutiORIGINAL);
	
	setCookie("cnc_csoport",suti);
	return;
}catch(e){alert(e);}}

function roundNumber(num, dec) {
	var result = Math.round(num*Math.pow(10,dec))/Math.pow(10,dec);
	return result;
}

function politavolsag(){try{
	var X=document.getElementById("production_table").rows;
	var temp="";
	var Mero="";
	for (var i=1;i<X.length;i++){
		if (X[i].style.display!="none"){
			temp=X[i].cells[getOszlopNo("falunev")].innerText.match(/[0-9]+(\|)[0-9]+/g);
			Mero+=temp[temp.length-1]+" ";
		}
	}
	Mero=prompt("Mely falukhoz viszonyítva szeretnéd a távolságokat kiíratni?\n(A kiírt távolság a listában szereplő faluk közül a legközelebbihez lesz mérve.\nEzt a falut megnézheted, ha ráteszed az egered a távolságra.)",Mero);
	if (Mero==null || Mero=="") return;
	try{Mero=Mero.match(/[0-9]+(\|)[0-9]+/g); if (Mero.length<1) throw "error"; }catch(e){alert("Érvénytelen koordináta megadás."); return;}
	var vane=false;
	if (document.getElementById("tav")==undefined) vane=false; else vane=true;
	
	var prodtable=document.getElementById("production_table").rows;
	var min=-1; var temp=0; var minF=""; var RNum=0;
	for (var i=0;i<prodtable.length;i++){
		min=-1;
		if (!vane) var cell=prodtable[i].insertCell(getOszlopNo("falunev")+1); else var cell=prodtable[i].cells[getOszlopNo("tav")];
		if (i==0) {cell.innerHTML='<a href="javascript: tavrendez()"><b>Távolság</b></a>'; cell.setAttribute("id","tav");continue;}
		
		JFalu=prodtable[i].cells[getOszlopNo("falunev")].innerText.match(/[0-9]+(\|)[0-9]+/g);
		JFalu=JFalu[JFalu.length-1].split("|");
		for (var j=0;j<Mero.length;j++){
			temp=roundNumber(Math.abs(Math.sqrt(Math.pow(Mero[j].split("|")[0]-JFalu[0],2)+Math.pow(Mero[j].split("|")[1]-JFalu[1],2))),2);
			if (temp<min || min==-1) {min=temp; minF=Mero[j];}
		}
		cell.innerHTML=min;
		var ut_l=min*(1/SPEED)*(1/UNITS)*18;
		var ut_k=min*(1/SPEED)*(1/UNITS)*22;
		var ut_kem=min*(1/SPEED)*(1/UNITS)*9;
		var ut_kl=min*(1/SPEED)*(1/UNITS)*10;
		var ut_nl=min*(1/SPEED)*(1/UNITS)*11;
		var ut_kos=min*(1/SPEED)*(1/UNITS)*30;
		var ut_fn=min*(1/SPEED)*(1/UNITS)*35;		
		cell.setAttribute("title","Távolság_Időben_(óra:perc)\nLándzsás:\t"+parseInt(ut_l/60)+":"+(parseInt(ut_l) % 60)+"\nKardforgató:\t"+parseInt(ut_k/60)+":"+(parseInt(ut_k) % 60)+"\nFelderítő:\t"+parseInt(ut_kem/60)+":"+(parseInt(ut_kem) % 60)+"\nKönnyűlovas:\t"+parseInt(ut_kl/60)+":"+(parseInt(ut_kl) % 60)+"\nNehézlovas:\t"+parseInt(ut_nl/60)+":"+(parseInt(ut_nl) % 60)+"\nKos:\t\t"+parseInt(ut_kos/60)+":"+(parseInt(ut_kos) % 60)+"\nFőnemes:\t"+parseInt(ut_fn/60)+":"+(parseInt(ut_fn) % 60)+"\n"); /*<--------*/
	}
	return;
}catch(e){alert(e);}}

function tavolsag(){try{
	var Mero=prompt("Melyik faluhoz viszonyítva szeretnéd a távolságokat kiíratni?",game_data["village"]["coord"]);
	if (Mero==null || Mero=="") return;
	try{Mero=Mero.match(/[0-9]+(\|)[0-9]+/g)[0].split("|");}catch(e){alert("Érvénytelen koordináta megadás."); return;}
	var vane=false;
	if (document.getElementById("tav")==undefined) vane=false; else vane=true;
	
	var prodtable=document.getElementById("production_table").rows;
	for (var i=0;i<prodtable.length;i++){
		if (!vane) var cell=prodtable[i].insertCell(getOszlopNo("falunev")+1); else var cell=prodtable[i].cells[getOszlopNo("tav")];
		if (i==0) {cell.innerHTML='<a href="javascript: tavrendez()"><b>Távolság</b></a>'; cell.setAttribute("id","tav");continue;}
		
		JFalu=prodtable[i].cells[getOszlopNo("falunev")].innerText.match(/[0-9]+(\|)[0-9]+/g);
		JFalu=JFalu[JFalu.length-1].split("|");
		
		var min=roundNumber(Math.abs(Math.sqrt(Math.pow(Mero[0]-JFalu[0],2)+Math.pow(Mero[1]-JFalu[1],2))),2);
		cell.innerHTML=min;		
		var ut_l=min*(1/SPEED)*(1/UNITS)*18;
		var ut_k=min*(1/SPEED)*(1/UNITS)*22;
		var ut_kem=min*(1/SPEED)*(1/UNITS)*9;
		var ut_kl=min*(1/SPEED)*(1/UNITS)*10;
		var ut_nl=min*(1/SPEED)*(1/UNITS)*11;
		var ut_kos=min*(1/SPEED)*(1/UNITS)*30;
		var ut_fn=min*(1/SPEED)*(1/UNITS)*35;		
		cell.setAttribute("title","Távolság_Időben_(óra:perc)\nLándzsás:\t"+parseInt(ut_l/60)+":"+(parseInt(ut_l) % 60)+"\nKardforgató:\t"+parseInt(ut_k/60)+":"+(parseInt(ut_k) % 60)+"\nFelderítő:\t"+parseInt(ut_kem/60)+":"+(parseInt(ut_kem) % 60)+"\nKönnyűlovas:\t"+parseInt(ut_kl/60)+":"+(parseInt(ut_kl) % 60)+"\nNehézlovas:\t"+parseInt(ut_nl/60)+":"+(parseInt(ut_nl) % 60)+"\nKos:\t\t"+parseInt(ut_kos/60)+":"+(parseInt(ut_kos) % 60)+"\nFőnemes:\t"+parseInt(ut_fn/60)+":"+(parseInt(ut_fn) % 60)+"\n"); /*<--------*/
	}
	return;
}catch(e){alert(e);}}

function tavrendez(bool){try{
	var prodtable=document.getElementById("production_table").rows;
	var tavok=new Array(); var sorok=new Array(); var indexek=new Array();
	for (var i=1;i<prodtable.length;i++){
		tavok[i-1]=parseFloat(prodtable[i].cells[getOszlopNo("tav")].innerText);
		sorok[i-1]=prodtable[i];
		indexek[i-1]=i-1;
	}
	for (var i=0;i<tavok.length;i++){
		var min=i;
		for (var j=i;j<tavok.length;j++){
			if (bool) {if (tavok[j]>tavok[min]) min=j;}
			else {if (tavok[j]<tavok[min]) min=j;}
		}
		var Ttemp=tavok[i];
		tavok[i]=tavok[min];
		tavok[min]=Ttemp;
		
		var Ttemp=indexek[i];
		indexek[i]=indexek[min];
		indexek[min]=Ttemp;
		
	}
	
	for (var i=prodtable.length-1;i>0;i--){
		document.getElementById("production_table").deleteRow(i);
	}
	
	for (var i=0;i<tavok.length;i++){
		document.getElementById("production_table").appendChild(sorok[indexek[i]]);
	}
	if (bool)
		document.getElementById("tav").getElementsByTagName("a")[0].setAttribute("href","javascript: tavrendez(false);");
	else
		document.getElementById("tav").getElementsByTagName("a")[0].setAttribute("href","javascript: tavrendez(true);");
}catch(e){alert("Hiba rendezéskor:\n"+e);}}

function falulista_export(tipus){try{
	var X=document.getElementById("production_table").rows;
	var temp="";
	var str="";var hely=document.getElementById("uzi");
	str='<p align="right"><input type="button" onclick=falulista_export("disable") value="X"></p><textarea cols="40" rows="20" onclick="this.select()" onmouseover="this.select()">';
	if (tipus=="disable") {$( "#uzi" ).hide(); return;}
	for (var i=1;i<X.length;i++){
		if (X[i].style.display!="none"){
			temp=X[i].cells[0].innerText.match(/[0-9]+(\|)[0-9]+/g);
			switch (tipus){
				case "BB": str+="[coord]"+temp[temp.length-1]+"[/coord]\n"; break;
				case "ujsor": str+=temp[temp.length-1]+"\n"; break;
				case "egysor": str+=temp[temp.length-1]+" "; break;
			}
		}
	}
	str+="</textarea>";
	hely.innerHTML=str;
	$( "#uzi" ).show();}catch(e){alert(e);}
}

function falulista_import(){try{
	var be_Adat=prompt("Add meg a falulistát, amit szeretnél látni.\nElválasztás nem számít");
	if (be_Adat==null || be_Adat=="" || be_Adat.search(/[0-9]+(\|)[0-9]+/g)==-1) return;
	be_Adat=be_Adat.match(/[0-9]+(\|)[0-9]+/g);
	var a=document.getElementById("production_table").rows;
	var oszl=getOszlopNo("falunev"); var uj=false;
	for (var i=1;i<a.length;i++){
		var CHECK2=a[i];
		var nev = $.trim(CHECK2.cells[oszl].innerText).match(/[0-9]+(\|)[0-9]+/g); nev=nev[nev.length-1];
		if (CHECK2.style.display!="none") regi=true; else regi=false;
		uj=false;
		for (var j=0;j<be_Adat.length;j++){
			if (be_Adat[j]==nev) {uj=true; break;}
		}
		if (halmaz(regi,uj)) CHECK2.setAttribute("style","display:line"); else CHECK2.setAttribute("style","display:none");
	}
}catch(e){alert(e);}}

function kivag(){try{
	var X=document.getElementById("production_table").rows;
	for (var i=X.length-1;i>0;i--){
		if (X[i].style.display=="none") document.getElementById("production_table").deleteRow(i);
	}
	return;
}catch(e){alert(e);}}

function load(){
	$.getScript('http://cncdani2.freeiz.com/script/csoportkieg.php');
}
function szoveg(szovID){
	switch (szovID){
		case "sz1": return "Nyersanyag különbségek";
		case "sz2": return "Összes nyersanyag";
		default: return "Unknow string";
	}
	return;
}

try{
suti=getCookie("cnc_csoport");
if (suti==null || suti=="" ) {alert("Nem érzékeltem lementett csoportleosztást."); setCookie("cnc_csoport","overview;23000;80;8500");}
suti=getCookie("cnc_csoport");
if (suti.split(";").length<4) {alert("Az értékelt csoportfelosztás szerkezetileg helytelen:\n"+suti+"\n\nEz a lementés törlésre kerül, és új generálódik."); setCookie("cnc_csoport","overview;23000;80;8500");}
var KIVALASZTOTT=""; var OPENTYPE=suti.split(";")[0]; var ISHALMAZ="";
}catch(e){}
try{
var gazdasag=document.getElementById("production_table").rows[0].cells[0];
gazdasag.innerHTML='<a href="javascript:load();"><img width=30px" onclick="javascript: $(this).hide();" title="Gazdasági nézet: Nyerskülönbségek és diagramok" src="http://cncdani2.freeiz.com/pic/script_csoport/gazd.png"></a>'+gazdasag.innerHTML;
document.getElementById("production_table").rows[0].cells[0].setAttribute("id","falunev"); /*Nézet módosítása után is tudunk hivatkozni a csoportokra*/
document.getElementById("production_table").rows[0].cells[1].setAttribute("id","pont");
document.getElementById("production_table").rows[0].cells[2].setAttribute("id","nyers");
document.getElementById("production_table").rows[0].cells[3].setAttribute("id","raktar");
document.getElementById("production_table").rows[0].cells[4].setAttribute("id","tanya");
}catch(e){alert("Hoppaaaa\n"+e);}

try{
	document.getElementsByTagName("body")[0].innerHTML+='<div id="uzi" style="display: none; width: 300px; background-color: #60302b; color: yellow; position: absolute; left:30%; top:30%; border:3px solid black; padding: 10px; z-index:10;"></div>';
    newNode=document.createElement("csoportok");
    x=document.getElementById("content_value");
    x.insertBefore(newNode,x.firstChild);
    x.childNodes[0].innerHTML=' <table><tr><td id="tools" width="200px"></td><td style="border: 1px solid black" id="defaults" width="200px">\
	<b><u>Alap\u00E9rtelmezett csoportok</u></b><br><br><a href=\'javascript: Dcsoport("ossz")\' title="Összes falu megjelenítése">Összes</a>&nbsp;&nbsp;\
	<a href=\'javascript: Dcsoport("tanya")\' title="Tanya lakosság alapján való szűkítés">Tanya</a><img onclick=mod(1) id="D_tanya" title="" src="'+pic("e_modify")+'">&nbsp;&nbsp;\
	<a href=\'javascript: Dcsoport("raktar")\' title="Raktár telítettsége alapján való szűkítés (legnagyobb értékű nyersanyag alapján)">Raktár</a><img onclick=mod(2) id="D_raktar" title="" src="'+pic("e_modify")+'">&nbsp;&nbsp;\
	<a href=\'javascript: Dcsoport("pont")\' title="Pontérték alapján való listaszűkítés"\'>Pont</a><img onclick=mod(3) id="D_pont" title="" src="'+pic("e_modify")+'">&nbsp;&nbsp;\
	<a href=\'javascript: Dcsoport("tamad")\'><img title="Támadás alatt áll faluk kilistázása" src="'+picT("att")+'"></a>&nbsp;&nbsp;\
	<a href=\'javascript: Dcsoport("regexp")\' title="Reguláris kifejezéssel megadott listaszűkítés">RegExp</a>&nbsp;&nbsp;\
	<a href=\'javascript: Dcsoport("headtail")\' title="Első/utolsó X falu listázása">Fej/Láb</a>\
	</td><td id="group"></td></tr></table>';
    var T=document.getElementById("tools");
    var D=document.getElementById("defaults");
    var G=document.getElementById("group");

     T.innerHTML='<a href=\'javascript: megnyit();\'><img src="'+pic("2_all")+'" title="Minden falu megnyitása"></a>\n\
        	<img src="'+picT("barracks")+'"	title="Kiképzések megnyitása"/ '+iskivalaszt("train")+' onclick=ModOpenType(this,"train")>\n\
			<img src="'+picT("farm")+'"		title="Áttekintések megnyitása"/ '+iskivalaszt("overview")+' onclick=ModOpenType(this,"overview")>\n\
			<img src="'+picT("market")+'"	title="Piacok megnyitása"/ '+iskivalaszt("market")+' onclick=ModOpenType(this,"market")>\n\
			<img src="'+picT("main")+'"		title="F\u0151hadiszállások megnyitása"/ '+iskivalaszt("main")+' onclick=ModOpenType(this,"main")>\n\
			<img src="'+picT("snob")+'"		title="Akadémiák megnyitása"/ '+iskivalaszt("snob")+' onclick=ModOpenType(this,"snob")>\n\
            <img src="'+picT("place")+'"	title="Gyülekez\u0151helyek/parancsok megnyitása"/ '+iskivalaszt("place")+' onclick=ModOpenType(this,"place")>\n\
			<img src="'+picT("place")+'"	title="Gyülekez\u0151helyek/sereg megnyitása"/ '+iskivalaszt("place&mode=units")+' onclick=ModOpenType(this,"place&mode=units")>\n\
			<img src="'+pic("flag")+'"	title="Zászlók helyének megnyitása"/ '+iskivalaszt("flags")+' onclick=ModOpenType(this,"flags")>\n\
			<br><hr>\
			<img src="'+pic("metszet")+'" onclick=sethalmaz("metszet") title="Metszetképzés. A következőleg kiválasztott csoportból csak azon faluk fognak szerepelni, amik most is láthatóak.">\
			<img src="'+pic("unio")+'" onclick=sethalmaz("unio") title="Unióképzés. A jelenlegi listához hozzáadja a következőleg kiválasztott csoport faluit.">\
			<img src="'+pic("kulonbseg")+'" onclick=sethalmaz("kulonbseg") title="Különbségképzés. A jelenlegi listából kiveszi a következőleg kiválasztott lista faluit.">\
			<img src="'+pic("negalt")+'" onclick=sethalmaz("negalt") title="Negációképzés. A jelenleg látott listát megfordítja.">\
			<img src="'+pic("2_separator")+'">\n\
			<img src="'+pic("tavolsag")+'" onclick="tavolsag()" title="Egy megadott faluhoz mért távolságokat számít.">\
			<img src="'+pic("politavolsag")+'" onclick="politavolsag(true)" title="Több faluhoz mért távolságokat számít.">\
			<br>\
			<a href=\'javascript: ujcsoport();\'><img src="'+pic("uj")+'" title="Új csoport felvétele"></a>\n\
			<a href=\'javascript: if (KIVALASZTOTT!="") szerkeszt();\'><img src="'+pic("szerk")+'" title="Kiválasztott csoport szerkesztése"></a>\n\
			<a href=\'javascript: atnevez();\'><img src="'+pic("2_rename")+'" title="Kiválasztott csoport átnevezése"></a>\n\
			<a href=\'javascript: torol();\'><img src="'+pic("2_delete")+'" title="Kiválasztott csoport törlése"></a>\n\
			<img src="'+pic("2_separator")+'">\n\
			<a href=\'javascript: mentes();\'><img src="'+pic("save")+'" title="Jelenleg látott lista csoportba mentése"></a>\n\
			<a href=\'javascript: szinez();\'><img src="'+pic("colorize")+'" title="Jelenleg látott lista színezése véletlenszerű színnel"></a>\n\
			<a href=\'javascript: kivag();\'><img src="'+pic("cut_16")+'" title="A jelenleg nem látott falukat törli az oldal listájából, így semmi más nem fogja ezentúl látni azokat! (Az adatok nem törlődnek)"></a>\n\
			<br>\
            <a href=\'javascript: manager("exp");\'><img src="'+pic("2_exp")+'" title="Adatok Exportálása"></a>\n\
            <a href=\'javascript: manager("imp");\'><img src="'+pic("2_imp")+'" title="Adatok importálása"></a>\n\
            <a href=\'javascript: manager("del");\'><img src="'+pic("2_delall")+'" title="ADATMEGSEMMISÍTÉS (minden elvész)"></a>\n\
			<img src="'+pic("2_separator")+'">\n\
			<a href=\'javascript: toredezett();\'><img src="'+pic("defrag")+'" title="Adategyeztetés: olyan faluk törlése a csoportod lementéséből, melyek nem léteznek (mert pl. elfoglalták)"></a>';
	document.getElementById("production_table").rows[0].cells[0].innerHTML+=' Export &rarr; <a href="javascript: falulista_export(\'BB\');">BB</a>|<a href="javascript: falulista_export(\'ujsor\');">Soronként</a>|<a href="javascript: falulista_export(\'egysor\');">Egy sorba</a>. <a href="javascript: falulista_import()">Import</a>';
	
	
	var FalukT=document.getElementById("production_table");
    for (var i=1;i<FalukT.rows.length;i++){
    	Seged=FalukT.rows[i].cells[0].innerHTML;
    	FalukT.rows[i].cells[0].innerHTML='<input type="checkbox" style="display:none">'+'<img onclick="szinez1(this)" src="'+pic("pin")+'" alt="pin it">'+Seged;
    }
	
	try{
	var BASE_URL=document.location.href.split("game.php")[0];
	var CONFIG=loadXMLDoc(BASE_URL+"interface.php?func=get_config");
	var ARCHERS=CONFIG.getElementsByTagName("archer")[0].textContent; if (ARCHERS=="0") ARCHERS=false; else ARCHERS=true;
	var SPEED=CONFIG.getElementsByTagName("speed")[0].textContent;
	var UNITS=CONFIG.getElementsByTagName("unit_speed")[0].textContent;
	}catch(e){alert(e);}
	
	frissit();
	/*document.getElementById("production_table").;*/
} catch(e){alert("Hiba indításkor \n"+e);}	


$(document).ready(function(){
$(function() {
        $( "#uzi" ).draggable();
});
$(":checkbox").change(function(){
    try{
		var Oszlop=getOszlopNo("falunev");
		var ThisOszlop=$(this).parent().children().index($(this));
		if (KIVALASZTOTT!="" && Oszlop==ThisOszlop){
			koord=this.parentNode.innerText.match(/[0-9]+(\|)[0-9]+/g);
			koord=koord[koord.length-1];
			addFalu(koord);
		}
    } catch(e){alert("Hiba bejelöléskor\n"+e);}
});
});

void(0);