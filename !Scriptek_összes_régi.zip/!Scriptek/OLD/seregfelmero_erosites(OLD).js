javascript: 
if (document.location.href.indexOf("screen=overview_villages") == -1) {
    alert("Ez a script az �ttekint�sben fut le csak.\n\nPr�miumosoknak el�sz�r �ttekint�s �talak�t� futtat�s�ra van sz�ks�g a Termel�i n�zetbe!");
    exit(0);
}
RefArray = new Array();
WAIT = new Array(0, 0, 0, 0, 0);
FALUK = new Array();
init();
var LAP = 0;
var BASE_URL = document.location.href.split("game.php")[0];
eloszto();

function init() {
    try {
        try { /*PF-Area*/
            var PFA = document.getElementById("production_table");
            if (PFA.rows[0].cells.length > 5) {
                for (i = 0; i < PFA.rows.length; i++) {
                    PFA.rows[i].deleteCell(9);
                    PFA.rows[i].deleteCell(8);
                    PFA.rows[i].deleteCell(7);
                    PFA.rows[i].deleteCell(5);
                    PFA.rows[i].deleteCell(0);
                }
            }
        } catch (e) {
            alert("PF -> Nem-PF konverzi�s hiba:\n" + e);
        }
        for (var i = 1; i < PFA.rows.length; i++) {
            FALUK[i - 1] = parseInt(PFA.rows[i].cells[0].getElementsByTagName("span")[0].getAttribute("id").match(/[0-9]+/g)[0]);
        }
        document.getElementsByTagName("body")[0].innerHTML = '<h1>C&C M�hely - Anti megv�lt� / Er�s�t�s felm�r�</h1><br><br><b>N�zet:</b> <a href="javascript: rejt(0)">Minden r�szlet</a> | <a href="javascript: rejt(1)">Csak n�v �s koordin�ta</a> | <a href="javascript: rejt(2)">Csak n�v</a>';
    } catch (e) {
        alert(e);
    }
}

function rejt(tipus) {
    try {
        if (tipus == 0) {
            $(".reszlet").css("display", "block");
            $(".faluk").css("display", "block");
        }
        if (tipus == 1) {
            $(".reszlet").css("display", "none");
            $(".faluk").css("display", "block");
        }
        if (tipus == 2) {
            $(".reszlet").css("display", "none");
            $(".faluk").css("display", "none");
        }
    } catch (e) {
        alert("Hiba rejt�skor:\n" + e);
    }
}

function recalc() {
    try {
        alert("v�ge"); /*J�t�kosokn�l l�v�*/
        var XX = document.getElementsByTagName("div");
        var sereg = new Array();
        var sereg2 = new Array();
        for (var i = 0; i < XX.length; i++) { /*j�t�kosok. Minden i-n�l �j sereg t�mb!*/
            var alXX = XX[i].getElementsByTagName("table");
            for (var j = 0; j < alXX.length; j++) { /*Minden falun...*/
                for (var k = 1; k < alXX[j].rows.length; k++) { /*A falu minden sor�n*/
                    for (var l = 2; l < alXX[j].rows[k].cells.length - 1; l++) { /*...�s minden oszlop�n :D*/
                        if (j == 0 && k == 1) { /*sereg t�mb inicializ�l�sa*/
                            sereg[l - 2] = parseInt(alXX[j].rows[k].cells[l].innerText.match(/[0-9]+/g));
                        } else {
                            sereg[l - 2] += parseInt(alXX[j].rows[k].cells[l].innerText.match(/[0-9]+/g));
                        }
                        if (k == 1) {
                            sereg2[l - 2] = parseInt(alXX[j].rows[k].cells[l].innerText.match(/[0-9]+/g));
                        } else {
                            sereg2[l - 2] += parseInt(alXX[j].rows[k].cells[l].innerText.match(/[0-9]+/g));
                        }
                    }
                }
                alXX[j].rows[0].cells[1].innerHTML = sereg2;
            }
            XX[i].getElementsByTagName("p")[0].innerHTML = " " + sereg;
        }
    } catch (e) {
        alert("Hiba �jrasz�m�t�skor:\n" + e);
    }
}

function szamol(P_IND, sorsz) {
    try {
        if ((WAIT[P_IND] == 4) && RefArray[P_IND].document.getElementById("serverTime")) {
            FALUK[sorsz] = 0;
            return true;
        }
        var XX = RefArray[P_IND].document.getElementById("units_away").rows;
        for (var i = 1; i < XX.length - 1; i++) {
            try {
                var darabka = XX[i].cells[1].innerText.match(/\([^\(]+\)/g);
                var nev = darabka[darabka.length - 2].replace("(", "").replace(")", "");
                var vill = darabka[darabka.length - 1].replace("(", "").replace(")", "");
                var aaa = XX[i].cells.length - 2;
                if (document.getElementById(nev)) {
                    if (document.getElementById(vill)) { /*Beilleszteni a sort a vill ID al�;*/
                        document.getElementById(vill).innerHTML += '<tr class="reszlet">' + XX[i].innerHTML + '</tr>';
                    } else { /*#nev-hez �j t�bla #vill ID-vel*/
                        document.getElementById(nev).innerHTML += '<table id="' + vill + '" class="faluk" style="margin: 0px 0px 0px 10px"><tr><td colspan="2"> - [coord]' + vill + '[/coord]</td><td colspan="' + aaa + '" style="text-align: left"></td></tr><tr class="reszlet">' + XX[i].innerHTML + '</tr></table>'; /*+margin*/
                    }
                } else { /*Kieg. �j div: #nev*/
                    document.getElementsByTagName("body")[0].innerHTML += '<br><br><div id="' + nev + '">[player]' + nev + '[/player]<p style="display:inline" class="sereg"></p><br><br><table id="' + vill + '" class="faluk" style="margin: 0px 0px 0px 10px"><tr><td colspan="2"> - [coord]' + vill + '[/coord]</td><td colspan="' + aaa + '" style="text-align: left"></td></tr><tr class="reszlet">' + XX[i].innerHTML + '</tr></table></div>';
                }
            } catch (e) {}
        }
        FALUK[sorsz] = 0;
        return true;
    } catch (e) {}
    return false;
}

function eloszto() {
    try {
        var nextindex = -1;
        for (var i = 0; i < FALUK.length; i++) {
            if (FALUK[i] != 0) {
                nextindex = i;
                break;
            }
        }
        if (nextindex == -1) {
            recalc();
            return;
        }
        if ((RefArray[LAP] == undefined) || (RefArray[LAP].closed) || (RefArray[LAP].location.href.indexOf("screen=place&mode=units") == -1) || (WAIT[LAP] == 0)) {
            RefArray[LAP] = window.open(BASE_URL + "game.php?village=" + FALUK[nextindex] + "&screen=place&mode=units", "ero" + LAP);
        }
        if (szamol(LAP, nextindex)) { /*RefArray[LAP]=window.open(BASE_URL+"game.php?village="+FALUK[nextindex]+"&screen=place&mode=units","ero"+LAP); */
            WAIT[LAP] = 0;
        } else {
            WAIT[LAP]++;
            if (WAIT[LAP] > 4) {
                RefArray[LAP].window.close();
                WAIT[LAP] = 0;
            }
        }
    } catch (e) {
        alert(e);
    }
    setTimeout("eloszto()", 1000);
    return;
}

void(0);