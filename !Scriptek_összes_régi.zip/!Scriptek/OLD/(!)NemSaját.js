javascript:
var coords = '549|756 549|756';
var units = { spear: 5, sword: 5, axe: 0, archer: 0, spy: 0, light: 0, marcher: 0, heavy: 0, ram: 0, catapult: 0, knight: 0, snob: 0 };
var type = 'attack';

(function () {
	function c() {
		var a = coords.split(" "),
			f = false,
			b = Number(ls.autofarm) || 0, g, h, i, d, j;
		b = b >= a.length ? 0 : b; a = a[b].split("|");
		g = $.extend(units, { attack: type === "attack", support: type === "support", x: a[0], y: a[1] });
		$.post("game.php?village=" + k + "&screen=place&try=confirm" + l, g, function (e)
					{
					if (h = $("#error", e).text()) {
						j = $("#_error").html(h);
						setTimeout(function () { j.empty(); }, 10000);
						$(".unitsInput", e).each(function () {
								i = runit.exec(this.id)[0];
								if (units[i] < Number(rnum.exec($(this).next().text())[0])) { f = true; return false; }
								});
					} else {
						d = $("form:first", e);
						$.post(d.attr("action"), d.serialize());
						$("#attacks").text(ls.autofarmAttacks = Number(ls.autofarmAttacks || 0) + 1);
						$("#last-coord").text(ls.autofarmLast = a.join("|")); ls.autofarm = ++b;
					}
		f ? setTimeout(function () { c(); }, 10000) : c(); });
	}
	document.getElementById("d") || $("body").append("<div id=\"d\"><div id=\"h\"><span>Auto attack script</span><span id=\"o\"></span></div><div id=\"c\"><h1>Attacks</h1><div class=\"b\"><span>Last coord attacked: <b id=\"last-coord\"></b></span><span>Total number of attacks sent: <b id=\"attacks\"></b></span><span id=\"_error\" style=\"color:red\"/></div><h1>Informations</h1><div class=\"b\"><span>Actual version: <b>v1.1.1</b></span></div></div><style>#d{background:#c1d9ff;border:1px solid #3a5774;font-family:arial;padding:4px;width:19em;margin:auto;position:absolute;left:75%;top:30%;z-index:999999}#h{background:#e0edfe;font-size:14px;font-weight:700;padding:4px 20px 4px 10px;cursor:move}#o{background:url(http://www.gstatic.com/analytics/iyp/iyp_close_dialog.gif) no-repeat scroll center center transparent;cursor:pointer;height:15px;position:absolute;right:10px;top:8px;width:15px}#c{background:#fff;font-size:12px}.b{padding:5px}#d #c span{display:block}#d h1{background:none repeat scroll 0 0 #e4e4e4;border-bottom:1px solid #c4c4c4;border-top:1px solid #fff;font-size:13px;line-height:20px;margin:0;outline:medium none;padding:0 4px}code{font-size:11px;display:block;color:#800}</style></div>");
	$("#d").draggable({ containment: "html", handle: "#h" });
	$("#o").click(function () { $("#c").slideToggle(200); });
	game_data.player.ally_id === "220" && game_data.world === "br35" && $("#c").prepend("<h1 style=\"color:red\">Salve |TSN| :D</h1>");
	var m = $(".b:last, #c h1:last").hide(),
		k = game_data.village.id,
		l = game_data.player.sitter_id === "0" ? "" : "&t=" + game_data.player.id;
	runit = /[a-z]+$/;
	rnum = /\d+/;
	ls = localStorage;
	isupdate = true;
	$("#last-coord").text(ls.autofarmLast || "nenhuma");
	$("#attacks").text(ls.autofarmAttacks || 0);
	if (typeof type === "undefined") { isupdate = false; m.show();}
	isupdate && c(); })();