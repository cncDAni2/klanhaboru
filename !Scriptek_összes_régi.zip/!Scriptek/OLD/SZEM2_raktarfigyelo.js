javascript: 
function res_check(){
	try{
	for (rf=1;rf<11;rf++){
		if (document.getElementById(rf).innerHTML!=""){
			var lapref=window["lap"+rf];
			var fa=lapref.document.getElementById("wood").innerHTML; fa=parseInt(fa);
			var agyag=lapref.document.getElementById("stone").innerHTML; agyag=parseInt(agyag);
			var vas=lapref.document.getElementById("iron").innerHTML; vas=parseInt(vas);
			var kapac=lapref.document.getElementById("storage").innerHTML; kapac=parseInt(kapac);
			var max=Math.max(fa,agyag,vas);
			if (Math.round(kapac*0.85)<=max) {
				if (kapac==max) {
					naplo("Rakt�rfigyel�: <b>Beltelt a rakt�r</b>");
					window.location="http://cncdani2.freeiz.com/hang/Narrator_nyers_full.wav";
				} else {
					window.location="http://cncdani2.freeiz.com/hang/Narrator_nyers_krit.wav";				
				}
	}}}}catch (e) {naplo("Rakt�rfigyel�: Hiba: "+e);}
}
	
function raktarf(){
		res_check();
		iraktarf=setTimeout("raktarf()",1000*60*2);
	}
document.getElementById('kieg').innerHTML+='<tr><td>Rakt�rfigyel�</td><td><a href=\'javascript: stop("raktarf");\'>Le�ll�t�s</a></td></tr>';
document.getElementById("naplo").innerHTML+="<tr><td>"+Date()+"</td><td><b>�j kieg�sz�t�</b> �rz�kelve: Rakt�rfigyel�</td></tr>";
raktarf();	 
void(0);	
