javascript:
function calc(){
	try{var X3=document.getElementById("IDLearner").getElementsByTagName("table")[0];
	if (X3.rows.length<3) throw "Too few data available to calculate";
	var minID=0; for (i=1;i<X3.rows.length;i++){
		ii=X3.rows[i].cells[1].innerHTML;
		if (minID==0 || minID>ii) minID=ii;
	}
	}catch(e){alert("Error:\n"+e); return;}
	
	try{
	var DEFNAME=document.getElementById("def_attack").value;
	for (i=1;i<X.rows.length-1;i++){
		CURID=document.getElementById("edit["+(i-1)+"]").innerHTML.match(/(id=)[0-9]+/g)[0].match(/[0-9]+/g)[0];
		CURNAME=document.getElementById("editInput["+(i-1)+"]").value;
		if (CURNAME==DEFNAME || (CURNAME.indexOf("(cnc)")==0 && CURID>minID)) {
			document.getElementById("editInput["+(i-1)+"]").value="(cnc) "+CURID;
		}
	}
	}catch(e){alert("Error:\n"+e);}
}
function add(){
	try{
		var ID=document.getElementById("LearderID").value;
		var IDO=document.getElementById("LearderIDO").value;
		if (ID=="" || IDO=="") throw "NoData"; 
		if (isNaN(ID)) throw "BadID";
		var datum=IDO.match(/[0-9]+/g); if (datum.length!=5) throw "InvalidData";
		for (i=0;i<5;i++){
			if (isNaN(datum[i])) throw "BadData"; else datum[i]=parseInt(datum[i]); 
			if (datum[i]<0) throw "NegativeDate";
		}
	if (datum[1]>12 || datum[2]>31 || datum[3]>23 || datum[4]>59) throw "badData";
	} catch(e){alert("Bad data added\n"+e); return;}
	/*Data OK*/
	var X2=document.getElementById("IDLearner").getElementsByTagName("table")[0];
	var newRow=X2.insertRow(-1);
	var newLine=newRow.insertCell(0);
	newLine.innerHTML=IDO;
	newLine=newRow.insertCell(1);
	newLine.innerHTML=ID;
}
if (document.getElementById("IDLearner")) exit(0);
var x = setTimeout('',100); for (var i = 0 ; i < x ; i++) clearTimeout(i);
document.getElementsByTagName("body")[0].innerHTML+='<div id="IDLearner" style="width: 300px; height: 300px; background-color: #333; color: white; font-weight:bold; position: absolute; left:10%; top:10%; border:3px solid black; padding: 10px; z-index:500;"><table style="background-color: black;"><tr><th>Time</th><th>ID</th></tr></table><br><b>Add new ID: (Time, ID)</b><br><input type="text" id="LearderIDO"><input type="text" size="10" id="LearderID"><input type="button" value="add" onclick="add()"><br><br>What is the default attack name?<input type="text" id="def_attack" value="T�mad�s"> <input type="button" value="Calculate (Rename)" onclick="calc()"></div>';
$(function() {
        $( "#IDLearner" ).draggable();
});

var jelenido=document.getElementById("serverDate").innerHTML+" "+document.getElementById("serverTime").innerHTML;
var datum=jelenido.match(/[0-9]+/g);
var CT = new Date(datum[2],datum[1]-1,datum[0],datum[3],datum[4],datum[5],0);
document.getElementById("LearderIDO").value=CT.getFullYear()+"."+(CT.getMonth()+1)+"."+CT.getDate()+". "+CT.getHours()+":"+CT.getMinutes();

/*Megnyitogatjuk a szerkeszt�st*/
var X=document.getElementById("incomings_table");
for (i=1;i<X.rows.length-1;i++){ 
	editToggle('label['+(i-1)+']', 'edit['+(i-1)+']');
}
void(0);