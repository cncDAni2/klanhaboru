javascript:
function setCookie(name, value, expire) {
	document.cookie = name + "=" + escape(value)
	+ ((expire == null) ? "" : ("; expires=" + expire.toGMTString()));
}

function getCookie(Name){
	var search = Name + "=";
	if (document.cookie.length > 0) {
		offset = document.cookie.indexOf(search);
		if (offset != -1) {
			offset += search.length;
			end = document.cookie.indexOf(";", offset);
			if (end == -1) end = document.cookie.length;
			return unescape(document.cookie.substring(offset, end));
		}
	}
}
	
	var d=document;	
	if(window.frames.length>0) d=window.main.document;
	url=d.URL;
	if(url.indexOf('screen=place')==-1) {
		alert('Gy�l. helyen pr�b�ld...');
		exit(0);
	}
	
	VISITED = getCookie('visited');
	if (VISITED==null || VISITED=="") {
		alert("Nem szippantott�l m�g be adatokat! Haszn�ld a m�sik scriptet el�bb az adatok felvitel�hez!");
		exit("");
	}
	LEPES = getCookie('lepes');
	if (LEPES==null || LEPES=="") {
		LEPES=0;
	}
	
	LEPES = parseInt(LEPES);
	VISITED = parseInt(VISITED);
if (LEPES > VISITED){
		alert("K�rbe�rt�l! Ez volt az utols� falu.\n A script �jraindul...");
		expDate = new Date();
		expDate.setTime(expDate.getTime() - (100));
		setCookie('visited', 0, expDate);
		setCookie('lepes', 0, expDate);
		for (i=0;i<21;i++) {
			V="falu" + i;
			setCookie(V, 0, expDate);
		}		
		if (d.forms[0].name!='units') d.forms[0].submit.click();
		exit("");
	} else {
		expDate = new Date();
		expDate.setTime(expDate.getTime() + (60*1000));
		setCookie('visited', VISITED, expDate);
	}
	
	VALT = "falu" + LEPES;
	CSOMAG = getCookie(VALT);
	CSTOMB=CSOMAG.match(/[0-9]+/g);
if(d.forms[0].name=='units')
	{
	
	KL=Math.ceil(CSTOMB[0] / 80);
	d.forms[0].x.value=CSTOMB[1];
	d.forms[0].y.value=CSTOMB[2];
	d.forms[0].spy.value=1;
	d.forms[0].light.value=KL;
	d.forms[0].attack.click();
	LEPES++;
	expDate.setTime(expDate.getTime() + (60*1000));
	setCookie('lepes', LEPES, expDate);
	} else {
	d.forms[0].submit.click();
	}
	void(0);