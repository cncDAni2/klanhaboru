javascript:
try{ 
	var x=document.getElementById("production_table").rows; 
	var str=""; var temp=""; var oldal=document.location.href; if (oldal.indexOf("mode=prod")>0) pf=true; else pf=false;
	for (i=1;i<x.length;i++){
		M=x[i].cells[2].childNodes;
		fa=M[0].innerHTML.replace(/[^0-9]+/g,"");
		agyag=M[2].innerHTML.replace(/[^0-9]+/g,"");
		vas=M[4].innerHTML.replace(/[^0-9]+/g,"");

		if (pf) M=x[i].cells[5].innerHTML; else M=x[i].cells[4].innerHTML;
		tanya=M.split("/");
		falunev=x[i].cells[0].textContent; falunev=$.trim(falunev);
		str+=falunev+"\t"+fa+"\t"+agyag+"\t"+vas+"\t"+tanya[0]+"\t"+tanya[1]+"\n";
	}
	alert("Az al�bbi sz�veget illessze be a Gazdas�g analiz�torba. \n"+str);
} catch(e){alert(e);}