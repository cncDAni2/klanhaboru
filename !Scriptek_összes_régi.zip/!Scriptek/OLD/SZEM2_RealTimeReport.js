javascript:
document.getElementById('kieg').innerHTML+='<tr><td>VI Jelent�s Elemz�<\/td><td><a href=\'javascript: stop("VIJE");\'>Le�ll�t�s</a></td></tr>';
naplo("<b>�j kieg�sz�t�</b> �rz�kelve: Val�s Idej� Jelent�s Elemz�");

function jelkeres(VIJE_REF){
	try{
	VIJE_table=VIJE_REF.document.getElementById("report_list");
	var i=1; var Vtalal=false;
	var VIJE_ik = new Array (); var k=0;
	while (VIJE_table.rows[i]!=undefined){
		if (VIJE_table.rows[i].cells[0].lastChild.textContent.search(/\(�j\)/g)>=0) {
			VIJE_ik[k]=i; 
			k++;
			Vtalal=true;
		}
		i++;
	} if(!Vtalal) return false;
	var j=0; var OK=false;
	while (!OK && j<VIJE_ik.length){
		Falu=VIJE_table.rows[VIJE_ik[j]].cells[0].textContent.match(/[0-9]+(\|)[0-9]+/g);
		VIJE_koord=Falu[Falu.length-1];
		var V_i=-1; while (!OK && V_i<=10){
			var V_k=0;
			V_i++;
			if (document.getElementById(V_i+"_T")){
			while (!OK && document.getElementById(V_i+"_T").rows[V_k]){
				if (document.getElementById(V_i+"_T").rows[V_k].cells[1].innerHTML==VIJE_koord) OK=true; else V_k++;
			}}
		}
		j++;
	}
	j--;
	 if (OK) {
		var szin=VIJE_REF.document.getElementById("report_list").rows[VIJE_ik[j]].cells[0].getElementsByTagName("img")[0].getAttribute("src").match(/\/[a-z_A-Z]+\.png/g)[0];
		szin=szin.replace("/",""); szin=szin.replace(".png","");
		switch (szin){
			case "green": document.getElementById(V_i+"_T").rows[V_k].cells[3].innerHTML="G"; break;
			case "yellow": document.getElementById(V_i+"_T").rows[V_k].cells[3].innerHTML="Y"; naplo("VI Jelent�s Elemz�: "+VIJE_koord+" falun egys�gveszt�s t�rt�nt."); break;
			case "blue": document.getElementById(V_i+"_T").rows[V_k].cells[3].innerHTML="B"; break;
			default: document.getElementById(V_i+"_T").rows[V_k].cells[3].innerHTML="R"; naplo("VI Jelent�s Elemz�: "+VIJE_koord+" tov�bbi t�mad�sa <b>vesz�lyesnek</b> �t�lve"); break;
		}		
		VIJE_OPEN=VIJE_table.rows[VIJE_ik[j]].cells[0].getElementsByTagName("a")[0].getAttribute("href").match(/view=[0-9]+/g)[0];
		VIJE_REF.location=(VIJE_REF.document.location.href+"&"+VIJE_OPEN);
		koord=VIJE_koord;
		hely1=V_i+"_T";
		hely2=V_k;
		return true;
	} else return false;
	}catch(e){naplo("VIJE: Hiba: "+e);}
}
function jelelemez(VIJE_REF){
	try{
		if (VIJE_REF.document.getElementById("attack_spy")){
			var x=VIJE_REF.document.getElementById("attack_spy").innerHTML;
			x=x.replace(/<span class="grey">.<\/span>/g,"");
			var nyers=x.match(/(>)[0-9]+( <)/g); var ossz=0;
			for (i=0;i<nyers.length;i++) {nyers[i]=nyers[i].replace(">","");nyers[i]=nyers[i].replace(" <",""); ossz+=parseInt(nyers[i]);}
			document.getElementById(hely1).rows[hely2].cells[4].innerHTML=ossz;
		}
	return 0;
	}catch(e) {naplo(e);}
}
function VIJE_main(){
	try{
	if (window["VIJE"]==undefined || !isbot(VIJE_lap)) {
	  VIJE_lap=window.open(WEBPAGE+"&screen=report&mode=attack"+SITTER,"VIJE");
	  var VIJE_ido=(Math.floor(Math.random()*61)+30)*500;
	  var folyt=false;
	  setTimeout("folyt=jelkeres(VIJE_lap)",3000);
	  setTimeout("jelelemez(VIJE_lap)",6000);
	  iVIJE=setTimeout("VIJE_main()",VIJE_ido);
	}}catch(e){naplo("VIJE: Hiba jelent�s-elemz�s k�zben: "+e)};
}
var koord=""; var hely1=""; var hely2="";
VIJE_main();
void(0);