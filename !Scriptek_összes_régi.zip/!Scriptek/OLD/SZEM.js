javascript:
function setCookie(name, value, expire) {
	document.cookie = name + "=" + escape(value)
	+ ((expire == null) ? "" : ("; expires=" + expire.toGMTString()));
}

function getCookie(Name){
	var search = Name + "=";
	if (document.cookie.length > 0) {
		offset = document.cookie.indexOf(search);
		if (offset != -1) {
			offset += search.length;
			end = document.cookie.indexOf(";", offset);
			if (end == -1) end = document.cookie.length;
			return unescape(document.cookie.substring(offset, end));
		}
	}
}

function kitolt(){
	i = getCookie(ID);
	if (i>hossz || i!=parseInt(i)) {
		document.getElementById("kor").innerHTML+="<tr><td>"+Date()+"</td><td>Hiba l�pett fel l�ptet�skor: "+i+". falu (?)! �jraind�t�s...</td></tr>";
		i=0;
		setCookie(ID,i);} else i=parseInt(i);
	aktualis.document.forms["units"].x.value=b[i][0];
	aktualis.document.forms["units"].y.value=b[i][1];
	aktualis.document.forms["units"].sword.value=KL[i];
	aktualis.document.forms["units"].spy.value=0;
	aktualis.document.forms["units"].attack.click();
}

function check_ok(){
	var teszt=aktualis.document.getElementById("content_value");
	teszt=teszt.innerHTML;
	var patt=/Gy�lekez�hely/g;
	if (!(patt.test(teszt))) {
		i++;
		setCookie(ID,i);
		aktualis.document.forms[0].submit.click();
	}
	if (i >= hossz) {
		i=0;
		setCookie(ID,i);
		document.getElementById("kor").innerHTML+="<tr><td>"+Date()+"</td><td>A script k�rbe�rt, �s el�r�l kezdi munk�j�t.</td></tr>";
	}
	document.getElementById("next").innerHTML="K�vetkez� falu: "+b[i][0]+"|"+b[i][1]+" ("+(i+1)+". falu a sorban)";
}

	var KL=new Array(10,20);
	ID="tesztSZEM";
	var b=new Array();
	var hossz = KL.length;
	b[0] = new Array(399,601); 
	b[1] = new Array(399,601);
	i=0;
	setCookie(ID,i);
	document.title = "SZEM b�zis"; void(0);
	document.getElementById("ds_body").innerHTML='<p align="center"><img src="http://cncdani2.freeiz.com/pic/Focim/Scriptgen_SZEM.png"></p><br><br><p align="center">Itt jelenleg a SZEM nev� script fut.<br>Befejez�shez z�rd be ezt a lapot.<br><br>Azonosito: '+ID+'<br></p><p align="center" id="next">K�vetkez� falu: '+b[0][0]+"|"+b[0][1]+' (1. falu a sorban)</p><p align="center"><b><a href=\'javascript: function setCookie(name, value, expire) {document.cookie = name + "=" + escape(value) + ((expire == null) ? "" : ("; expires=" + expire.toGMTString()));} if ((i+1)>=hossz) {i=0; document.getElementById("kor").innerHTML+="<tr><td>"+Date()+"</td><td>A script k�rbe�rt, �s el�r�l kezdi munk�j�t.</td></tr>";} else i++; setCookie(ID,i); document.getElementById("next").innerHTML="K�vetkez� falu: "+b[i][0]+"|"+b[i][1]+" ("+(i+1)+". falu a sorban)"; void(0);\'>Ugord ki ezt a falut!</a></b></p><h1 align="center">Napl�</h1><table cellpadding="3px" align="center" class="vis"><tbody id="kor"><tr><th>D�tum</th><th>Esem�ny</th></tr><tr><td>'+Date()+'</td><td>SZEM elindult.</td></tr></tbody></table>';
	
	function SZEM(){
		var ido = (Math.floor(Math.random()*61)+30)*800;
		var url=document.location.href;
		urll=url.replace("report", "place");
		urll=urll.replace("&mode=all","");
		urll=urll.replace(/(&view=)[0-9]*/g,"");
		aktualis=window.open(urll,ID);
		setTimeout("kitolt()",2000);
		setTimeout("check_ok()",4000);
		setTimeout("SZEM()",ido);
	}
	
SZEM();
void(0);