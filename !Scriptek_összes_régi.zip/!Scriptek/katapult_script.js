javascript:
function setCookie(name, value, expire) {
	document.cookie = name + "=" + escape(value)
	+ ((expire == null) ? "" : ("; expires=" + expire.toGMTString()));
}

function getCookie(Name){
	var search = Name + "=";
	if (document.cookie.length > 0) {
		offset = document.cookie.indexOf(search);
		if (offset != -1) {
			offset += search.length;
			end = document.cookie.indexOf(";", offset);
			if (end == -1) end = document.cookie.length;
			return unescape(document.cookie.substring(offset, end));
		}
	}
}
	
	var d=document;	
	if(window.frames.length>0) d=window.main.document;
	url=d.URL;
	if(url.indexOf('screen=place')==-1) {
		alert('Gy�l. helyen pr�b�ld...');
		exit(0);
	}
	var KL=new Array(3,2,2,2);
	hossz=KL.length;
	var celpont='smith';
	
	VISITED = 0;
	VISITED = getCookie('visited');
	if (VISITED==null || VISITED=="") {
		VISITED=0;
	} else {
		VISITED++;
	}
	
if (VISITED >= (hossz)){
		alert("Katapultoz�s k�sz.\n A script �jraindul...");
		expDate = new Date();
		expDate.setTime(expDate.getTime() + (100));
		setCookie('visited', 0, expDate);
	} else {
		expDate = new Date();
		expDate.setTime(expDate.getTime() + (60*1000));
		setCookie('visited', VISITED, expDate);
	}
	
if(d.forms[0].name=='units')
	{
	d.forms[0].x.value=325;
	d.forms[0].y.value=379;
	d.forms[0].catapult.value=KL[VISITED];
	d.forms[0].attack.click();
	} else {
	d.forms[0].elements['building'].value=celpont;
	d.forms[0].submit.click();
	setCookie('visited', VISITED-1, expDate);
	}
	void(0);