javascript:
coords='298|665 397|753';
ejjel=7; /*�jszakai b�nusz v�ge. 0: ne vegye figyelembe*/
sebesseg=30*60; /*Kos sebess�ge m�sodpercbe (vagy perc*60).*/

kuld();
function kuld(){
if (document.forms[0].name!='units') {document.forms[0].submit.click(); return;}
var doc=document;
if(window.frames.length>0)doc=window.main.document;url=doc.URL; 
if(url.indexOf('screen=place')==-1)alert('Ez a script csak a gy�lekezohelyrol futtathat�!');
coords=coords.match(/([0-9]+)(\|)([0-9]+)/g);

round=0;found=0;
while(round<300){
	index=Math.round(Math.random()*(coords.length-1));
	coordsb=coords[index];coordsb=coordsb.split('|');
	tit=document.title;
	x=(tit.substring(tit.indexOf('(')+1,tit.indexOf('|')));dx=(coordsb[0]-x);
	y=(tit.substring(tit.indexOf('|')+1,tit.indexOf(')')));dy=(coordsb[1]-y);
	tav=Math.sqrt(dx*dx+dy*dy);
	now=new Date();
	arr=new Date(now.valueOf()+sebesseg*1000*tav);
	if(arr.getHours()<ejjel){
	}else{
		round=round+1000;found=1;}
	round++;
}
if(found==1){
	doc.forms[0].input.value=coordsb[0]+"|"+coordsb[1];
	selectAllUnits(false);
	/*�t�rhat� ter�let KEZDETE*/ 
	insertUnit(doc.forms[0].spear,50); /*L�ndzs�s*/
	insertUnit(doc.forms[0].sword,0); /*Kardos*/
	insertUnit(doc.forms[0].axe,0); /*B�rdos*/
	insertUnit(doc.forms[0].archer,0); /*�j�sz*/
	insertUnit(doc.forms[0].spy,2); /*K�m*/
	insertUnit(doc.forms[0].light,0); /*K�nny�lovas*/
	insertUnit(doc.forms[0].marcher,0); /*Lovas�j�sz*/
	insertUnit(doc.forms[0].heavy,5); /*Neh�zlovas*/
	insertUnit(doc.forms[0].ram,0); /*kos*/
	insertUnit(doc.forms[0].catapult,5); /*Katapult*/
	/*�t�rhat� ter�let V�GE*/ 
	doc.forms[0].attack.click();
	}else{alert('Minden c�l �jjel �rkezne')};
}
void(0);