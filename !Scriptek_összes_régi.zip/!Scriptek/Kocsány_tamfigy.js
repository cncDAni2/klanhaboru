javascript:
if ((document.location.href.indexOf("mode=vacation")==-1) || (document.location.href.indexOf("t=")>0)){
	alert("Ez a bot csak a saj�t fi�kod fi�khelyettes�t�sek oldal�r�l ind�that�.\nOK lenyom�sa ut�n bet�lt�dik...");
	document.location.href="game.php?village="+game_data.village.id+"&mode=vacation&screen=settings";
	exit(0);
}
init();
var LAP=1; var REF;
munka();
function init(){try{
	for (var i=0;i<document.links.length;i++){
		if (document.links[i].href.indexOf("action=sitter_login")>-1){
			var tabla=document.links[i].parentNode.parentNode.parentNode;
			break;
		}
	}
	if (tabla==undefined) {throw "Nem tal�lhat� helyettes�tend� fi�k"; }
	var newcell=tabla.rows[0].insertCell(0); newcell.innerHTML='Figyel�s?';
	var newcell=tabla.rows[0].insertCell(2); newcell.innerHTML='Bej�v�k';
	for (var i=1;i<tabla.rows.length;i++){
		newcell=tabla.rows[i].insertCell(0); newcell.innerHTML='<input type="checkbox">';
		newcell=tabla.rows[i].insertCell(3); newcell.innerHTML='0';
	}
	document.body.innerHTML='<p align="center"><audio id="audio1" controls="controls" autoplay="autoplay"><source id="wavhang" src="" type="audio/wav"></audio></p><h1 align="center">KOCS�NY</h1><h3 align="center">T�mad�s fel�gyel�</h3><br><br><br><table align="center" id="tabla" class="vis">'+tabla.innerHTML+'<tr><td><input type="checkbox"></td><td>Saj�t fi�k</td><td><a href="'+document.location.href+'">� bejelentkez�s</a></td><td>0</td></tr></table><br><br><table align="center" id="naplo" class="vis"><tr><th>Id�pont</th><th>Napl�esem�ny</th></tr></table><br><br><div style="background-color: green" align="center"><b>Be�ll�t�sok</b><br>Egy fi�kot <input type="text" id="ido" value="600" size="3"> m�sodpercenk�nt ellen�rizzen.<br>T�mad�i ID lek�r�s: <i>Jelenleg nem el�rhet�</i><br>�zenetek figyel�s: <i>Jelenleg nem el�rhet�</i></div>';
	
	for (var i=0;i<document.links.length;i++){
		document.links[i].setAttribute("TARGET","_BLANK");
	}
	return;
}catch(e){alert("Hiba t�rt�nt :(\n"+e);}}

function playSound(hang){
var play="http://cncdani2.freeiz.com/SZEM3/Sounds/"+hang+".wav";
document.getElementById("wavhang").src=play;
document.getElementById("audio1").load();
document.getElementById("audio1").play();
}
function naplo(szoveg){
	var d=new Date();
	perc=d.getMinutes(); mp=d.getSeconds(); if (perc<10) perc="0"+perc; if (mp<10) mp="0"+mp;
	var honap=new Array("Janu�r","Febru�r","M�rcius","�prilis","M�jus","J�nius","J�lius","Augusztus","Szeptember","Okt�ber","November","December");
	var table=document.getElementById("naplo");
	var row=table.insertRow(1);
	var cell1=row.insertCell(0);
	var cell2=row.insertCell(1);
	cell1.innerHTML=honap[d.getMonth()]+" "+d.getDate()+", "+d.getHours()+":"+perc+":"+mp;
	cell2.innerHTML=szoveg;
}

function getCurrId(){try{
	/*Opci�: SOHA / �R�NK�NT / BEJ�V� T�MAD�S ESET�N */
}catch(e){}}
function egyeztet(jatekos){try{
	/*N�zze meg hogy az azon az a saj�t azon-od e!*/
	if (jatekos.getElementsByTagName("a")){
		var azon=jatekos.getElementsByTagName("a")[0].href.match(/player=[0-9]+/g)[0].split("=")[1];
		naplo("ERROR AT "+azon);
	} else {
		naplo("ERROR AT YOURSELF");
	}
}catch(e){naplo("egyeztet�si hiba:"+e);}}

function munka(){try{
	var X=document.getElementById("tabla").rows;
	if (X[LAP].cells[0].getElementsByTagName("input")[0].checked==true){
		if (REF==undefined || REF.document.title=="OK") { /*lapnyit�s*/
			var link="";
			if (X[LAP].cells[2].getElementsByTagName("a")[0].href.indexOf("sitter_login")==-1) link=X[LAP].cells[2].getElementsByTagName("a")[0].href; 
			else 
			link="game.php?t="+X[LAP].cells[2].getElementsByTagName("a")[0].href.match(/player=[0-9]+/g)[0].split("=")[1]+"&"+X[LAP].cells[2].getElementsByTagName("a")[0].href.match(/village=[0-9]+/g)[0]+"&screen=overview_villages";
			REF=window.open(link,"TAMFIGY");
		} else { /*adatlek�r�s*/
			try{
				if (REF.document.location.href.indexOf("sid_wrong")>-1) {naplo("Bel�ptek egy j�t�koskoz, vagy nem m�r el�rhet� n�lad a helyettes�t�s"); playSound("Bot"); throw "Err"; }
				if (REF.document.getElementById("bot_check") || REF.document.title=="Bot v�delem") {naplo("BOT v�delem akt�v "+X[LAP].cells[1].innerText+" j�t�kosn�l!");playSound("Bot"); throw "bot";}
				var bejovo=REF.game_data.player.incomings;
				/*if (REF.game_data.player.id==X[LAP].cells[???].???? ID) mehet; ellenben THROW "speci hiba", nem n�veli a lapot hanem pl. bez�rja...*/
				if (parseInt(X[LAP].cells[3].innerText)<bejovo){
					naplo("Bej�v� t�mad�s "+X[LAP].cells[1].innerHTML+' j�t�kosn�l! Bej�v�k sz�ma: <b><img src="http://hu17.tribalwars.net/graphic/unit/att.png?1bdd4">('+bejovo+')</b>');
					playSound("Bejovo");
				}
				if (REF.game_data.player.id==cells[2].getElementsByTagName("a")[0].href.match(/player=[0-9]+/g)[0].split("=")[1]) X[LAP].cells[3].innerHTML=bejovo; else naplo("Anom�lia? "+REF.game_data.player.id+" VS "+cells[2].getElementsByTagName("a")[0].href.match(/player=[0-9]+/g)[0].split("=")[1]+" nem egyez� sz�mok!");
				getCurrId();
			} catch(e){
				if (e=="Err") REF=window.open(X[LAP].cells[2].getElementsByTagName("a")[0].href,"TAMFIGY");
				egyeztet(X[LAP].cells[1].innerHTML);
				LAP++;
				if (e!="Err") REF=window.open(X[LAP].cells[2].getElementsByTagName("a")[0].href,"TAMFIGY");
			}
			REF.document.title="OK";
			LAP++;
		}
	} else LAP++;
	if (LAP>=X.length) LAP=1;
}catch(e){
	naplo(LAP+". sorban l�v� helyettesn�l gond van. Bejelentkez�si k�s�rlet...");
	LAP++;
	REF=window.open(X[LAP].cells[2].getElementsByTagName("a")[0].href,"TAMFIGY"); 
}
var ido=0; var getido=document.getElementById("ido").value; getido=getido.replace(/[^0-9]/g,""); if (getido=="") getido=300; getido=parseInt(getido); if (getido<10) {naplo("10mp-n�l gyorsabb ellen�rz�s nem vezet helyes m�k�d�shez."); getido=30;}
document.getElementById("ido").value=getido;
var pipak=0; var CX=document.getElementById("tabla").getElementsByTagName("input");
for (var i=0;i<CX.length;i++){if (CX[i].checked==true) pipak++;}
try{ido=Math.round(((getido*925)/(pipak*2))+(Math.random()*getido*0.15));}catch(e){naplo(e);}
setTimeout("munka()",ido);}

void(0);